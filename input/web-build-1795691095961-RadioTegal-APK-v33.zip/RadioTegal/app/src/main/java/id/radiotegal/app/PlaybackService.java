package id.radiotegal.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationChannelCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.ServiceCompat;

/**
 * Service foreground pemutar radio. Pemutaran sebenarnya dilakukan oleh RadioEngine
 * (ExoPlayer native + DSP), bukan WebView, sehingga suara tidak tersendat di belakang layar.
 * Notifikasi punya tombol sebelumnya (prev), putar/jeda, dan berikutnya (next).
 */
public class PlaybackService extends Service {

    static final String ACTION_PLAY = "id.radiotegal.app.action.PLAY";
    static final String ACTION_STOP = "id.radiotegal.app.action.STOP";
    static final String ACTION_PREV = "id.radiotegal.app.action.PREV";
    static final String ACTION_TOGGLE = "id.radiotegal.app.action.TOGGLE";
    static final String ACTION_NEXT = "id.radiotegal.app.action.NEXT";
    static final String EXTRA_URL = "url";
    static final String EXTRA_NAME = "name";

    private static final String CHANNEL_ID = "radiotegal_playback";
    private static final int NOTIF_ID = 1;

    private MediaSession session;
    private String currentName = "Radio Tegal";
    private boolean paused = false;

    @Override
    public void onCreate() {
        super.onCreate();

        NotificationChannelCompat ch = new NotificationChannelCompat.Builder(
                CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_LOW)
                .setName("Pemutaran Radio")
                .setDescription("Notifikasi saat radio diputar")
                .build();
        NotificationManagerCompat.from(this).createNotificationChannel(ch);

        session = new MediaSession(this, "RadioTegal");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { if (paused) RadioEngine.resume(); }
            @Override public void onPause() { if (!paused) RadioEngine.pause(); }
            @Override public void onSkipToNext() { RadioEngine.command("next"); }
            @Override public void onSkipToPrevious() { RadioEngine.command("prev"); }
        });
        updateSession();
        session.setActive(true);

        // ikon play/pause di notifikasi mengikuti status pemutar yang sebenarnya
        RadioEngine.setServiceListener(this::onEngineState);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            RadioEngine.release();
            stopSelf();
            return START_NOT_STICKY;
        }

        // Tombol notifikasi. Layanan sudah jalan; startForeground dipanggil lagi karena
        // PendingIntent foreground service mewajibkannya.
        if (ACTION_TOGGLE.equals(action) || ACTION_PREV.equals(action) || ACTION_NEXT.equals(action)) {
            enterForeground();
            if (ACTION_TOGGLE.equals(action)) {
                if (paused) RadioEngine.resume(); else RadioEngine.pause();
            } else {
                RadioEngine.command(ACTION_PREV.equals(action) ? "prev" : "next");
            }
            return START_NOT_STICKY;
        }

        String name = intent.getStringExtra(EXTRA_NAME);
        if (name == null || name.isEmpty()) name = "Radio Tegal";
        currentName = name;
        paused = false;
        updateSession();
        enterForeground();

        String url = intent.getStringExtra(EXTRA_URL);
        if (url != null && !url.isEmpty()) RadioEngine.play(this, url);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        RadioEngine.setServiceListener(null);
        RadioEngine.release();
        if (session != null) { session.setActive(false); session.release(); }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void onEngineState(String st) {
        boolean p;
        if ("paused".equals(st)) p = true;
        else if ("playing".equals(st) || "buffering".equals(st)) p = false;
        else return;
        if (p != paused) {
            paused = p;
            updateSession();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, buildNotification());
        }
    }

    private void enterForeground() {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void updateSession() {
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, currentName)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, "Radio Tegal").build());
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                        | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS)
                .setState(paused ? PlaybackState.STATE_PAUSED : PlaybackState.STATE_PLAYING,
                        PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f).build());
    }

    private PendingIntent actionIntent(String action, int requestCode) {
        Intent i = new Intent(this, PlaybackService.class).setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? PendingIntent.getForegroundService(this, requestCode, i, flags)
                : PendingIntent.getService(this, requestCode, i, flags);
    }

    private Notification.Action action(int icon, String label, String action, int requestCode) {
        return new Notification.Action.Builder(
                Icon.createWithResource(this, icon), label, actionIntent(action, requestCode)).build();
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setContentTitle(currentName)
                .setContentText(paused ? "Radio Tegal dijeda" : "Radio Tegal sedang diputar")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(action(android.R.drawable.ic_media_previous, "Sebelumnya", ACTION_PREV, 1))
                .addAction(paused
                        ? action(android.R.drawable.ic_media_play, "Putar", ACTION_TOGGLE, 2)
                        : action(android.R.drawable.ic_media_pause, "Jeda", ACTION_TOGGLE, 2))
                .addAction(action(android.R.drawable.ic_media_next, "Berikutnya", ACTION_NEXT, 3))
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(session.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2));
        return b.build();
    }
}
