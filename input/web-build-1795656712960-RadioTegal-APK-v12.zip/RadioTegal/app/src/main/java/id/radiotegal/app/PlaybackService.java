package id.radiotegal.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationChannelCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.ServiceCompat;

/**
 * Service foreground pemutar radio. Pemutaran sebenarnya dilakukan oleh RadioEngine
 * (ExoPlayer native + DSP), bukan WebView, sehingga suara tidak tersendat di belakang layar.
 */
public class PlaybackService extends Service {

    static final String ACTION_PLAY = "id.radiotegal.app.action.PLAY";
    static final String ACTION_STOP = "id.radiotegal.app.action.STOP";
    static final String EXTRA_URL = "url";
    static final String EXTRA_NAME = "name";

    private static final String CHANNEL_ID = "radiotegal_playback";
    private static final int NOTIF_ID = 1;

    private MediaSession session;

    @Override
    public void onCreate() {
        super.onCreate();
        session = new MediaSession(this, "RadioTegal");
        session.setPlaybackState(new PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE)
                .setState(PlaybackState.STATE_PLAYING, PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f).build());
        session.setActive(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_STOP.equals(intent.getAction())) {
            RadioEngine.release();
            stopSelf();
            return START_NOT_STICKY;
        }

        String name = intent.getStringExtra(EXTRA_NAME);
        if (name == null || name.isEmpty()) name = "Radio Tegal";
        session.setMetadata(new MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, name)
                .putString(MediaMetadata.METADATA_KEY_ARTIST, "Radio Tegal").build());

        Notification n = buildNotification(name);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }

        String url = intent.getStringExtra(EXTRA_URL);
        if (url != null && !url.isEmpty()) RadioEngine.play(this, url);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        RadioEngine.release();
        if (session != null) { session.setActive(false); session.release(); }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Notification buildNotification(String name) {
        NotificationChannelCompat ch = new NotificationChannelCompat.Builder(
                CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_LOW)
                .setName("Pemutaran Radio")
                .setDescription("Notifikasi saat radio diputar")
                .build();
        NotificationManagerCompat.from(this).createNotificationChannel(ch);

        Intent openIntent = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(this, 0, openIntent, flags);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        b.setContentTitle(name)
                .setContentText("Radio Tegal sedang diputar")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pi)
                .setOngoing(true)
                .setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken()));
        return b.build();
    }
}
