package id.radiotegal.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ActivityCompat;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0e0805"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                      // menyimpan daftar channel
        s.setMediaPlaybackRequiresUserGesture(false);      // pindah ke mode langsung tanpa ketuk ulang
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);                                // tata letak tidak berubah oleh ukuran font HP

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new PlaybackBridge(), "Android");

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Dipanggil dari index.html lewat Android.setPlaying(...) tiap kali status putar berubah. */
    private class PlaybackBridge {
        @JavascriptInterface
        public void setPlaying(boolean playing) {
            Intent i = new Intent(MainActivity.this, PlaybackService.class);
            if (playing) {
                i.setAction(PlaybackService.ACTION_START);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
                else startService(i);
            } else {
                i.setAction(PlaybackService.ACTION_STOP);
                startService(i);
            }
        }
    }

    /** Tombol kembali: tutup daftar channel dulu; jika sudah tertutup, radio tetap berjalan di belakang. */
    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
            "(function(){var s=document.getElementById('sheet');"
            + "if(s&&s.classList.contains('open')){s.classList.remove('open');return true}return false})()",
            result -> {
                if (!"true".equals(result)) {
                    moveTaskToBack(true);
                }
            });
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        startService(new Intent(this, PlaybackService.class).setAction(PlaybackService.ACTION_STOP));
        super.onDestroy();
    }
}
