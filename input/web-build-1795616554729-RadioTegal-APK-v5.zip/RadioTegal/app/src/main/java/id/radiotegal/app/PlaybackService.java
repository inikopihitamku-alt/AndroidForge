package id.radiotegal.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import androidx.core.app.NotificationChannelCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.ServiceCompat;

/**
 * Service kecil yang HANYA bertugas menahan CPU (wake lock) dan Wi-Fi (wifi lock)
 * selama radio sedang diputar.
 *
 * Penyebab suara tersendat saat aplikasi di belakang layar: Android mematikan
 * sebagian daya CPU dan menurunkan performa Wi-Fi begitu layar mati / aplikasi
 * tidak di depan (mode hemat baterai / Doze), sehingga aliran data stream
 * radio ikut terputus-putus. Service foreground dengan wake lock + wifi lock
 * ini memberi tahu sistem "sedang memutar media", sehingga pengecualian itu
 * tidak diberlakukan selama notifikasi masih tampil.
 */
public class PlaybackService extends Service {

    static final String ACTION_START = "id.radiotegal.app.action.START";
    static final String ACTION_STOP = "id.radiotegal.app.action.STOP";

    private static final String CHANNEL_ID = "radiotegal_playback";
    private static final int NOTIF_ID = 1;

    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;

    @Override
    public void onCreate() {
        super.onCreate();
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RadioTegal:playback");
        wakeLock.setReferenceCounted(false);

        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "RadioTegal:wifi");
        wifiLock.setReferenceCounted(false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }

        if (!wakeLock.isHeld()) wakeLock.acquire(12 * 60 * 60 * 1000L); // batas aman 12 jam
        if (!wifiLock.isHeld()) wifiLock.acquire();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Notification buildNotification() {
        NotificationManagerCompat nm = NotificationManagerCompat.from(this);
        NotificationChannelCompat ch = new NotificationChannelCompat.Builder(
                CHANNEL_ID, NotificationManagerCompat.IMPORTANCE_LOW)
                .setName("Pemutaran Radio")
                .setDescription("Menjaga siaran tetap lancar saat aplikasi di belakang layar")
                .build();
        nm.createNotificationChannel(ch);

        Intent openIntent = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent pi = PendingIntent.getActivity(this, 0, openIntent, flags);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Radio Tegal sedang diputar")
                .setContentText("Ketuk untuk membuka")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }
}
