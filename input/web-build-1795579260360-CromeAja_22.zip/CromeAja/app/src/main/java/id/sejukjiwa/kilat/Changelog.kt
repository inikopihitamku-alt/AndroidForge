package id.sejukjiwa.kilat

/**
 * Riwayat perubahan yang tampil di menu "Tentang CromeAja".
 * Tiap ada perubahan: tambahkan baris baru di ATAS dan samakan angka versinya dengan versionName di app/build.gradle.
 */
object Changelog {
    val ENTRIES = listOf(
        "1.5" to "Thumbnail tab aktif tidak kosong lagi; ukuran thumbnail tab dikecilkan (3 kolom)",
        "1.4" to "Tekan lama thumbnail situs di halaman utama membuka dialog ubah (ada tombol Hapus)",
        "1.3" to "Perbaikan unduhan gagal \"Failed to build unique file\": nama file otomatis diganti bila bentrok",
        "1.2" to "Versi sebelumnya"
    )
}
