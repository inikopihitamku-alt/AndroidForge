package com.example.amperemeter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Amperemeter charging: tegangan (V), arus (mA), daya (W) ke baterai.
 *
 * Cara pakai: Android Studio > New Project > "Empty Views Activity"
 * (package com.example.amperemeter), ganti isi MainActivity.kt dengan file ini.
 * Tidak perlu permission tambahan. minSdk 21.
 */
class MainActivity : Activity() {

    private enum class UnitMode(val label: String) {
        AUTO("Otomatis"), MICRO("Paksa µA"), MILLI("Paksa mA")
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var bm: BatteryManager
    private var mode = UnitMode.AUTO
    private val samples = ArrayDeque<Double>() // untuk rata-rata, meredam fluktuasi

    private lateinit var tvStatus: TextView
    private lateinit var tvVolt: TextView
    private lateinit var tvAmp: TextView
    private lateinit var tvWatt: TextView
    private lateinit var tvInfo: TextView
    private lateinit var tvRaw: TextView
    private lateinit var btnMode: Button

    private val ticker = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    private fun update() {
        val i: Intent? = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        // Tegangan baterai (mV). Sebagian perangkat melaporkan dalam V.
        var mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        if (mv in 1..99) mv *= 1000
        val volt = mv / 1000.0

        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        // Arus mentah dari fuel gauge
        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (raw == Int.MIN_VALUE || raw == 0 && !charging) {
            tvStatus.text = "Sensor arus tidak tersedia / tidak ada arus"
        }

        // Konversi satuan. Banyak aplikasi "ngawur" karena salah di sini:
        // spesifikasi Android = µA, tapi beberapa merk melaporkan mA.
        val mA = when (mode) {
            UnitMode.MICRO -> abs(raw) / 1000.0
            UnitMode.MILLI -> abs(raw).toDouble()
            UnitMode.AUTO -> if (abs(raw) >= 20000) abs(raw) / 1000.0 else abs(raw).toDouble()
        }

        // Rata-rata 5 sampel terakhir
        samples.addLast(mA)
        if (samples.size > 5) samples.removeFirst()
        val avg = samples.average()

        val watt = volt * avg / 1000.0
        val src = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Charger (AC)"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> "Tidak dicolok"
        }

        tvStatus.text = when {
            plugged == 0 -> "Tidak mengisi (arus = pemakaian baterai)"
            status == BatteryManager.BATTERY_STATUS_FULL -> "Penuh"
            charging -> "Mengisi daya"
            else -> "Dicolok, tidak mengisi"
        }
        tvStatus.setTextColor(if (charging && plugged != 0) Color.parseColor("#2E7D32") else Color.GRAY)
        tvVolt.text = String.format("%.3f V", volt)
        tvAmp.text = String.format("%.0f mA", avg)
        tvWatt.text = String.format("%.2f W", watt)
        tvInfo.text = "Sumber: $src\nBaterai: ${level * 100 / scale}%   Suhu: ${"%.1f".format(temp)}°C"
        tvRaw.text = "Nilai mentah sensor: $raw\nSatuan: ${mode.label}"
    }

    // ---------- UI tanpa XML ----------
    private fun tv(size: Float, bold: Boolean = false, color: Int = Color.BLACK) = TextView(this).apply {
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            setBackgroundColor(Color.WHITE)
        }
        tvStatus = tv(16f, true)
        tvVolt = tv(44f, true, Color.parseColor("#1565C0"))
        tvAmp = tv(56f, true, Color.parseColor("#C62828"))
        tvWatt = tv(32f, true, Color.parseColor("#EF6C00"))
        tvInfo = tv(15f, color = Color.DKGRAY)
        tvRaw = tv(12f, color = Color.GRAY)
        btnMode = Button(this).apply {
            text = "Ganti satuan sensor (jika angka tidak masuk akal)"
            setOnClickListener {
                mode = UnitMode.values()[(mode.ordinal + 1) % UnitMode.values().size]
                samples.clear()
                update()
            }
        }
        val note = tv(11f, color = Color.GRAY).apply {
            text = "Nilai = arus yang tercatat sensor baterai (fuel gauge). " +
                    "Jika layar menyala, sebagian arus dipakai hp sehingga lebih kecil dari output charger."
            setPadding(0, 32, 0, 0)
        }
        listOf(
            tvStatus, label("TEGANGAN BATERAI"), tvVolt,
            label("ARUS MASUK"), tvAmp,
            label("DAYA"), tvWatt,
            tvInfo, tvRaw, btnMode, note
        ).forEach { root.addView(it) }
        setContentView(root)
    }

    private fun label(t: String) = tv(12f, color = Color.GRAY).apply {
        text = t
        setPadding(0, 24, 0, 0)
    }
}
