CARA BUILD APK
1. Install Android Studio (versi terbaru).
2. File > Open > pilih folder "Amperemeter" ini. Tunggu Gradle Sync selesai (butuh internet).
3. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK ada di: app/build/outputs/apk/debug/app-debug.apk
5. Kirim APK ke hp, aktifkan "Install dari sumber tidak dikenal", lalu install.

Lewat terminal (opsional): ./gradlew assembleDebug
