package com.example.amperemeter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Pengukur analog (jarum) yang digambar dengan Canvas. */
class GaugeView(
    ctx: Context,
    private val title: String,
    private val unit: String,
    private val accent: Int
) : View(ctx) {

    private var minV = 0f
    private var maxV = 100f
    private var majorStep = 20f
    private var decimals = 0
    private var shown = 0f
    private var target = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    fun configure(lo: Float, hi: Float, step: Float, dec: Int) {
        minV = lo; maxV = hi; majorStep = step; decimals = dec
        postInvalidateOnAnimation()
    }

    fun setValue(v: Float) {
        target = v
        postInvalidateOnAnimation()
    }

    private fun pt(cx: Float, cy: Float, rad: Float, deg: Float): PointF {
        val a = Math.toRadians(deg.toDouble())
        return PointF(cx + rad * cos(a).toFloat(), cy + rad * sin(a).toFloat())
    }

    override fun onDraw(c: Canvas) {
        val range = maxV - minV
        val diff = target - shown
        if (abs(diff) > range * 0.002f) {
            shown += diff * 0.2f
            postInvalidateOnAnimation()
        } else {
            shown = target
        }

        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f - 4f
        val frac = ((shown - minV) / range).coerceIn(0f, 1f)

        // muka jam
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#FDFDF6")
        c.drawCircle(cx, cy, r, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = r * 0.07f
        paint.color = Color.parseColor("#37474F")
        c.drawCircle(cx, cy, r, paint)

        // busur indikator warna
        val ra = r * 0.72f
        box.set(cx - ra, cy - ra, cx + ra, cy + ra)
        paint.strokeWidth = r * 0.045f
        paint.color = Color.parseColor("#E0E0E0")
        c.drawArc(box, 135f, 270f, false, paint)
        paint.color = accent
        c.drawArc(box, 135f, 270f * frac, false, paint)

        // garis skala dan angka
        val minor = majorStep / 5f
        val n = (range / minor).roundToInt()
        for (i in 0..n) {
            val v = minV + i * minor
            val deg = 135f + 270f * (i * minor / range)
            val isMajor = i % 5 == 0
            val p1 = pt(cx, cy, r * 0.93f, deg)
            val p2 = pt(cx, cy, r * (if (isMajor) 0.80f else 0.86f), deg)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = r * (if (isMajor) 0.035f else 0.015f)
            paint.color = Color.parseColor("#263238")
            c.drawLine(p1.x, p1.y, p2.x, p2.y, paint)
            if (isMajor) {
                val lp = pt(cx, cy, r * 0.56f, deg)
                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = r * 0.12f
                paint.typeface = Typeface.DEFAULT_BOLD
                c.drawText("%.${decimals}f".format(v), lp.x, lp.y + r * 0.04f, paint)
            }
        }

        // jarum
        val needleDeg = 135f + 270f * frac
        val tip = pt(cx, cy, r * 0.82f, needleDeg)
        val tail = pt(cx, cy, -r * 0.12f, needleDeg)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = r * 0.035f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = Color.parseColor("#D50000")
        c.drawLine(tail.x, tail.y, tip.x, tip.y, paint)
        paint.strokeCap = Paint.Cap.BUTT
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#263238")
        c.drawCircle(cx, cy, r * 0.07f, paint)

        // satuan dan judul
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = Typeface.DEFAULT_BOLD
        paint.color = accent
        paint.textSize = r * 0.2f
        c.drawText(unit, cx, cy + r * 0.40f, paint)
        paint.color = Color.parseColor("#546E7A")
        paint.textSize = r * 0.12f
        c.drawText(title, cx, cy + r * 0.80f, paint)
    }
}

/**
 * Amperemeter charging: voltmeter dan amperemeter analog + digital,
 * data dari sensor baterai (BatteryManager). Ada indikator fast charging (perkiraan).
 */
class MainActivity : Activity() {

    private enum class UnitMode(val label: String) {
        AUTO("Otomatis"), MICRO("Paksa µA"), MILLI("Paksa mA")
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var bm: BatteryManager
    private var mode = UnitMode.AUTO
    private val samples = ArrayDeque<Double>()

    private lateinit var voltGauge: GaugeView
    private lateinit var ampGauge: GaugeView
    private lateinit var tvVoltDigital: TextView
    private lateinit var tvAmpDigital: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvFast: TextView
    private lateinit var tvInfo: TextView

    private val ticker = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun chargeTypeHint(): String? = try {
        File("/sys/class/power_supply/battery/charge_type").readText().trim()
    } catch (e: Exception) {
        null
    }

    private fun update() {
        val i: Intent? = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        var mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        if (mv in 1..99) mv *= 1000
        val volt = mv / 1000.0
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0

        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val rawAbs = if (raw == Int.MIN_VALUE) 0L else abs(raw.toLong())
        // Banyak aplikasi salah karena satuan: standar Android adalah mikroampere,
        // tetapi sebagian merk melaporkan miliampere.
        val ma = when (mode) {
            UnitMode.MICRO -> rawAbs / 1000.0
            UnitMode.MILLI -> rawAbs.toDouble()
            UnitMode.AUTO -> if (rawAbs >= 20000) rawAbs / 1000.0 else rawAbs.toDouble()
        }
        samples.addLast(ma)
        if (samples.size > 4) samples.removeFirst()
        val avg = samples.average()
        val watt = volt * avg / 1000.0

        val charging = plugged != 0 &&
                (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL)
        val full = status == BatteryManager.BATTERY_STATUS_FULL

        // Fast charging: tidak ada API resmi, jadi memakai petunjuk sistem bila terbaca
        // (charge_type) atau perkiraan dari daya sisi baterai.
        val hint = chargeTypeHint()
        val hintFast = hint != null && (hint.contains("fast", true) || hint.contains("turbo", true))
        val fast = charging && !full && (hintFast || watt >= 10.0)
        val superFast = charging && !full && watt >= 25.0

        // gauge
        voltGauge.setValue(volt.toFloat())
        val top = listOf(1000f, 2000f, 3000f, 5000f, 8000f, 12000f).firstOrNull { avg <= it * 0.95f } ?: 12000f
        ampGauge.configure(0f, top, top / 5f, 0)
        ampGauge.setValue(avg.toFloat())

        // digital
        tvVoltDigital.text = "%.2f V".format(volt)
        tvAmpDigital.text = "%.0f mA".format(avg)

        // status
        tvStatus.text = when {
            plugged == 0 -> "Tidak mengisi (arus = pemakaian baterai)"
            full -> "Baterai penuh"
            charging -> "Sedang mengisi daya"
            else -> "Terhubung, tidak mengisi"
        }
        if (fast) {
            tvFast.visibility = View.VISIBLE
            tvFast.text = if (superFast) "⚡⚡ SUPER FAST CHARGING AKTIF" else "⚡ FAST CHARGING AKTIF"
        } else {
            tvFast.visibility = View.GONE
        }

        val src = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Charger (AC)"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> "-"
        }
        tvInfo.text = "Daya ke baterai: %.2f W\nSumber: %s   Baterai: %d%%   Suhu: %.1f°C\nSensor mentah: %d (%s)%s".format(
            watt, src, level * 100 / scale, temp, raw, mode.label,
            if (hint != null) "\nTipe charge: $hint" else ""
        )
    }

    // ---------- UI ----------
    private fun text(size: Float, bold: Boolean = false, color: Int = Color.BLACK) = TextView(this).apply {
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun lcd(color: Int) = TextView(this).apply {
        textSize = 24f
        typeface = Typeface.MONOSPACE
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(dp(8), dp(8), dp(8), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#0D1B0D"))
            cornerRadius = dp(8).toFloat()
            setStroke(dp(2), Color.parseColor("#455A64"))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(28), dp(12), dp(16))
            setBackgroundColor(Color.parseColor("#ECEFF1"))
        }

        val title = text(20f, true, Color.parseColor("#263238")).apply { text = "AMPEREMETER CHARGING" }
        tvStatus = text(14f, true, Color.parseColor("#2E7D32")).apply { setPadding(0, dp(6), 0, dp(6)) }
        tvFast = text(15f, true, Color.WHITE).apply {
            visibility = View.GONE
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EF6C00"))
                cornerRadius = dp(20).toFloat()
            }
        }
        val fastWrap = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(tvFast)
        }

        voltGauge = GaugeView(this, "VOLTMETER", "V", Color.parseColor("#1565C0")).apply {
            configure(3.0f, 4.6f, 0.2f, 1)
        }
        ampGauge = GaugeView(this, "AMPEREMETER", "mA", Color.parseColor("#C62828")).apply {
            configure(0f, 1000f, 200f, 0)
        }
        val gaugeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(voltGauge, LinearLayout.LayoutParams(0, dp(170), 1f))
            addView(ampGauge, LinearLayout.LayoutParams(0, dp(170), 1f))
        }

        tvVoltDigital = lcd(Color.parseColor("#4FC3F7"))
        tvAmpDigital = lcd(Color.parseColor("#FF8A80"))
        val lcdRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val lp1 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp1.setMargins(dp(4), 0, dp(4), 0)
            val lp2 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            lp2.setMargins(dp(4), 0, dp(4), 0)
            addView(tvVoltDigital, lp1)
            addView(tvAmpDigital, lp2)
        }

        tvInfo = text(13f, color = Color.DKGRAY).apply { setPadding(0, dp(16), 0, dp(8)) }
        val btn = Button(this).apply {
            text = "Ganti satuan sensor (jika arus tidak masuk akal)"
            setOnClickListener {
                mode = UnitMode.values()[(mode.ordinal + 1) % UnitMode.values().size]
                samples.clear()
                update()
            }
        }
        val note = text(11f, color = Color.GRAY).apply {
            text = "Nilai dibaca dari sensor baterai (fuel gauge). Indikator fast charging adalah perkiraan " +
                    "dari daya ke baterai, karena Android tidak menyediakan data resminya."
        }

        listOf(title, tvStatus, fastWrap, gaugeRow, lcdRow, tvInfo, btn, note).forEach { col.addView(it) }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }
}
