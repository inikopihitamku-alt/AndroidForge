package id.radiotegal.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import kotlin.math.min

/**
 * Pemutar radio NATIVE (ExoPlayer) + DSP di thread audio sendiri.
 * Tidak lagi lewat WebView, jadi suara tidak tersendat saat aplikasi di belakang layar / layar mati.
 */
object RadioEngine {

    fun interface StateListener { fun onState(state: String) }

    val processor = EqAudioProcessor()
    private val main = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var url: String? = null
    private var retries = 0
    @Volatile private var listener: StateListener? = null

    @Volatile private var vol = 0.6f
    @Volatile private var low = 0.56f
    @Volatile private var mid = 0.56f
    @Volatile private var high = 0.56f

    @JvmStatic fun setStateListener(l: StateListener?) { listener = l }

    private fun emit(s: String) { listener?.onState(s) }

    private val retryRun = Runnable {
        val u = url
        val p = player
        if (u != null && p != null) {
            p.setMediaItem(MediaItem.fromUri(u))
            p.prepare()
            p.playWhenReady = true
        }
    }

    private fun fail() {
        if (url == null) return
        if (retries < 6) {
            retries++
            emit("buffering")
            main.removeCallbacks(retryRun)
            main.postDelayed(retryRun, 2000L * retries)   // sambung ulang otomatis
        } else {
            emit("error")
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                retries = 0
                emit("playing")
            } else {
                when (player?.playbackState) {
                    Player.STATE_BUFFERING -> emit("buffering")
                    Player.STATE_READY -> emit("paused")
                    else -> {}
                }
            }
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_BUFFERING && player?.playWhenReady == true) emit("buffering")
            if (state == Player.STATE_ENDED) fail()
        }

        override fun onPlayerError(error: PlaybackException) { fail() }
    }

    private fun build(ctx: Context): ExoPlayer {
        val renderersFactory = RenderersFactory { handler, _, audioListener, _, _ ->
            val sink = DefaultAudioSink.Builder(ctx)
                .setAudioProcessors(arrayOf<AudioProcessor>(processor))
                .build()
            arrayOf<Renderer>(
                MediaCodecAudioRenderer(ctx, MediaCodecSelector.DEFAULT, handler, audioListener, sink)
            )
        }
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("RadioTegal/2.3 (Android)")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
        val sourceFactory = DefaultMediaSourceFactory(DefaultDataSource.Factory(ctx, httpFactory))

        val p = ExoPlayer.Builder(ctx, renderersFactory)
            .setMediaSourceFactory(sourceFactory)
            .setWakeMode(C.WAKE_MODE_NETWORK)          // CPU + Wi-Fi tetap aktif saat layar mati
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(playerListener)
        p.volume = playerVolume()
        return p
    }

    private fun playerVolume(): Float = min(1f, vol * vol * 1.15f)

    /** Pengaturan suara dari knob layar: karakter hangat ala Harman + loudness otomatis. */
    private fun dsp(): DspParams {
        val v = vol
        val lowDb = (low - 0.5f) * 16f
        val midDb = (mid - 0.5f) * 20f
        val highDb = (high - 0.5f) * 22f
        val loudLo = 1.5f + 4f * (1f - v)      // makin pelan, bass diangkat
        val loudHi = 1f + 4f * (1f - v)        // makin pelan, treble diangkat
        val g = FloatArray(EqAudioProcessor.BAND_COUNT)
        // 31, 62, 125, 250, 500, 1k, 2k, 4k, 8k, 16k
        g[0] = lowDb * 0.6f + loudLo * 0.8f
        g[1] = lowDb + loudLo
        g[2] = lowDb * 0.8f + loudLo * 0.5f
        g[3] = lowDb * 0.3f + 0.6f             // hangat
        g[4] = midDb * 0.5f
        g[5] = midDb
        g[6] = midDb * 0.9f + 0.8f             // vokal jernih
        g[7] = highDb * 0.8f + 0.7f
        g[8] = highDb + loudHi * 0.5f
        g[9] = highDb * 0.9f + loudHi
        for (i in g.indices) g[i] = g[i].coerceIn(-EqAudioProcessor.MAX_GAIN_DB, EqAudioProcessor.MAX_GAIN_DB)
        return DspParams(
            eqEnabled = true,
            gains = g,
            preampDb = 0f,
            noiseFilter = true,    // filter desis halus: rumble 30 Hz + gerbang noise lembut
            bassBoost = 0.15f,
            width = 1.3f,
            ampDb = 3f,
        )
    }

    @JvmStatic fun setSound(v: Float, l: Float, m: Float, h: Float) {
        vol = v.coerceIn(0f, 1f); low = l; mid = m; high = h
        processor.setParams(dsp())
        main.post { player?.volume = playerVolume() }
    }

    @JvmStatic fun play(ctx: Context, streamUrl: String) {
        val app = ctx.applicationContext
        main.post {
            url = streamUrl
            retries = 0
            main.removeCallbacks(retryRun)
            val p = player ?: build(app).also { player = it }
            processor.setParams(dsp())
            p.volume = playerVolume()
            p.setMediaItem(MediaItem.fromUri(streamUrl))
            p.prepare()
            p.playWhenReady = true
            emit("buffering")
        }
    }

    @JvmStatic fun release() {
        main.post {
            url = null
            main.removeCallbacks(retryRun)
            player?.release()
            player = null
        }
    }

    /** "kiri,kanan,bass,limiter(dB)" untuk meter di layar. */
    @JvmStatic fun levels(): String =
        "${processor.levelL},${processor.levelR},${processor.bassLevel},${processor.limiterReductionDb}"
}
