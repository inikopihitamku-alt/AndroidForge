
# dipanggil lewat refleksi (MainActivity.enableWebAuthn)
-keep class androidx.webkit.WebSettingsCompat { *; }

# dipanggil lewat refleksi (MainActivity.chromeBrandHints)
-keep class androidx.webkit.UserAgentMetadata { *; }
-keep class androidx.webkit.UserAgentMetadata$* { *; }
-keep class androidx.webkit.UserAgentMetadata$BrandVersion$* { *; }
