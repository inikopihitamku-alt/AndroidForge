package id.sejukjiwa.kilat

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebView
import java.io.File

/**
 * Jendela pribadi: berjalan di proses terpisah dengan direktori data WebView sendiri
 * (cookie, cache, storage tidak tercampur dengan mode biasa). Data dihapus saat ditutup.
 */
class PrivateActivity : MainActivity() {
    override val isPrivate = true

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(R.style.AppThemePrivate)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                File(applicationInfo.dataDir, "app_webview_private").deleteRecursively()
                WebView.setDataDirectorySuffix("private")
            } catch (e: Exception) {
                // sudah diset pada pembuatan ulang activity
            }
        }
        super.onCreate(savedInstanceState)
    }
}
