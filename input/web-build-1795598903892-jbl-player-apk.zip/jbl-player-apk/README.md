# JBL Player - Build ke APK (Capacitor)

## Cara 1: Tanpa Android Studio (paling mudah, lewat GitHub)
1. Buat repository baru di GitHub, upload SEMUA isi folder ini (termasuk folder .github).
2. Buka tab "Actions" > "Build APK" > "Run workflow".
3. Setelah selesai (sekitar 5 menit), buka hasilnya dan unduh artifact "jbl-player-apk".
4. Ekstrak, lalu pasang app-debug.apk di HP (izinkan "install dari sumber tidak dikenal").

## Cara 2: Di komputer sendiri
Syarat: Node.js 18+, JDK 17, Android Studio (atau Android SDK), ANDROID_HOME sudah di-set.

    npm install
    npx cap add android
    npx cap sync android
    cd android
    ./gradlew assembleDebug        (Windows: gradlew.bat assembleDebug)

APK ada di: android/app/build/outputs/apk/debug/app-debug.apk

Atau buka folder "android" dengan Android Studio lalu Build > Build APK(s).

## Mengubah tampilan/kode
Seluruh aplikasi ada di www/index.html. Setelah diubah jalankan: npx cap sync android

## Ganti ikon & nama
- Nama: ubah "appName" di capacitor.config.json
- Ikon: ganti file di android/app/src/main/res/mipmap-* (atau pakai Android Studio > Image Asset)

## Catatan
- APK debug cukup untuk dipasang sendiri. Untuk Play Store perlu build release yang ditandatangani.
- Tombol buka lagu memakai pemilih file Android, tidak butuh izin tambahan.
