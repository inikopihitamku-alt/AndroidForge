package com.fileku.app;

import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.*;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.text.*;
import android.util.LruCache;
import android.view.*;
import android.webkit.MimeTypeMap;
import android.widget.*;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Consumer;
import java.util.zip.*;

public class MainActivity extends Activity {
    static final int BLUE = 0xFF1E88E5, GREEN = 0xFF43A047, ORANGE = 0xFFFB8C00, RED = 0xFFE53935, GREY = 0xFF546E7A;
    static final List<String> IMG = Arrays.asList("jpg", "jpeg", "png", "gif", "webp", "bmp");
    interface Job { void run() throws Exception; }

    File root = Environment.getExternalStorageDirectory(), cur = root;
    List<File> shown = new ArrayList<>(), clip = new ArrayList<>();
    Set<File> sel = new LinkedHashSet<>();
    boolean cut; int sortMode;
    ListView lv; TextView path; EditText search; LinearLayout barIn; FA ad;
    ScrollView homeSv; LinearLayout homeBox; HorizontalScrollView barHs;
    boolean home = true, scanning; List<File> catFiles; String catTitle = ""; int scanId;
    static final List<String> AUD = Arrays.asList("mp3", "wav", "m4a", "ogg", "flac", "aac", "amr", "opus");
    static final List<String> VID = Arrays.asList("mp4", "mkv", "avi", "3gp", "webm", "mov");
    static final List<String> DOC = Arrays.asList("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "epub");
    static final List<String> APK = Arrays.asList("apk", "xapk", "apks");
    Handler h = new Handler(Looper.getMainLooper());
    LruCache<String, Bitmap> cache = new LruCache<>(150);

    int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    @Override protected void onCreate(Bundle sb) {
        super.onCreate(sb);
        getWindow().setStatusBarColor(BLUE);
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setBackgroundColor(-1);
        TextView t = new TextView(this); t.setText("Fileku"); t.setTextColor(-1); t.setTextSize(22);
        t.setTypeface(null, Typeface.BOLD); t.setBackgroundColor(BLUE); t.setPadding(dp(16), dp(14), dp(16), dp(6));
        path = new TextView(this); path.setBackgroundColor(BLUE); path.setTextColor(0xFFE3F2FD); path.setTextSize(12);
        path.setPadding(dp(16), 0, dp(16), dp(10)); path.setSingleLine(true); path.setEllipsize(TextUtils.TruncateAt.START);
        search = new EditText(this); search.setHint("Cari di folder ini…"); search.setSingleLine(true);
        search.setPadding(dp(16), dp(8), dp(16), dp(8));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence a, int x, int y, int z) {}
            public void onTextChanged(CharSequence a, int x, int y, int z) {}
            public void afterTextChanged(Editable e) { load(); }
        });
        lv = new ListView(this); ad = new FA(); lv.setAdapter(ad);
        lv.setOnItemClickListener((p, v, i, id) -> { File f = shown.get(i); if (!sel.isEmpty()) toggle(f); else open(f); });
        lv.setOnItemLongClickListener((p, v, i, id) -> { toggle(shown.get(i)); return true; });
        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setBackgroundColor(0xFFECEFF1); barHs = hs;
        barIn = new LinearLayout(this); hs.addView(barIn);
        homeSv = new ScrollView(this); homeBox = new LinearLayout(this); homeBox.setOrientation(LinearLayout.VERTICAL);
        homeBox.setPadding(dp(8), dp(8), dp(8), dp(16)); homeSv.addView(homeBox);
        t.setOnClickListener(v -> showHome());
        r.addView(t); r.addView(path); r.addView(search);
        r.addView(homeSv, new LinearLayout.LayoutParams(-1, 0, 1));
        r.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1));
        r.addView(hs);
        setContentView(r);
        askPermission();
    }

    void askPermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager()) {
                try { startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()))); }
                catch (Exception e) { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
            }
        } else if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
    }

    @Override protected void onResume() { super.onResume(); load(); }
    @Override public void onRequestPermissionsResult(int c, String[] p, int[] g) { load(); }
    @Override public void onBackPressed() {
        if (!sel.isEmpty()) { sel.clear(); load(); }
        else if (home) super.onBackPressed();
        else if (catFiles == null && !cur.equals(root) && cur.getParentFile() != null) { cur = cur.getParentFile(); load(); }
        else showHome();
    }

    void load() {
        boolean browse = !home;
        homeSv.setVisibility(home ? View.VISIBLE : View.GONE); lv.setVisibility(browse ? View.VISIBLE : View.GONE);
        search.setVisibility(browse ? View.VISIBLE : View.GONE); barHs.setVisibility(browse ? View.VISIBLE : View.GONE);
        if (home) { buildHome(); return; }
        List<File> src;
        if (catFiles != null) { catFiles.removeIf(f -> !f.exists()); src = catFiles; }
        else { File[] a = cur.listFiles(); src = a == null ? new ArrayList<File>() : Arrays.asList(a); }
        List<File> l = new ArrayList<>();
        String q = search == null ? "" : search.getText().toString().toLowerCase();
        for (File f : src) if (q.isEmpty() || f.getName().toLowerCase().contains(q)) l.add(f);
        Collections.sort(l, (x, y) -> {
            if (x.isDirectory() != y.isDirectory()) return x.isDirectory() ? -1 : 1;
            if (sortMode == 1) return Long.compare(y.lastModified(), x.lastModified());
            if (sortMode == 2) return Long.compare(y.length(), x.length());
            return x.getName().compareToIgnoreCase(y.getName());
        });
        shown = l; sel.retainAll(l); ad.notifyDataSetChanged();
        String head = catFiles != null ? catTitle + " • " + l.size() + " file" + (scanning ? " (memindai…)" : "") : cur.getPath();
        path.setText(head + (sel.isEmpty() ? "" : "  •  " + sel.size() + " dipilih"));
        refreshBar();
    }

    void showHome() { home = true; catFiles = null; scanning = false; scanId++; sel.clear(); search.setText(""); load(); }

    void openDir(File r, File c) { home = false; catFiles = null; root = r; cur = c; sortMode = 0; sel.clear(); search.setText(""); load(); }

    View tile(String ic, int col, String name, String sub, Runnable r) {
        LinearLayout t = new LinearLayout(this); t.setOrientation(LinearLayout.VERTICAL); t.setGravity(Gravity.CENTER_HORIZONTAL); t.setPadding(dp(4), dp(10), dp(4), dp(10));
        TextView i = new TextView(this); i.setText(ic); i.setTextSize(30); i.setGravity(Gravity.CENTER); i.setTextColor(-1);
        GradientDrawable g = new GradientDrawable(); g.setColor(col); g.setCornerRadius(dp(20)); i.setBackground(g);
        t.addView(i, new LinearLayout.LayoutParams(dp(68), dp(68)));
        TextView n = new TextView(this); n.setText(name); n.setTextSize(14); n.setTextColor(0xFF212121); n.setSingleLine(true); n.setEllipsize(TextUtils.TruncateAt.END); n.setPadding(0, dp(6), 0, 0); t.addView(n);
        if (sub != null) { TextView s = new TextView(this); s.setText(sub); s.setTextSize(11); s.setTextColor(0xFF78909C); s.setSingleLine(true); t.addView(s); }
        t.setOnClickListener(v -> r.run()); return t;
    }

    void section(String title, List<View> ts) {
        TextView t = new TextView(this); t.setText(title); t.setTextSize(15); t.setTypeface(null, Typeface.BOLD); t.setTextColor(BLUE); t.setPadding(dp(10), dp(12), 0, dp(4)); homeBox.addView(t);
        LinearLayout row = null;
        for (int k = 0; k < ts.size(); k++) {
            if (k % 3 == 0) { row = new LinearLayout(this); homeBox.addView(row); }
            row.addView(ts.get(k), new LinearLayout.LayoutParams(0, -2, 1));
        }
        for (int k = ts.size() % 3; k != 0 && k < 3; k++) row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
    }

    void buildHome() {
        path.setText("Beranda"); homeBox.removeAllViews();
        List<View> st = new ArrayList<>(); File prim = Environment.getExternalStorageDirectory();
        for (File v : volumes()) {
            String lb = label(v); boolean internal = v.equals(prim), usb = lb.toLowerCase().contains("usb");
            st.add(tile(internal ? "📱" : usb ? "🔌" : "💾", internal ? BLUE : usb ? 0xFF00897B : ORANGE, lb,
                fmt(v.getTotalSpace() - v.getFreeSpace()) + " / " + fmt(v.getTotalSpace()), () -> openDir(v, v)));
        }
        File dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS); String[] dn = dl.list();
        st.add(tile("📥", 0xFFF9A825, "Unduhan", dn == null ? null : dn.length + " item", () -> openDir(prim, dl)));
        section("Penyimpanan", st);
        List<View> ct = new ArrayList<>();
        ct.add(tile("🖼", 0xFF8E24AA, "Gambar", null, () -> openCat("Gambar", IMG, false)));
        ct.add(tile("🎵", 0xFF00ACC1, "Audio", null, () -> openCat("Audio", AUD, false)));
        ct.add(tile("🎞", RED, "Video", null, () -> openCat("Video", VID, false)));
        ct.add(tile("📄", 0xFF1E88E5, "Dokumen", null, () -> openCat("Dokumen", DOC, false)));
        ct.add(tile("🤖", GREEN, "Aplikasi (APK)", null, () -> openCat("Aplikasi (APK)", APK, false)));
        ct.add(tile("🕑", GREY, "File Baru", null, () -> openCat("File Baru", null, true)));
        section("Kategori", ct);
    }

    void openCat(String title, List<String> exts, boolean recent) {
        home = false; catTitle = title; catFiles = new ArrayList<>(); sel.clear(); sortMode = 1; scanning = true; int id = ++scanId;
        search.setText(""); load();
        new Thread(() -> {
            List<File> out = new ArrayList<>(); for (File v : volumes()) scan(v, exts, out, 0);
            Collections.sort(out, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
            List<File> res = recent && out.size() > 100 ? new ArrayList<>(out.subList(0, 100)) : out;
            h.post(() -> { if (id == scanId && !home) { catFiles = res; scanning = false; load(); } });
        }).start();
    }

    void scan(File d, List<String> exts, List<File> out, int depth) {
        File[] a = d.listFiles(); if (a == null || depth > 12) return;
        for (File f : a) {
            String n = f.getName(); if (n.startsWith(".")) continue;
            if (f.isDirectory()) { if (!(depth == 0 && n.equals("Android"))) scan(f, exts, out, depth + 1); }
            else if (exts == null || exts.contains(ext(f))) out.add(f);
        }
    }

    List<File> volumes() {
        List<File> r = new ArrayList<>(); r.add(Environment.getExternalStorageDirectory());
        File[] a = getExternalFilesDirs(null);
        if (a != null) for (File d : a) {
            if (d == null) continue;
            String p = d.getAbsolutePath(); int i = p.indexOf("/Android/data");
            if (i > 0) { File v = new File(p.substring(0, i)); if (!r.contains(v)) r.add(v); }
        }
        File[] s = new File("/storage").listFiles();
        if (s != null) for (File d : s) {
            String n = d.getName();
            if (!n.equals("emulated") && !n.equals("self") && d.isDirectory() && d.canRead() && !r.contains(d)) r.add(d);
        }
        return r;
    }

    String label(File v) {
        if (v.equals(Environment.getExternalStorageDirectory())) return "Memori internal";
        try {
            StorageVolume sv = ((StorageManager) getSystemService(STORAGE_SERVICE)).getStorageVolume(v);
            if (sv != null) return sv.getDescription(this);
        } catch (Exception e) { }
        return v.getName();
    }

    void pickStorage() {
        List<File> vs = volumes(); String[] items = new String[vs.size()];
        for (int i = 0; i < items.length; i++) {
            File v = vs.get(i);
            items[i] = label(v) + "\n" + fmt(v.getFreeSpace()) + " kosong dari " + fmt(v.getTotalSpace());
        }
        new AlertDialog.Builder(this).setTitle("Pilih penyimpanan (" + vs.size() + " terdeteksi)")
            .setItems(items, (d, w) -> { root = vs.get(w); cur = root; sel.clear(); search.setText(""); load(); })
            .setNegativeButton("Tutup", null).show();
    }

    void toggle(File f) { if (!sel.remove(f)) sel.add(f); load(); }

    void btn(String t, int c, Runnable r) {
        TextView b = new TextView(this); b.setText(t); b.setTextColor(-1); b.setTypeface(null, Typeface.BOLD);
        b.setGravity(Gravity.CENTER); b.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable g = new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(18)); b.setBackground(g);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2); p.setMargins(dp(4), dp(6), dp(4), dp(6));
        b.setLayoutParams(p); b.setOnClickListener(v -> r.run()); barIn.addView(b);
    }

    void refreshBar() {
        barIn.removeAllViews();
        if (sel.isEmpty()) {
            btn("Beranda", BLUE, this::showHome);
            if (catFiles == null) btn("+ Folder", GREEN, this::newFolder);
            if (catFiles == null && !clip.isEmpty()) btn("Tempel (" + clip.size() + ")", ORANGE, this::paste);
            btn("Urutkan", BLUE, () -> new AlertDialog.Builder(this).setItems(new String[]{"Nama", "Terbaru", "Terbesar"}, (d, w) -> { sortMode = w; load(); }).show());
            btn("Pilih semua", GREY, () -> { sel.addAll(shown); load(); });
        } else {
            btn("Salin", BLUE, () -> { clip = new ArrayList<>(sel); cut = false; sel.clear(); toast("Siap ditempel"); load(); });
            btn("Pindah", ORANGE, () -> { clip = new ArrayList<>(sel); cut = true; sel.clear(); toast("Buka folder tujuan, lalu Tempel"); load(); });
            btn("Bagikan", GREEN, this::share);
            btn("Hapus", RED, this::delete);
            if (sel.size() == 1) {
                File f = sel.iterator().next(); String e = ext(f);
                btn("Ganti nama", BLUE, () -> ask("Ganti nama", f.getName(), n -> { if (!n.isEmpty() && f.renameTo(new File(f.getParentFile(), n))) sel.clear(); else toast("Gagal"); load(); }));
                if (e.equals("zip")) btn("Ekstrak", ORANGE, () -> extract(f));
                if (e.equals("rar") || e.equals("7z")) btn("Ekstrak", ORANGE, () -> toast("Saat ini hanya ZIP yang didukung"));
                if (e.equals("apk")) btn("Pasang", GREEN, () -> install(f));
                btn("Info", GREY, () -> info(f));
            }
            btn("Batal", GREY, () -> { sel.clear(); load(); });
        }
    }

    void ask(String title, String init, Consumer<String> ok) {
        EditText e = new EditText(this); e.setText(init);
        new AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("OK", (d, w) -> ok.accept(e.getText().toString().trim())).setNegativeButton("Batal", null).show();
    }
    void newFolder() { ask("Folder baru", "", n -> { if (!n.isEmpty() && new File(cur, n).mkdirs()) load(); else toast("Gagal membuat folder"); }); }

    void bg(Job j, String done) {
        toast("Memproses…");
        new Thread(() -> {
            try { j.run(); h.post(() -> { toast(done); sel.clear(); load(); }); }
            catch (Exception e) { h.post(() -> { toast("Gagal: " + e.getMessage()); load(); }); }
        }).start();
    }

    void delete() {
        List<File> l = new ArrayList<>(sel);
        new AlertDialog.Builder(this).setTitle("Hapus " + l.size() + " item?").setMessage("Tidak bisa dibatalkan.")
            .setPositiveButton("Hapus", (d, w) -> bg(() -> { for (File f : l) del(f); }, "Terhapus")).setNegativeButton("Batal", null).show();
    }
    void del(File f) { File[] a = f.listFiles(); if (a != null) for (File c : a) del(c); f.delete(); }

    void copy(File s, File d) throws IOException {
        if (s.isDirectory()) {
            if (d.getCanonicalPath().startsWith(s.getCanonicalPath() + "/")) throw new IOException("Folder tidak bisa disalin ke dalam dirinya");
            d.mkdirs(); File[] a = s.listFiles(); if (a != null) for (File c : a) copy(c, new File(d, c.getName()));
        } else try (InputStream in = new FileInputStream(s); OutputStream o = new FileOutputStream(d)) {
            byte[] bf = new byte[65536]; int n; while ((n = in.read(bf)) > 0) o.write(bf, 0, n);
        }
    }

    File uniq(File d) {
        if (!d.exists()) return d;
        String n = d.getName(); int i = n.lastIndexOf('.'); String b = i > 0 ? n.substring(0, i) : n, e = i > 0 ? n.substring(i) : "";
        for (int k = 2; ; k++) { File f = new File(d.getParentFile(), b + " (" + k + ")" + e); if (!f.exists()) return f; }
    }

    void paste() {
        List<File> c = new ArrayList<>(clip); boolean ct = cut; File to = cur; clip.clear();
        bg(() -> { for (File f : c) { File d = uniq(new File(to, f.getName())); if (ct) { if (!f.renameTo(d)) { copy(f, d); del(f); } } else copy(f, d); } }, ct ? "Dipindahkan" : "Disalin");
    }

    void extract(File z) {
        File out = uniq(new File(z.getParentFile(), z.getName().replaceFirst("\\.[^.]+$", "")));
        bg(() -> {
            out.mkdirs(); String base = out.getCanonicalPath() + "/";
            try (ZipInputStream zi = new ZipInputStream(new FileInputStream(z))) {
                ZipEntry e; byte[] bf = new byte[65536];
                while ((e = zi.getNextEntry()) != null) {
                    File f = new File(out, e.getName());
                    if (!f.getCanonicalPath().startsWith(base)) continue;
                    if (e.isDirectory()) { f.mkdirs(); continue; }
                    f.getParentFile().mkdirs();
                    try (OutputStream o = new FileOutputStream(f)) { int n; while ((n = zi.read(bf)) > 0) o.write(bf, 0, n); }
                }
            }
        }, "Diekstrak ke folder " + out.getName());
    }

    Uri uri(File f) { return FileProvider.getUriForFile(this, getPackageName() + ".fp", f); }
    String ext(File f) { String n = f.getName(); int i = n.lastIndexOf('.'); return i < 0 ? "" : n.substring(i + 1).toLowerCase(); }

    void open(File f) {
        if (f.isDirectory()) { cur = f; search.setText(""); load(); return; }
        if (ext(f).equals("apk")) { install(f); return; }
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(f));
        try { Intent i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(uri(f), m == null ? "*/*" : m); i.addFlags(1); startActivity(i); }
        catch (Exception e) { toast("Tidak ada aplikasi untuk membuka file ini"); }
    }

    void install(File f) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            toast("Izinkan Fileku memasang aplikasi, lalu coba lagi");
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()))); return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(uri(f), "application/vnd.android.package-archive"); i.addFlags(1); startActivity(i);
    }

    void share() {
        List<File> l = new ArrayList<>(sel); boolean dir = false;
        for (File f : l) if (f.isDirectory()) dir = true;
        if (!dir) { doShare(l); return; }
        toast("Folder dikompres jadi ZIP dulu…");
        new Thread(() -> {
            try {
                List<File> r = new ArrayList<>(); File tmp = new File(getCacheDir(), "share"); del(tmp); tmp.mkdirs();
                for (File f : l) {
                    if (f.isFile()) r.add(f);
                    else { File z = new File(tmp, f.getName() + ".zip"); try (ZipOutputStream o = new ZipOutputStream(new FileOutputStream(z))) { addZip(o, f, f.getName()); } r.add(z); }
                }
                h.post(() -> doShare(r));
            } catch (Exception e) { h.post(() -> toast("Gagal: " + e.getMessage())); }
        }).start();
    }

    void addZip(ZipOutputStream o, File f, String n) throws IOException {
        if (f.isDirectory()) { File[] a = f.listFiles(); if (a != null) for (File c : a) addZip(o, c, n + "/" + c.getName()); }
        else {
            o.putNextEntry(new ZipEntry(n));
            try (InputStream in = new FileInputStream(f)) { byte[] bf = new byte[65536]; int k; while ((k = in.read(bf)) > 0) o.write(bf, 0, k); }
            o.closeEntry();
        }
    }

    void doShare(List<File> l) {
        ArrayList<Uri> u = new ArrayList<>(); String mt = null;
        for (File f : l) {
            u.add(uri(f));
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(f)); if (m == null) m = "application/octet-stream";
            if (mt == null) mt = m;
            else if (!mt.equals(m)) mt = mt.split("/")[0].equals(m.split("/")[0]) ? mt.split("/")[0] + "/*" : "*/*";
        }
        Intent i = new Intent(u.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE); i.setType(mt);
        if (u.size() == 1) i.putExtra(Intent.EXTRA_STREAM, u.get(0)); else i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, u);
        ClipData cd = ClipData.newRawUri("file", u.get(0)); for (int k = 1; k < u.size(); k++) cd.addItem(new ClipData.Item(u.get(k)));
        i.setClipData(cd); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Bagikan lewat"));
    }

    void info(File f) {
        String s = "Nama: " + f.getName() + "\nLokasi: " + f.getParent() + "\nUkuran: " + fmt(size(f)) + "\nDiubah: " + date(f);
        new AlertDialog.Builder(this).setTitle("Info").setMessage(s).setPositiveButton("OK", null).show();
    }
    long size(File f) { if (f.isFile()) return f.length(); long t = 0; File[] a = f.listFiles(); if (a != null) for (File c : a) t += size(c); return t; }
    String date(File f) { return new SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(new Date(f.lastModified())); }
    String fmt(long b) {
        if (b < 1024) return b + " B"; double v = b / 1024.0; String[] u = {"KB", "MB", "GB", "TB"}; int i = 0;
        while (v >= 1024 && i < 3) { v /= 1024; i++; } return String.format(Locale.getDefault(), "%.1f %s", v, u[i]);
    }

    int color(String e) {
        switch (e) {
            case "zip": case "jar": return 0xFFFF6F00;
            case "rar": return 0xFF8E24AA;
            case "7z": case "tar": case "gz": return 0xFF00897B;
            case "pdf": return 0xFFE53935;
            case "doc": case "docx": return 0xFF1E88E5;
            case "xls": case "xlsx": case "csv": return 0xFF2E7D32;
            case "ppt": case "pptx": return 0xFFEF6C00;
            case "txt": case "log": return 0xFF78909C;
            case "mp3": case "wav": case "m4a": case "ogg": case "flac": return 0xFFEC407A;
            case "mp4": case "mkv": case "avi": case "3gp": case "webm": return 0xFF5E35B1;
            case "apk": return 0xFF43A047;
            case "html": case "htm": case "js": case "json": case "xml": return 0xFF039BE5;
            default: return 0xFF607D8B;
        }
    }

    Bitmap icon(File f) {
        String k = f.getPath() + f.lastModified(); Bitmap b = cache.get(k); if (b != null) return b;
        int S = dp(48); b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); String e = ext(f);
        if (f.isDirectory()) {
            p.setColor(0xFFFFA000); c.drawRoundRect(new RectF(S * .04f, S * .16f, S * .46f, S * .5f), S * .06f, S * .06f, p);
            p.setColor(0xFFFFCA28); c.drawRoundRect(new RectF(S * .04f, S * .28f, S * .96f, S * .86f), S * .1f, S * .1f, p);
            p.setColor(0xFFFFE082); c.drawRoundRect(new RectF(S * .04f, S * .28f, S * .96f, S * .4f), S * .08f, S * .08f, p);
        } else {
            Bitmap x = IMG.contains(e) ? thumb(f, S) : e.equals("apk") ? apkIcon(f, S) : null;
            if (x != null) c.drawBitmap(x, null, new RectF(S * .04f, S * .04f, S * .96f, S * .96f), p);
            else {
                p.setColor(color(e)); c.drawRoundRect(new RectF(S * .1f, S * .04f, S * .9f, S * .96f), S * .14f, S * .14f, p);
                p.setColor(-1); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD);
                String L = e.isEmpty() ? "FILE" : e.toUpperCase(); if (L.length() > 4) L = L.substring(0, 4);
                p.setTextSize(S * (L.length() > 3 ? .22f : .3f)); c.drawText(L, S / 2f, S * .6f, p);
            }
        }
        cache.put(k, b); return b;
    }

    Bitmap thumb(File f, int S) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeFile(f.getPath(), o);
            if (o.outWidth <= 0) return null;
            o.inSampleSize = Math.max(1, Math.min(o.outWidth, o.outHeight) / S); o.inJustDecodeBounds = false;
            Bitmap s = BitmapFactory.decodeFile(f.getPath(), o); return s == null ? null : ThumbnailUtils.extractThumbnail(s, S, S);
        } catch (Throwable t) { return null; }
    }

    Bitmap apkIcon(File f, int S) {
        try {
            PackageManager pm = getPackageManager(); PackageInfo pi = pm.getPackageArchiveInfo(f.getPath(), 0); if (pi == null) return null;
            ApplicationInfo ai = pi.applicationInfo; ai.sourceDir = f.getPath(); ai.publicSourceDir = f.getPath();
            Drawable d = ai.loadIcon(pm); Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
            d.setBounds(0, 0, S, S); d.draw(new Canvas(b)); return b;
        } catch (Throwable t) { return null; }
    }

    class FA extends BaseAdapter {
        public int getCount() { return shown.size(); }
        public Object getItem(int i) { return shown.get(i); }
        public long getItemId(int i) { return i; }
        public View getView(int i, View cv, ViewGroup parent) {
            File f = shown.get(i); Context x = MainActivity.this;
            LinearLayout row = new LinearLayout(x); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(14), dp(8), dp(14), dp(8));
            ImageView im = new ImageView(x); im.setImageBitmap(icon(f)); row.addView(im, new LinearLayout.LayoutParams(dp(48), dp(48)));
            LinearLayout col = new LinearLayout(x); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(14), 0, dp(8), 0);
            TextView n = new TextView(x); n.setText(f.getName()); n.setTextSize(16); n.setTextColor(0xFF212121); n.setSingleLine(true); n.setEllipsize(TextUtils.TruncateAt.MIDDLE);
            TextView s = new TextView(x); s.setTextSize(12); s.setTextColor(0xFF78909C);
            if (f.isDirectory()) { String[] a = f.list(); s.setText((a == null ? 0 : a.length) + " item • " + date(f)); }
            else if (catFiles != null) s.setText(fmt(f.length()) + " • " + date(f) + " • " + f.getParentFile().getName());
            else s.setText(fmt(f.length()) + " • " + date(f));
            col.addView(n); col.addView(s); row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            if (sel.contains(f)) {
                row.setBackgroundColor(0xFFBBDEFB);
                TextView ck = new TextView(x); ck.setText("✔"); ck.setTextSize(20); ck.setTextColor(BLUE); row.addView(ck);
            }
            return row;
        }
    }
}
