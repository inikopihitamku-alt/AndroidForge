package id.radiotegal.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0e0805"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                      // menyimpan daftar channel
        s.setMediaPlaybackRequiresUserGesture(false);      // pindah ke mode langsung tanpa ketuk ulang
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);                                // tata letak tidak berubah oleh ukuran font HP

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Tombol kembali: tutup daftar channel dulu; jika sudah tertutup, radio tetap berjalan di belakang. */
    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
            "(function(){var s=document.getElementById('sheet');"
            + "if(s&&s.classList.contains('open')){s.classList.remove('open');return true}return false})()",
            result -> {
                if (!"true".equals(result)) {
                    moveTaskToBack(true);
                }
            });
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
