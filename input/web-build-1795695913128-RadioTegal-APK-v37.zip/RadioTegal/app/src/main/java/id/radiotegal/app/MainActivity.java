package id.radiotegal.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ActivityCompat;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0e0805"));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                      // menyimpan daftar channel
        s.setMediaPlaybackRequiresUserGesture(false);      // pindah ke mode langsung tanpa ketuk ulang
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);                                // tata letak tidak berubah oleh ukuran font HP

        // KUNCI perbaikan: proses renderer WebView (tempat suara diproses) tetap
        // berprioritas tinggi walau aplikasi di belakang layar, sehingga tidak "dicekik" sistem.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false);
        }

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new PlaybackBridge(), "Android");

        RadioEngine.setStateListener(state -> web.evaluateJavascript(
                "window.onNativeState&&window.onNativeState('" + state + "')", null));

        RadioEngine.setCommandListener(cmd -> web.evaluateJavascript(
                "window.onNativeCmd&&window.onNativeCmd('" + cmd + "')", null));

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Dipanggil dari index.html lewat Android.setPlaying(...) tiap kali status putar berubah. */
    private class PlaybackBridge {
        /** Putar stasiun lewat pemutar native (ExoPlayer + DSP). */
        @JavascriptInterface
        public void nativePlay(String url, String name) {
            Intent i = new Intent(MainActivity.this, PlaybackService.class);
            i.setAction(PlaybackService.ACTION_PLAY);
            i.putExtra(PlaybackService.EXTRA_URL, url);
            i.putExtra(PlaybackService.EXTRA_NAME, name);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
            else startService(i);
        }

        /** Jeda / lanjut dari lampu tengah di layar (sama seperti tombol di notifikasi). */
        @JavascriptInterface
        public void nativePause() { RadioEngine.pause(); }

        @JavascriptInterface
        public void nativeResume() { RadioEngine.resume(); }

        @JavascriptInterface
        public void nativeStop() {
            startService(new Intent(MainActivity.this, PlaybackService.class).setAction(PlaybackService.ACTION_STOP));
        }

        /** Dipanggil dari index.html tiap volume / knob EQ berubah. */
        @JavascriptInterface
        public void setSound(float vol, float low, float mid, float high) {
            RadioEngine.setSound(vol, low, mid, high);
        }

        /** Stereo width: true = nyala (lembut), false = mati. */
        @JavascriptInterface
        public void setWide(boolean on) {
            RadioEngine.setWide(on);
        }

        /** "kiri,kanan,bass,limiter" untuk meter. */
        @JavascriptInterface
        public String levels() {
            return RadioEngine.levels();
        }

        /** Kompatibilitas lama: false = hentikan. */
        @JavascriptInterface
        public void setPlaying(boolean playing) {
            if (!playing) nativeStop();
        }
    }

    /** Tombol kembali: tutup daftar channel dulu; jika sudah tertutup, radio tetap berjalan di belakang. */
    @Override
    public void onBackPressed() {
        web.evaluateJavascript(
            "(function(){var s=document.getElementById('sheet');"
            + "if(s&&s.classList.contains('open')){s.classList.remove('open');return true}return false})()",
            result -> {
                if (!"true".equals(result)) {
                    moveTaskToBack(true);
                }
            });
    }

    @Override
    protected void onDestroy() {
        RadioEngine.setStateListener(null);
        RadioEngine.setCommandListener(null);
        web.destroy();
        startService(new Intent(this, PlaybackService.class).setAction(PlaybackService.ACTION_STOP));
        super.onDestroy();
    }
}
