package com.fileku.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;

/** Gambar kecil buatan sendiri: ikon folder 3D ala screenshot, diagram pie, dan bar penyimpanan. */
final class Art {
    private Art() {}

    /** Ikon folder krem/oranye. items=true menampilkan kertas putih di dalam folder. badgeRes=0 berarti tanpa lencana. */
    static Bitmap folder(Context ctx, int S, boolean items, int badgeRes) {
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        final float sc = 0.94f * S / 262f, tx = 0.03f * S, ty = 0.05f * S;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        c.save();
        c.translate(tx, ty);
        c.scale(sc, sc);

        // panel belakang
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFD29447);
        p.setPathEffect(new CornerPathEffect(14));
        Path back = new Path();
        back.moveTo(21, 0); back.lineTo(242, 0); back.lineTo(242, 140); back.lineTo(21, 140); back.close();
        c.drawPath(back, p);

        // kertas
        if (items) {
            for (int i = 0; i < 3; i++) {
                float top = 26 + 12 * i;
                Path sheet = new Path();
                sheet.moveTo(8, top); sheet.lineTo(228, top); sheet.lineTo(228, 120); sheet.lineTo(8, 120); sheet.close();
                p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFFFFF); p.setPathEffect(new CornerPathEffect(8));
                c.drawPath(sheet, p);
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.5f); p.setColor(0xFFD9D9D9);
                c.drawPath(sheet, p);
            }
        }

        // panel depan
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFE2AC62);
        p.setPathEffect(new CornerPathEffect(16));
        Path front = new Path();
        front.moveTo(0, 63); front.lineTo(112, 63); front.lineTo(150, 24); front.lineTo(262, 24);
        front.lineTo(262, 228); front.lineTo(0, 228); front.close();
        c.drawPath(front, p);
        c.restore();

        // lencana (Bluetooth, DCIM, Download, dst.)
        if (badgeRes != 0) {
            RectF r = new RectF(tx + 55 * sc, ty + 88 * sc, tx + 207 * sc, ty + 240 * sc);
            p.setPathEffect(null);
            p.setStyle(Paint.Style.FILL); p.setColor(0xFFFFFFFF);
            c.drawRoundRect(r, 24 * sc, 24 * sc, p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.max(1f, 2 * sc)); p.setColor(0xFFD0D0D0);
            c.drawRoundRect(r, 24 * sc, 24 * sc, p);
            Drawable d = ctx.getDrawable(badgeRes);
            if (d != null) {
                d.setBounds(Math.round(tx + 75 * sc), Math.round(ty + 108 * sc), Math.round(tx + 187 * sc), Math.round(ty + 220 * sc));
                d.draw(c);
            }
        }
        return b;
    }

    /** Lingkaran kecil: bagian terpakai gelap, sisa abu-abu muda. */
    static class Pie extends View {
        int pct;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final RectF r = new RectF();

        Pie(Context c) { super(c); }

        void set(int pct) { this.pct = Math.max(0, Math.min(100, pct)); invalidate(); }

        @Override protected void onDraw(Canvas c) {
            float d = Math.min(getWidth(), getHeight());
            float l = (getWidth() - d) / 2f, t = (getHeight() - d) / 2f;
            r.set(l, t, l + d, t + d);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF9E9E9E);
            c.drawArc(r, 0, 360, true, p);
            p.setColor(0xFF444444);
            if (pct >= 100) c.drawArc(r, 0, 360, true, p);
            else c.drawArc(r, -90, pct * 3.6f, true, p);
        }
    }

    /** Garis progres tipis untuk pemakaian penyimpanan. */
    static class Bar extends View {
        final int pct;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Bar(Context c, int pct) { super(c); this.pct = Math.max(0, Math.min(100, pct)); }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setColor(0xFFE3EDF9);
            c.drawRoundRect(0, 0, w, h, h / 2f, h / 2f, p);
            p.setColor(0xFF4485DF);
            c.drawRoundRect(0, 0, Math.max(h, w * pct / 100f), h, h / 2f, h / 2f, p);
        }
    }
}
