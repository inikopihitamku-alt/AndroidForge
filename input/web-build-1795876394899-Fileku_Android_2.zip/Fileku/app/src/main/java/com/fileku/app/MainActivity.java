package com.fileku.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class MainActivity extends Activity {
    // ---- warna (diambil dari screenshot) ----
    static final int TEAL = 0xFF018578, DARK = 0xFF212121, BG = 0xFFFAFAFA, LINE = 0xFFDBDBDB, SUB = 0xFF727272;
    static final int BLUE = 0xFF1E88E5, GREEN = 0xFF43A047, ORANGE = 0xFFFB8C00, RED = 0xFFE53935, GREY = 0xFF546E7A;
    static final int SEL_BG = 0xFFCCE7E4;

    static final List<String> IMG = Arrays.asList("jpg", "jpeg", "png", "gif", "webp", "bmp");
    static final List<String> AUD = Arrays.asList("mp3", "wav", "m4a", "ogg", "flac", "aac", "amr", "opus");
    static final List<String> VID = Arrays.asList("mp4", "mkv", "avi", "3gp", "webm", "mov");
    static final List<String> DOC = Arrays.asList("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "epub");
    static final List<String> APK = Arrays.asList("apk", "xapk", "apks");
    static final String[] SORT_NAMES = {"Nama", "Ukuran", "Tanggal diubah", "Tipe"};

    static final int M_HOME = 0, M_DIR = 1, M_CAT = 2, M_TRASH = 3;

    interface Job { void run() throws Exception; }

    /** Pengaturan tampilan: layout (0 daftar, 1 kisi, 2 daftar rinci), ukuran ikon, urutan. */
    static class Cfg {
        int layout, thumb, sort;
        boolean asc = true;

        String ser() { return layout + "," + thumb + "," + sort + "," + (asc ? 1 : 0); }

        static Cfg parse(String s) {
            Cfg c = new Cfg();
            if (s == null) return c;
            try {
                String[] a = s.split(",");
                c.layout = Integer.parseInt(a[0]); c.thumb = Integer.parseInt(a[1]);
                c.sort = Integer.parseInt(a[2]); c.asc = a[3].equals("1");
            } catch (Exception e) { return new Cfg(); }
            return c;
        }
    }

    static class Holder {
        View root; ImageView icon; TextView name, sub, date, chk;
        String key = ""; int S;
    }

    // ---- state ----
    int mode = M_HOME;
    File root = Environment.getExternalStorageDirectory(), cur = root;
    List<File> shown = new ArrayList<>(), clip = new ArrayList<>(), catFiles;
    Set<File> sel = new LinkedHashSet<>();
    boolean cut, hidden, searching, scanning, drawerOpen;
    String catTitle = "", cfgFor = "";
    int scanId, drawerTab, drawerW;
    long trashSize;
    Cfg cfg = new Cfg();
    SharedPreferences prefs;

    // ---- views ----
    FrameLayout frame, titleBox;
    LinearLayout page, tb, actions, crumbs, pill, pasteBar, homeBox, drawer;
    ImageView navBtn;
    TextView title, pillTxt, empty, pasteTxt;
    EditText searchEt;
    HorizontalScrollView crumbHs;
    Art.Pie pie;
    ListView lv; GridView gv; ScrollView homeSv;
    View scrim;
    FA ad = new FA();

    Handler h = new Handler(Looper.getMainLooper());
    LruCache<String, Bitmap> cache = new LruCache<>(300);
    LruCache<String, Integer> counts = new LruCache<>(1500);
    ExecutorService pool = Executors.newFixedThreadPool(3);
    SimpleDateFormat DF = new SimpleDateFormat("d MMM yyyy", Locale.getDefault());
    SimpleDateFormat DTF = new SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault());

    int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    Drawable ic(int res, int tint) {
        Drawable d = getDrawable(res).mutate();
        if (tint != 0) d.setTint(tint);
        return d;
    }
    Drawable ripple(int bg, int rip) {
        return new RippleDrawable(ColorStateList.valueOf(rip), new ColorDrawable(bg), null);
    }
    TextView tv(String t, int sp, int color) {
        TextView x = new TextView(this); x.setText(t); x.setTextSize(sp); x.setTextColor(color); return x;
    }
    View line(int color) { View v = new View(this); v.setBackgroundColor(color); return v; }

    // =====================================================================
    //  Siklus hidup
    // =====================================================================
    @Override protected void onCreate(Bundle sb) {
        super.onCreate(sb);
        prefs = getSharedPreferences("fileku", MODE_PRIVATE);
        hidden = prefs.getBoolean("hidden", false);
        getWindow().setStatusBarColor(0xFF000000);
        buildUi();
        if (!hasAccess()) askPermission();
        refreshTrashSize();
    }

    @Override protected void onResume() { super.onResume(); load(); refreshTrashSize(); }

    @Override protected void onDestroy() { pool.shutdownNow(); super.onDestroy(); }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] g) {
        super.onRequestPermissionsResult(c, p, g); load();
    }

    @Override public void onConfigurationChanged(Configuration nc) {
        super.onConfigurationChanged(nc);
        drawerW = Math.min(dp(320), Math.round(getResources().getDisplayMetrics().widthPixels * 0.78f));
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) drawer.getLayoutParams();
        lp.width = drawerW; drawer.setLayoutParams(lp);
        if (!drawerOpen) drawer.setTranslationX(-drawerW);
        applyLayout();
    }

    @Override public void onBackPressed() {
        if (drawerOpen) closeDrawer();
        else if (searching) setSearch(false);
        else if (!sel.isEmpty()) { sel.clear(); load(); }
        else if (mode == M_HOME) super.onBackPressed();
        else if (mode == M_DIR && !cur.equals(root) && cur.getParentFile() != null) go(cur.getParentFile(), false);
        else showHome();
    }

    boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED;
    }

    void askPermission() {
        if (Build.VERSION.SDK_INT >= 30) {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()))); }
            catch (Exception e) { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
        } else requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
    }

    // geser dari tepi kiri untuk membuka drawer, geser ke kiri untuk menutup
    float tx0, ty0; boolean edge;
    @Override public boolean dispatchTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) { tx0 = e.getRawX(); ty0 = e.getRawY(); edge = !drawerOpen && tx0 < dp(20); }
        else if (a == MotionEvent.ACTION_MOVE) {
            float dx = e.getRawX() - tx0, dy = Math.abs(e.getRawY() - ty0);
            boolean open = edge && dx > dp(40) && dx > dy * 1.5f;
            boolean close = drawerOpen && -dx > dp(40) && -dx > dy * 1.5f && tx0 < drawerW;
            if (open || close) {
                edge = false;
                MotionEvent c = MotionEvent.obtain(e); c.setAction(MotionEvent.ACTION_CANCEL);
                super.dispatchTouchEvent(c); c.recycle();
                if (open) openDrawer(); else closeDrawer();
                return true;
            }
        }
        return super.dispatchTouchEvent(e);
    }

    // =====================================================================
    //  Susunan layar
    // =====================================================================
    void buildUi() {
        frame = new FrameLayout(this); frame.setBackgroundColor(-1);
        page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);

        // --- toolbar gelap ---
        tb = new LinearLayout(this); tb.setGravity(Gravity.CENTER_VERTICAL); tb.setBackgroundColor(DARK);
        navBtn = new ImageView(this); navBtn.setScaleType(ImageView.ScaleType.CENTER);
        navBtn.setBackground(ripple(0, 0x33FFFFFF));
        title = tv("", 20, -1); title.setTypeface(null, Typeface.BOLD); title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END); title.setGravity(Gravity.CENTER_VERTICAL); title.setPadding(dp(16), 0, 0, 0);
        searchEt = new EditText(this); searchEt.setHint("Cari…"); searchEt.setHintTextColor(0x99FFFFFF); searchEt.setTextColor(-1);
        searchEt.setTextSize(18); searchEt.setSingleLine(true); searchEt.setBackground(null);
        searchEt.setInputType(InputType.TYPE_CLASS_TEXT); searchEt.setPadding(dp(16), 0, dp(4), 0); searchEt.setVisibility(View.GONE);
        searchEt.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence a, int x, int y, int z) {}
            public void onTextChanged(CharSequence a, int x, int y, int z) {}
            public void afterTextChanged(Editable e) { if (searching) load(); }
        });
        titleBox = new FrameLayout(this);
        titleBox.addView(title, new FrameLayout.LayoutParams(-1, -1));
        titleBox.addView(searchEt, new FrameLayout.LayoutParams(-1, -1));
        actions = new LinearLayout(this); actions.setGravity(Gravity.CENTER_VERTICAL);
        tb.addView(navBtn, new LinearLayout.LayoutParams(dp(56), dp(56)));
        tb.addView(titleBox, new LinearLayout.LayoutParams(0, dp(56), 1));
        tb.addView(actions, new LinearLayout.LayoutParams(-2, dp(56)));

        // --- breadcrumb + indikator pemakaian ---
        LinearLayout crumbBar = new LinearLayout(this); crumbBar.setGravity(Gravity.CENTER_VERTICAL); crumbBar.setBackgroundColor(-1);
        crumbHs = new HorizontalScrollView(this); crumbHs.setHorizontalScrollBarEnabled(false);
        crumbs = new LinearLayout(this); crumbs.setGravity(Gravity.CENTER_VERTICAL); crumbs.setPadding(dp(8), 0, dp(8), 0);
        crumbHs.addView(crumbs, new FrameLayout.LayoutParams(-2, -1));
        pill = new LinearLayout(this); pill.setGravity(Gravity.CENTER_VERTICAL); pill.setPadding(dp(8), dp(3), dp(10), dp(3));
        GradientDrawable pg = new GradientDrawable(); pg.setColor(-1); pg.setStroke(Math.max(1, dp(1)), 0xFF6F6F6F); pg.setCornerRadius(dp(5));
        pill.setBackground(pg);
        pie = new Art.Pie(this);
        pillTxt = tv("", 14, 0xFF434343); pillTxt.setTypeface(null, Typeface.BOLD); pillTxt.setSingleLine(true);
        pill.addView(pie, new LinearLayout.LayoutParams(dp(22), dp(22)));
        LinearLayout.LayoutParams ptp = new LinearLayout.LayoutParams(-2, -2); ptp.leftMargin = dp(6);
        pill.addView(pillTxt, ptp);
        crumbBar.addView(crumbHs, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(-2, -2); pl.rightMargin = dp(8); pl.leftMargin = dp(4);
        crumbBar.addView(pill, pl);

        // --- isi: daftar, kisi, beranda ---
        FrameLayout content = new FrameLayout(this); content.setBackgroundColor(BG);
        lv = new ListView(this); lv.setDivider(new ColorDrawable(LINE)); lv.setDividerHeight(Math.max(1, dp(1)));
        lv.setSelector(new ColorDrawable(0)); lv.setCacheColorHint(0); lv.setBackgroundColor(BG);
        gv = new GridView(this); gv.setSelector(new ColorDrawable(0)); gv.setBackgroundColor(BG); gv.setVerticalSpacing(dp(2));
        AdapterView.OnItemClickListener ocl = (p, v, i, id) -> { if (i < shown.size()) itemClick(shown.get(i)); };
        AdapterView.OnItemLongClickListener olc = (p, v, i, id) -> { if (i < shown.size()) toggle(shown.get(i)); return true; };
        lv.setOnItemClickListener(ocl); lv.setOnItemLongClickListener(olc);
        gv.setOnItemClickListener(ocl); gv.setOnItemLongClickListener(olc);
        homeSv = new ScrollView(this); homeSv.setBackgroundColor(-1);
        homeBox = new LinearLayout(this); homeBox.setOrientation(LinearLayout.VERTICAL); homeBox.setPadding(0, 0, 0, dp(16));
        homeSv.addView(homeBox);
        empty = tv("", 16, SUB); empty.setGravity(Gravity.CENTER); empty.setPadding(dp(24), dp(24), dp(24), dp(24)); empty.setVisibility(View.GONE);
        empty.setOnClickListener(v -> { if (!hasAccess()) askPermission(); });
        content.addView(lv, new FrameLayout.LayoutParams(-1, -1));
        content.addView(gv, new FrameLayout.LayoutParams(-1, -1));
        content.addView(homeSv, new FrameLayout.LayoutParams(-1, -1));
        content.addView(empty, new FrameLayout.LayoutParams(-1, -1));

        // --- bar tempel di bawah ---
        pasteBar = new LinearLayout(this); pasteBar.setGravity(Gravity.CENTER_VERTICAL); pasteBar.setBackgroundColor(DARK);
        pasteBar.setPadding(dp(16), 0, dp(8), 0); pasteBar.setVisibility(View.GONE);
        pasteTxt = tv("", 15, -1);
        TextView pb = tv("TEMPEL", 15, 0xFF4DB6AC); pb.setTypeface(null, Typeface.BOLD); pb.setPadding(dp(14), dp(14), dp(14), dp(14));
        pb.setOnClickListener(v -> paste());
        TextView cb = tv("BATAL", 15, 0xFFBDBDBD); cb.setTypeface(null, Typeface.BOLD); cb.setPadding(dp(14), dp(14), dp(14), dp(14));
        cb.setOnClickListener(v -> { clip.clear(); updatePasteBar(); });
        pasteBar.addView(pasteTxt, new LinearLayout.LayoutParams(0, -2, 1));
        pasteBar.addView(pb); pasteBar.addView(cb);

        page.addView(tb, new LinearLayout.LayoutParams(-1, -2));
        page.addView(crumbBar, new LinearLayout.LayoutParams(-1, dp(44)));
        page.addView(line(0xFFCCCCCC), new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))));
        page.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));
        page.addView(pasteBar, new LinearLayout.LayoutParams(-1, dp(52)));
        frame.addView(page, new FrameLayout.LayoutParams(-1, -1));

        // --- drawer samping ---
        scrim = new View(this); scrim.setBackgroundColor(0x99000000); scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> closeDrawer());
        frame.addView(scrim, new FrameLayout.LayoutParams(-1, -1));
        drawerW = Math.min(dp(320), Math.round(getResources().getDisplayMetrics().widthPixels * 0.78f));
        drawer = new LinearLayout(this); drawer.setOrientation(LinearLayout.VERTICAL); drawer.setBackgroundColor(-1);
        drawer.setClickable(true); drawer.setVisibility(View.GONE); drawer.setTranslationX(-drawerW);
        frame.addView(drawer, new FrameLayout.LayoutParams(drawerW, -1));

        setContentView(frame);
    }

    // =====================================================================
    //  Toolbar
    // =====================================================================
    void setNav(int res, View.OnClickListener l) { navBtn.setImageDrawable(ic(res, -1)); navBtn.setOnClickListener(l); }

    void addAct(int res, View.OnClickListener l) {
        ImageView b = new ImageView(this); b.setImageDrawable(ic(res, -1)); b.setScaleType(ImageView.ScaleType.CENTER);
        b.setBackground(ripple(0, 0x33FFFFFF)); b.setOnClickListener(l);
        actions.addView(b, new LinearLayout.LayoutParams(dp(48), dp(56)));
    }

    String titleText() {
        if (!sel.isEmpty()) return sel.size() + " dipilih";
        if (mode == M_HOME) return "Beranda";
        if (mode == M_CAT) return catTitle;
        if (mode == M_TRASH) return "Keranjang Sampah";
        return cur.equals(root) ? label(root) : cur.getName();
    }

    void refreshToolbar() {
        actions.removeAllViews();
        boolean selMode = !sel.isEmpty();
        title.setText(titleText());
        if (selMode) {
            setNav(R.drawable.ic_close, v -> { sel.clear(); load(); });
            if (mode == M_TRASH) {
                addAct(R.drawable.ic_history, v -> restoreSel());
                addAct(R.drawable.ic_delete, v -> deleteForever(new ArrayList<>(sel)));
            } else {
                addAct(R.drawable.ic_copy, v -> doClip(false));
                addAct(R.drawable.ic_cut, v -> doClip(true));
                addAct(R.drawable.ic_share, v -> share());
                addAct(R.drawable.ic_delete, v -> delete());
            }
            addAct(R.drawable.ic_more, v -> selMenu(v));
            title.setVisibility(View.VISIBLE); searchEt.setVisibility(View.GONE);
        } else if (searching) {
            setNav(R.drawable.ic_back, v -> setSearch(false));
            addAct(R.drawable.ic_close, v -> searchEt.setText(""));
            title.setVisibility(View.GONE); searchEt.setVisibility(View.VISIBLE);
        } else {
            setNav(R.drawable.ic_menu, v -> openDrawer());
            if (mode != M_HOME) {
                addAct(R.drawable.ic_search, v -> setSearch(true));
                addAct(R.drawable.ic_tune, v -> showViewSheet());
            }
            addAct(R.drawable.ic_more, v -> mainMenu(v));
            title.setVisibility(View.VISIBLE); searchEt.setVisibility(View.GONE);
        }
    }

    void setSearch(boolean on) {
        searching = on;
        searchEt.setText("");
        refreshToolbar();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (on) { searchEt.requestFocus(); if (imm != null) imm.showSoftInput(searchEt, InputMethodManager.SHOW_IMPLICIT); }
        else if (imm != null) imm.hideSoftInputFromWindow(searchEt.getWindowToken(), 0);
        load();
    }

    void closeSearchQuiet() {
        if (!searching) return;
        searching = false; searchEt.setText("");
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(searchEt.getWindowToken(), 0);
    }

    // =====================================================================
    //  Breadcrumb
    // =====================================================================
    void addCrumbIcon(int res, View.OnClickListener l) {
        ImageView i = new ImageView(this); i.setImageDrawable(ic(res, 0)); i.setScaleType(ImageView.ScaleType.FIT_CENTER);
        i.setOnClickListener(l);
        crumbs.addView(i, new LinearLayout.LayoutParams(dp(32), dp(32)));
    }

    void addChevron() {
        ImageView i = new ImageView(this); i.setImageDrawable(ic(R.drawable.ic_chevron, 0)); i.setScaleType(ImageView.ScaleType.FIT_CENTER);
        crumbs.addView(i, new LinearLayout.LayoutParams(dp(22), dp(22)));
    }

    void addCrumbText(String t, View.OnClickListener l, boolean bold) {
        TextView x = tv(t, 16, 0xFF212121); x.setSingleLine(true); x.setPadding(dp(6), dp(6), dp(6), dp(6));
        if (bold) x.setTypeface(null, Typeface.BOLD);
        if (l != null) x.setOnClickListener(l);
        crumbs.addView(x, new LinearLayout.LayoutParams(-2, -2));
    }

    void buildCrumbs() {
        crumbs.removeAllViews();
        addCrumbIcon(R.drawable.ic_home_color, v -> showHome());
        if (mode == M_CAT) { addChevron(); addCrumbText(catTitle, null, true); }
        else if (mode == M_TRASH) { addChevron(); addCrumbText("Keranjang Sampah", null, true); }
        else if (mode == M_DIR) {
            addChevron();
            addCrumbIcon(storageRes(root), v -> go(root, true));
            List<File> chain = new ArrayList<>();
            for (File x = cur; x != null && !x.equals(root) && chain.size() < 40; x = x.getParentFile()) chain.add(0, x);
            for (int i = 0; i < chain.size(); i++) {
                File x = chain.get(i);
                addChevron();
                addCrumbText(x.getName(), v -> go(x, true), i == chain.size() - 1);
            }
        }
        crumbHs.post(() -> crumbHs.fullScroll(View.FOCUS_RIGHT));
    }

    void updatePill() {
        if (mode == M_DIR) {
            int p = pct(root);
            pie.set(p); pillTxt.setText(p + "% DIGUNAKAN"); pill.setVisibility(View.VISIBLE);
        } else pill.setVisibility(View.GONE);
    }

    void updatePasteBar() {
        boolean show = mode == M_DIR && !clip.isEmpty();
        pasteBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) pasteTxt.setText(clip.size() + " item siap " + (cut ? "dipindah" : "disalin"));
    }

    // =====================================================================
    //  Pemuatan daftar
    // =====================================================================
    String cfgKey() {
        if (mode == M_DIR) return "d:" + cur.getAbsolutePath();
        if (mode == M_CAT) return "cat:" + catTitle;
        if (mode == M_TRASH) return "trash";
        return "home";
    }

    Cfg readCfg(String key) {
        String s = prefs.getString("v:" + key, null);
        if (s == null) s = prefs.getString("v:*", null);
        Cfg c = Cfg.parse(s);
        if (s == null && key.startsWith("cat:")) { c.sort = 2; c.asc = false; }
        return c;
    }

    void saveCfg(boolean all) {
        SharedPreferences.Editor e = prefs.edit();
        if (all) {
            e.putString("v:*", cfg.ser());
            for (String k : prefs.getAll().keySet()) if (k.startsWith("v:") && !k.equals("v:*")) e.remove(k);
        } else e.putString("v:" + cfgKey(), cfg.ser());
        e.apply();
    }

    void applyLayout() {
        boolean grid = cfg.layout == 1;
        if (grid) {
            lv.setAdapter(null);
            int w = getResources().getConfiguration().screenWidthDp;
            gv.setNumColumns(Math.max(2, w / (cfg.thumb == 0 ? 92 : 132)));
            gv.setAdapter(ad);
        } else { gv.setAdapter(null); lv.setAdapter(ad); }
    }

    void load() {
        String k = cfgKey();
        if (!k.equals(cfgFor)) { cfgFor = k; cfg = readCfg(k); applyLayout(); }
        boolean home = mode == M_HOME, grid = cfg.layout == 1;
        homeSv.setVisibility(home ? View.VISIBLE : View.GONE);
        lv.setVisibility(!home && !grid ? View.VISIBLE : View.GONE);
        gv.setVisibility(!home && grid ? View.VISIBLE : View.GONE);
        if (home) {
            empty.setVisibility(View.GONE); buildHome();
            refreshToolbar(); buildCrumbs(); updatePill(); updatePasteBar();
            return;
        }
        List<File> src;
        if (mode == M_CAT) { if (catFiles != null) catFiles.removeIf(f -> !f.exists()); src = catFiles == null ? new ArrayList<File>() : catFiles; }
        else {
            File[] a = (mode == M_TRASH ? trashDir() : cur).listFiles();
            src = a == null ? new ArrayList<File>() : Arrays.asList(a);
        }
        String q = searching ? searchEt.getText().toString().toLowerCase().trim() : "";
        List<File> l = new ArrayList<>();
        for (File f : src) {
            String n = f.getName();
            if (!hidden && n.startsWith(".")) continue;
            if (q.isEmpty() || n.toLowerCase().contains(q)) l.add(f);
        }
        try { Collections.sort(l, this::compare); } catch (IllegalArgumentException ignored) { }
        shown = l; sel.retainAll(l); ad.notifyDataSetChanged();

        if (l.isEmpty()) {
            String m = scanning ? "Memindai…" : !hasAccess() ? "Izin akses file belum diberikan.\nKetuk di sini untuk mengizinkan."
                : !q.isEmpty() ? "Tidak ditemukan" : mode == M_TRASH ? "Keranjang sampah kosong" : "Folder kosong";
            empty.setText(m); empty.setVisibility(View.VISIBLE);
        } else empty.setVisibility(View.GONE);
        refreshToolbar(); buildCrumbs(); updatePill(); updatePasteBar();
    }

    int compare(File x, File y) {
        boolean dx = x.isDirectory(), dy = y.isDirectory();
        if (dx != dy) return dx ? -1 : 1;
        int r = 0;
        if (cfg.sort == 1 && !dx) r = Long.compare(x.length(), y.length());
        else if (cfg.sort == 2) r = Long.compare(x.lastModified(), y.lastModified());
        else if (cfg.sort == 3 && !dx) r = ext(x).compareTo(ext(y));
        if (r != 0) return cfg.asc ? r : -r;
        r = x.getName().compareToIgnoreCase(y.getName());
        return (cfg.sort == 0 && !cfg.asc) ? -r : r;
    }

    // =====================================================================
    //  Navigasi
    // =====================================================================
    File volumeOf(File f) {
        String p = f.getPath();
        for (File v : volumes()) if (p.equals(v.getPath()) || p.startsWith(v.getPath() + "/")) return v;
        return Environment.getExternalStorageDirectory();
    }

    void go(File dir, boolean record) {
        closeSearchQuiet();
        if (mode != M_DIR || !(dir.equals(root) || dir.getPath().startsWith(root.getPath() + "/"))) root = volumeOf(dir);
        mode = M_DIR; cur = dir; catFiles = null; scanning = false; scanId++; sel.clear();
        if (record) addRecent(dir);
        load();
    }

    void showHome() {
        closeSearchQuiet();
        mode = M_HOME; catFiles = null; scanning = false; scanId++; sel.clear(); load();
    }

    void openTrash() {
        closeSearchQuiet();
        mode = M_TRASH; catFiles = null; sel.clear(); load();
    }

    void itemClick(File f) {
        if (!sel.isEmpty() || mode == M_TRASH) toggle(f); else open(f);
    }

    void toggle(File f) { if (!sel.remove(f)) sel.add(f); load(); }

    void openCat(String t, List<String> exts, boolean recent) {
        closeSearchQuiet();
        mode = M_CAT; catTitle = t; catFiles = new ArrayList<>(); sel.clear(); scanning = true; final int id = ++scanId;
        load();
        new Thread(() -> {
            List<File> out = new ArrayList<>(); for (File v : volumes()) scan(v, exts, out, 0);
            Collections.sort(out, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
            List<File> res = recent && out.size() > 100 ? new ArrayList<>(out.subList(0, 100)) : out;
            h.post(() -> { if (id == scanId && mode == M_CAT) { catFiles = res; scanning = false; load(); } });
        }).start();
    }

    void scan(File d, List<String> exts, List<File> out, int depth) {
        File[] a = d.listFiles(); if (a == null || depth > 12) return;
        for (File f : a) {
            String n = f.getName(); if (n.startsWith(".")) continue;
            if (f.isDirectory()) { if (!(depth == 0 && n.equals("Android"))) scan(f, exts, out, depth + 1); }
            else if (exts == null || exts.contains(ext(f))) out.add(f);
        }
    }

    // =====================================================================
    //  Penyimpanan
    // =====================================================================
    List<File> volumes() {
        List<File> r = new ArrayList<>(); r.add(Environment.getExternalStorageDirectory());
        File[] a = getExternalFilesDirs(null);
        if (a != null) for (File d : a) {
            if (d == null) continue;
            String p = d.getAbsolutePath(); int i = p.indexOf("/Android/data");
            if (i > 0) { File v = new File(p.substring(0, i)); if (!r.contains(v)) r.add(v); }
        }
        File[] s = new File("/storage").listFiles();
        if (s != null) for (File d : s) {
            String n = d.getName();
            if (!n.equals("emulated") && !n.equals("self") && d.isDirectory() && d.canRead() && !r.contains(d)) r.add(d);
        }
        return r;
    }

    String label(File v) {
        if (v.equals(Environment.getExternalStorageDirectory())) return "Penyimpanan Utama";
        try {
            StorageVolume sv = ((StorageManager) getSystemService(STORAGE_SERVICE)).getStorageVolume(v);
            if (sv != null) {
                String d = sv.getDescription(this);
                if (d != null && d.toLowerCase().contains("usb")) return d;
                if (sv.isRemovable()) return "Kartu SD";
                if (d != null) return d;
            }
        } catch (Exception e) { }
        return v.getName();
    }

    int storageRes(File v) {
        if (v.equals(Environment.getExternalStorageDirectory())) return R.drawable.ic_drive;
        return label(v).toLowerCase().contains("usb") ? R.drawable.ic_drive : R.drawable.ic_sdcard;
    }

    int pct(File v) {
        long t = v.getTotalSpace();
        return t <= 0 ? 0 : (int) Math.round((t - v.getFreeSpace()) * 100.0 / t);
    }

    File trashDir() { return new File(Environment.getExternalStorageDirectory(), ".fileku_trash"); }

    void refreshTrashSize() {
        pool.execute(() -> {
            final long s = size(trashDir());
            h.post(() -> { trashSize = s; if (drawerOpen) buildDrawer(); if (mode == M_HOME) buildHome(); });
        });
    }

    // =====================================================================
    //  Beranda
    // =====================================================================
    View navRow(Drawable icon, String name, String right, int pct, View.OnClickListener click, View.OnLongClickListener lc) {
        LinearLayout wrap = new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(6), dp(6), dp(8), dp(6)); row.setMinimumHeight(dp(52));
        ImageView im = new ImageView(this); im.setImageDrawable(icon); im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        row.addView(im, new LinearLayout.LayoutParams(dp(32), dp(32)));
        LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(8), 0, 0, 0);
        LinearLayout l1 = new LinearLayout(this); l1.setGravity(Gravity.CENTER_VERTICAL);
        TextView n = tv(name, 18, 0xFF000000); n.setSingleLine(true); n.setEllipsize(TextUtils.TruncateAt.END);
        l1.addView(n, new LinearLayout.LayoutParams(0, -2, 1));
        if (right != null) l1.addView(tv(right, 16, 0xFF7F7F7F));
        col.addView(l1);
        if (pct >= 0) {
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(3)); bp.topMargin = dp(8);
            col.addView(new Art.Bar(this, pct), bp);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        wrap.addView(row, new LinearLayout.LayoutParams(-1, -2));
        wrap.addView(line(0xFFE0E0E0), new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))));
        wrap.setBackground(ripple(0xFFFFFFFF, 0x22000000));
        wrap.setOnClickListener(click);
        if (lc != null) wrap.setOnLongClickListener(lc);
        return wrap;
    }

    View tile(String ic, int col, String name, Runnable r) {
        LinearLayout t = new LinearLayout(this); t.setOrientation(LinearLayout.VERTICAL); t.setGravity(Gravity.CENTER_HORIZONTAL); t.setPadding(dp(4), dp(10), dp(4), dp(10));
        TextView i = new TextView(this); i.setText(ic); i.setTextSize(28); i.setGravity(Gravity.CENTER); i.setTextColor(-1);
        GradientDrawable g = new GradientDrawable(); g.setColor(col); g.setCornerRadius(dp(20)); i.setBackground(g);
        t.addView(i, new LinearLayout.LayoutParams(dp(64), dp(64)));
        TextView n = tv(name, 14, 0xFF212121); n.setSingleLine(true); n.setEllipsize(TextUtils.TruncateAt.END); n.setPadding(0, dp(6), 0, 0);
        t.addView(n);
        t.setOnClickListener(v -> r.run());
        return t;
    }

    void buildHome() {
        homeBox.removeAllViews();
        for (File vol : volumes()) {
            int p = pct(vol);
            homeBox.addView(navRow(ic(storageRes(vol), 0), label(vol), p + "%", p, v -> go(vol, true), null));
        }
        final File dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        homeBox.addView(navRow(new BitmapDrawable(getResources(), folderIcon(dl, true, dp(32))), "Unduhan", null, -1, v -> go(dl, true), null));
        homeBox.addView(navRow(ic(R.drawable.ic_trash_color, 0), "Keranjang Sampah", fmt(trashSize), -1, v -> openTrash(), null));

        TextView hd = tv("Kategori", 16, TEAL); hd.setTypeface(null, Typeface.BOLD); hd.setPadding(dp(16), dp(18), 0, dp(4));
        homeBox.addView(hd);
        List<View> ct = new ArrayList<>();
        ct.add(tile("🖼", 0xFF8E24AA, "Gambar", () -> openCat("Gambar", IMG, false)));
        ct.add(tile("🎵", 0xFF00ACC1, "Audio", () -> openCat("Audio", AUD, false)));
        ct.add(tile("🎞", RED, "Video", () -> openCat("Video", VID, false)));
        ct.add(tile("📄", BLUE, "Dokumen", () -> openCat("Dokumen", DOC, false)));
        ct.add(tile("🤖", GREEN, "Aplikasi (APK)", () -> openCat("Aplikasi (APK)", APK, false)));
        ct.add(tile("🕑", GREY, "File Baru", () -> openCat("File Baru", null, true)));
        LinearLayout row = null;
        for (int k = 0; k < ct.size(); k++) {
            if (k % 3 == 0) { row = new LinearLayout(this); row.setPadding(dp(8), 0, dp(8), 0); homeBox.addView(row); }
            row.addView(ct.get(k), new LinearLayout.LayoutParams(0, -2, 1));
        }
    }

    // =====================================================================
    //  Drawer samping
    // =====================================================================
    void openDrawer() {
        if (drawerOpen) return;
        drawerOpen = true; buildDrawer();
        scrim.setVisibility(View.VISIBLE); scrim.setAlpha(0f); drawer.setVisibility(View.VISIBLE);
        drawer.setTranslationX(-drawerW);
        drawer.animate().translationX(0).setDuration(180).start();
        scrim.animate().alpha(1f).setDuration(180).start();
        refreshTrashSize();
    }

    void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        drawer.animate().translationX(-drawerW).setDuration(160).withEndAction(() -> {
            if (!drawerOpen) { drawer.setVisibility(View.GONE); scrim.setVisibility(View.GONE); }
        }).start();
        scrim.animate().alpha(0f).setDuration(160).start();
    }

    void buildDrawer() {
        drawer.removeAllViews();
        int[] tabs = {R.drawable.ic_tab_folder, R.drawable.ic_star, R.drawable.ic_history};
        LinearLayout strip = new LinearLayout(this); strip.setBackgroundColor(BG);
        for (int k = 0; k < 3; k++) {
            final int kk = k;
            ImageView t = new ImageView(this); t.setScaleType(ImageView.ScaleType.CENTER);
            t.setImageDrawable(ic(tabs[k], k == drawerTab ? 0xFF000000 : 0xFF9E9E9E));
            t.setOnClickListener(x -> { drawerTab = kk; buildDrawer(); });
            strip.addView(t, new LinearLayout.LayoutParams(0, dp(52), 1));
        }
        drawer.addView(strip, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout ind = new LinearLayout(this);
        for (int k = 0; k < 3; k++) {
            View seg = new View(this); seg.setBackgroundColor(k == drawerTab ? TEAL : 0);
            ind.addView(seg, new LinearLayout.LayoutParams(0, -1, 1));
        }
        drawer.addView(ind, new LinearLayout.LayoutParams(-1, dp(4)));
        drawer.addView(line(0xFFDDDDDD), new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))));

        ScrollView sv = new ScrollView(this); LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        sv.addView(body);
        drawer.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        if (drawerTab == 0) {
            body.addView(navRow(ic(R.drawable.ic_home_color, 0), "Beranda", null, -1, v -> { closeDrawer(); showHome(); }, null));
            for (File vol : volumes()) {
                int p = pct(vol);
                body.addView(navRow(ic(storageRes(vol), 0), label(vol), p + "%", p, v -> { closeDrawer(); go(vol, true); }, null));
            }
            body.addView(navRow(ic(R.drawable.ic_trash_color, 0), "Keranjang Sampah", fmt(trashSize), -1, v -> { closeDrawer(); openTrash(); }, null));
        } else if (drawerTab == 1) {
            fillPaths(body, "fav", "Belum ada favorit.\nBuka sebuah folder, lalu pilih ⋮ › Tambah ke favorit.");
        } else {
            fillPaths(body, "recent", "Belum ada riwayat.");
        }
    }

    void fillPaths(LinearLayout body, String key, String emptyMsg) {
        boolean any = false;
        for (String s : getList(key)) {
            final File f = new File(s);
            if (!f.exists()) continue;
            any = true;
            Drawable d = new BitmapDrawable(getResources(), f.isDirectory() ? folderIcon(f, true, dp(32)) : extIcon(f, dp(32)));
            View.OnClickListener ck = v -> { closeDrawer(); if (f.isDirectory()) go(f, true); else open(f); };
            View.OnLongClickListener lc = v -> {
                List<String> l = getList(key); l.remove(s); putList(key, l); buildDrawer(); toast("Dihapus dari daftar"); return true;
            };
            body.addView(navRow(d, f.getName().isEmpty() ? f.getPath() : f.getName(), null, -1, ck, lc));
        }
        if (!any) { TextView t = tv(emptyMsg, 15, SUB); t.setPadding(dp(16), dp(24), dp(16), 0); body.addView(t); }
    }

    List<String> getList(String key) {
        List<String> l = new ArrayList<>();
        for (String x : prefs.getString(key, "").split("\n")) if (!x.isEmpty()) l.add(x);
        return l;
    }
    void putList(String key, List<String> l) { prefs.edit().putString(key, TextUtils.join("\n", l)).apply(); }
    void addRecent(File f) {
        List<String> l = getList("recent"); l.remove(f.getAbsolutePath()); l.add(0, f.getAbsolutePath());
        while (l.size() > 25) l.remove(l.size() - 1);
        putList("recent", l);
    }
    boolean isFav(File f) { return getList("fav").contains(f.getAbsolutePath()); }
    void toggleFav(File f) {
        List<String> l = getList("fav");
        if (!l.remove(f.getAbsolutePath())) l.add(0, f.getAbsolutePath());
        putList("fav", l); toast(l.contains(f.getAbsolutePath()) ? "Ditambahkan ke favorit" : "Dihapus dari favorit");
    }

    // =====================================================================
    //  Menu ⋮
    // =====================================================================
    void mainMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor); Menu m = pm.getMenu();
        if (mode == M_DIR) { m.add(0, 1, 0, "Folder baru"); if (!clip.isEmpty()) m.add(0, 2, 0, "Tempel (" + clip.size() + ")"); }
        if (mode != M_HOME) m.add(0, 3, 0, "Pilih semua");
        if (mode == M_DIR) m.add(0, 4, 0, isFav(cur) ? "Hapus dari favorit" : "Tambah ke favorit");
        m.add(0, 5, 0, hidden ? "Sembunyikan file tersembunyi" : "Tampilkan file tersembunyi");
        if (mode == M_TRASH) m.add(0, 6, 0, "Kosongkan keranjang sampah");
        m.add(0, 7, 0, "Muat ulang");
        pm.setOnMenuItemClickListener(it -> {
            int id = it.getItemId();
            if (id == 1) newFolder();
            else if (id == 2) paste();
            else if (id == 3) { sel.addAll(shown); load(); }
            else if (id == 4) toggleFav(cur);
            else if (id == 5) setHidden(!hidden);
            else if (id == 6) emptyTrash();
            else if (id == 7) { counts.evictAll(); cache.evictAll(); load(); }
            return true;
        });
        pm.show();
    }

    void selMenu(View anchor) {
        PopupMenu pm = new PopupMenu(this, anchor); Menu m = pm.getMenu();
        m.add(0, 1, 0, "Pilih semua");
        if (sel.size() == 1) {
            File f = sel.iterator().next(); String e = ext(f);
            if (mode != M_TRASH) m.add(0, 2, 0, "Ganti nama");
            if (e.equals("zip")) m.add(0, 3, 0, "Ekstrak");
            if (e.equals("rar") || e.equals("7z")) m.add(0, 4, 0, "Ekstrak");
            if (e.equals("apk")) m.add(0, 5, 0, "Pasang");
            m.add(0, 6, 0, "Info");
            if (f.isDirectory() && mode != M_TRASH) m.add(0, 7, 0, isFav(f) ? "Hapus dari favorit" : "Tambah ke favorit");
        }
        if (mode == M_TRASH) m.add(0, 8, 0, "Pulihkan"); else m.add(0, 9, 0, "Hapus permanen");
        pm.setOnMenuItemClickListener(it -> {
            int id = it.getItemId();
            File f = sel.size() == 1 ? sel.iterator().next() : null;
            if (id == 1) { sel.addAll(shown); load(); }
            else if (id == 8) restoreSel();
            else if (id == 9) deleteForever(new ArrayList<>(sel));
            else if (f != null) {
                if (id == 2) ask("Ganti nama", f.getName(), n -> { if (!n.isEmpty() && f.renameTo(new File(f.getParentFile(), n))) sel.clear(); else toast("Gagal"); load(); });
                else if (id == 3) extract(f);
                else if (id == 4) toast("Saat ini hanya ZIP yang didukung");
                else if (id == 5) install(f);
                else if (id == 6) info(f);
                else if (id == 7) { toggleFav(f); sel.clear(); load(); }
            }
            return true;
        });
        pm.show();
    }

    void setHidden(boolean v) {
        hidden = v; prefs.edit().putBoolean("hidden", v).apply(); load();
    }

    // =====================================================================
    //  Lembar "Lihat / Sortir / Lainnya"
    // =====================================================================
    View sheetRow(String text, View right) {
        LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(dp(16), 0, dp(16), 0); r.setMinimumHeight(dp(52));
        TextView t = tv(text, 18, 0xFF000000);
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
        if (right != null) r.addView(right);
        return r;
    }

    TextView sheetHeader(String t) {
        TextView x = tv(t, 17, TEAL); x.setTypeface(null, Typeface.BOLD); x.setPadding(dp(16), dp(20), dp(16), dp(4)); return x;
    }

    View optCell(int icRes, int iconDp, boolean checked, RadioButton[] group, int idx, Runnable pick) {
        LinearLayout c = new LinearLayout(this); c.setGravity(Gravity.CENTER_VERTICAL); c.setPadding(dp(8), 0, 0, 0);
        RadioButton rb = new RadioButton(this); rb.setChecked(checked); rb.setClickable(false); rb.setFocusable(false);
        group[idx] = rb;
        c.addView(rb);
        ImageView im = new ImageView(this); im.setImageDrawable(ic(icRes, 0)); im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)); ip.leftMargin = dp(6);
        c.addView(im, ip);
        c.setOnClickListener(v -> { for (RadioButton b : group) if (b != null) b.setChecked(b == rb); pick.run(); });
        return c;
    }

    String sortLabel() { return SORT_NAMES[cfg.sort] + (cfg.asc ? "  ▲" : "  ▼"); }

    void showViewSheet() {
        final Dialog dlg = new Dialog(this, R.style.AppSheet);
        final boolean[] all = {false};
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setBackgroundColor(-1);
        Runnable changed = () -> { saveCfg(all[0]); applyLayout(); load(); };

        CheckBox cbAll = new CheckBox(this);
        cbAll.setOnCheckedChangeListener((b, on) -> { all[0] = on; if (on) saveCfg(true); });
        box.addView(sheetRow("Terapkan ke semua folder", cbAll));
        box.addView(line(LINE), new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))));

        box.addView(sheetHeader("Lihat"));
        int[] lay = {R.drawable.ic_view_list, R.drawable.ic_view_grid, R.drawable.ic_view_detail};
        RadioButton[] g1 = new RadioButton[3];
        LinearLayout r1 = new LinearLayout(this);
        for (int k = 0; k < 3; k++) {
            final int kk = k;
            r1.addView(optCell(lay[k], 22, cfg.layout == k, g1, k, () -> { cfg.layout = kk; changed.run(); }),
                new LinearLayout.LayoutParams(0, dp(60), 1));
        }
        box.addView(r1);
        int[] th = {R.drawable.ic_img_small, R.drawable.ic_img_large};
        int[] ths = {18, 24};
        RadioButton[] g2 = new RadioButton[2];
        LinearLayout r2 = new LinearLayout(this);
        for (int k = 0; k < 2; k++) {
            final int kk = k;
            r2.addView(optCell(th[k], ths[k], cfg.thumb == k, g2, k, () -> { cfg.thumb = kk; changed.run(); }),
                new LinearLayout.LayoutParams(0, dp(60), 1));
        }
        r2.addView(new View(this), new LinearLayout.LayoutParams(0, dp(60), 1));
        box.addView(r2);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))); sp.topMargin = dp(8);
        box.addView(line(LINE), sp);

        box.addView(sheetHeader("Sortir"));
        TextView ts = tv(sortLabel(), 18, 0xFF000000); ts.setPadding(dp(16), dp(14), dp(16), dp(18));
        ts.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Urutkan berdasarkan")
            .setItems(SORT_NAMES, (d, w) -> {
                if (cfg.sort == w) cfg.asc = !cfg.asc; else { cfg.sort = w; cfg.asc = (w == 0 || w == 3); }
                ts.setText(sortLabel()); changed.run();
            }).show());
        box.addView(ts);
        box.addView(line(LINE), new LinearLayout.LayoutParams(-1, Math.max(1, dp(1))));

        box.addView(sheetHeader("Lainnya"));
        CheckBox cbHid = new CheckBox(this); cbHid.setChecked(hidden);
        cbHid.setOnCheckedChangeListener((b, on) -> setHidden(on));
        box.addView(sheetRow("Tampilkan file tersembunyi", cbHid));

        ScrollView sv = new ScrollView(this); sv.addView(box);
        dlg.setContentView(sv);
        Window w = dlg.getWindow();
        if (w != null) {
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
            w.setBackgroundDrawable(new ColorDrawable(-1));
        }
        dlg.show();
    }

    // =====================================================================
    //  Operasi file
    // =====================================================================
    void ask(String t, String init, Consumer<String> ok) {
        EditText e = new EditText(this); e.setText(init); e.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle(t).setView(e).setPositiveButton("OK", (d, w) -> ok.accept(e.getText().toString().trim())).setNegativeButton("Batal", null).show();
    }

    void newFolder() { ask("Folder baru", "", n -> { if (!n.isEmpty() && new File(cur, n).mkdirs()) load(); else toast("Gagal membuat folder"); }); }

    void bg(Job j, String done) {
        toast("Memproses…");
        new Thread(() -> {
            try { j.run(); h.post(() -> { toast(done); sel.clear(); load(); refreshTrashSize(); }); }
            catch (Exception e) { h.post(() -> { toast("Gagal: " + e.getMessage()); load(); refreshTrashSize(); }); }
        }).start();
    }

    void delete() {
        final List<File> l = new ArrayList<>(sel);
        new AlertDialog.Builder(this).setTitle("Hapus " + l.size() + " item?")
            .setMessage("Item akan dipindahkan ke Keranjang Sampah.")
            .setPositiveButton("Pindahkan", (d, w) -> bg(() -> moveToTrash(l), "Dipindahkan ke keranjang sampah"))
            .setNeutralButton("Hapus permanen", (d, w) -> bg(() -> { for (File f : l) del(f); }, "Terhapus"))
            .setNegativeButton("Batal", null).show();
    }

    void deleteForever(List<File> l) {
        new AlertDialog.Builder(this).setTitle("Hapus permanen " + l.size() + " item?").setMessage("Tidak bisa dibatalkan.")
            .setPositiveButton("Hapus", (d, w) -> bg(() -> {
                for (File f : l) { if (mode == M_TRASH) prefs.edit().remove("t:" + f.getName()).apply(); del(f); }
            }, "Terhapus")).setNegativeButton("Batal", null).show();
    }

    void emptyTrash() {
        File[] a = trashDir().listFiles();
        if (a == null || a.length == 0) { toast("Keranjang sampah sudah kosong"); return; }
        deleteForever(new ArrayList<>(Arrays.asList(a)));
    }

    void moveToTrash(List<File> l) throws IOException {
        File t = trashDir(); t.mkdirs();
        for (File f : l) {
            File d = uniq(new File(t, f.getName()));
            if (!f.renameTo(d)) { copy(f, d); del(f); }
            prefs.edit().putString("t:" + d.getName(), f.getAbsolutePath()).apply();
        }
    }

    void restoreSel() {
        final List<File> l = new ArrayList<>(sel);
        bg(() -> {
            for (File f : l) {
                String o = prefs.getString("t:" + f.getName(), null);
                File dest = o != null ? new File(o) : new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), f.getName());
                File par = dest.getParentFile(); if (par != null) par.mkdirs();
                dest = uniq(dest);
                if (!f.renameTo(dest)) { copy(f, dest); del(f); }
                prefs.edit().remove("t:" + f.getName()).apply();
            }
        }, "Dipulihkan");
    }

    void del(File f) { File[] a = f.listFiles(); if (a != null) for (File c : a) del(c); f.delete(); }

    void copy(File s, File d) throws IOException {
        if (s.isDirectory()) {
            if (d.getCanonicalPath().startsWith(s.getCanonicalPath() + "/")) throw new IOException("Folder tidak bisa disalin ke dalam dirinya");
            d.mkdirs(); File[] a = s.listFiles(); if (a != null) for (File c : a) copy(c, new File(d, c.getName()));
        } else try (InputStream in = new FileInputStream(s); OutputStream o = new FileOutputStream(d)) {
            byte[] bf = new byte[65536]; int n; while ((n = in.read(bf)) > 0) o.write(bf, 0, n);
        }
    }

    File uniq(File d) {
        if (!d.exists()) return d;
        String n = d.getName(); int i = n.lastIndexOf('.'); String b = i > 0 ? n.substring(0, i) : n, e = i > 0 ? n.substring(i) : "";
        for (int k = 2; ; k++) { File f = new File(d.getParentFile(), b + " (" + k + ")" + e); if (!f.exists()) return f; }
    }

    void doClip(boolean isCut) {
        clip = new ArrayList<>(sel); cut = isCut; sel.clear();
        toast("Buka folder tujuan, lalu ketuk TEMPEL"); load();
    }

    void paste() {
        if (mode != M_DIR) return;
        final List<File> c = new ArrayList<>(clip); final boolean ct = cut; final File to = cur; clip.clear();
        updatePasteBar();
        bg(() -> {
            for (File f : c) {
                File d = uniq(new File(to, f.getName()));
                if (ct) { if (!f.renameTo(d)) { copy(f, d); del(f); } } else copy(f, d);
            }
        }, ct ? "Dipindahkan" : "Disalin");
    }

    void extract(File z) {
        final File out = uniq(new File(z.getParentFile(), z.getName().replaceFirst("\\.[^.]+$", "")));
        bg(() -> {
            out.mkdirs(); String base = out.getCanonicalPath() + "/";
            try (ZipInputStream zi = new ZipInputStream(new FileInputStream(z))) {
                ZipEntry e; byte[] bf = new byte[65536];
                while ((e = zi.getNextEntry()) != null) {
                    File f = new File(out, e.getName());
                    if (!f.getCanonicalPath().startsWith(base)) continue;
                    if (e.isDirectory()) { f.mkdirs(); continue; }
                    f.getParentFile().mkdirs();
                    try (OutputStream o = new FileOutputStream(f)) { int n; while ((n = zi.read(bf)) > 0) o.write(bf, 0, n); }
                }
            }
        }, "Diekstrak ke folder " + out.getName());
    }

    Uri uri(File f) { return FileProvider.getUriForFile(this, getPackageName() + ".fp", f); }
    String ext(File f) { String n = f.getName(); int i = n.lastIndexOf('.'); return i < 0 ? "" : n.substring(i + 1).toLowerCase(); }

    void open(File f) {
        addRecent(f);
        if (ext(f).equals("apk")) { install(f); return; }
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(f));
        try {
            Intent i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(uri(f), m == null ? "*/*" : m);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(i);
        } catch (Exception e) { toast("Tidak ada aplikasi untuk membuka file ini"); }
    }

    void install(File f) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            toast("Izinkan Fileku memasang aplikasi, lalu coba lagi");
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getPackageName()))); return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW); i.setDataAndType(uri(f), "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); startActivity(i);
        } catch (Exception e) { toast("Tidak bisa memasang: " + e.getMessage()); }
    }

    void share() {
        final List<File> l = new ArrayList<>(sel); boolean dir = false;
        for (File f : l) if (f.isDirectory()) dir = true;
        if (!dir) { doShare(l); return; }
        toast("Folder dikompres jadi ZIP dulu…");
        new Thread(() -> {
            try {
                List<File> r = new ArrayList<>(); File tmp = new File(getCacheDir(), "share"); del(tmp); tmp.mkdirs();
                for (File f : l) {
                    if (f.isFile()) r.add(f);
                    else { File z = new File(tmp, f.getName() + ".zip"); try (ZipOutputStream o = new ZipOutputStream(new FileOutputStream(z))) { addZip(o, f, f.getName()); } r.add(z); }
                }
                h.post(() -> doShare(r));
            } catch (Exception e) { h.post(() -> toast("Gagal: " + e.getMessage())); }
        }).start();
    }

    void addZip(ZipOutputStream o, File f, String n) throws IOException {
        if (f.isDirectory()) { File[] a = f.listFiles(); if (a != null) for (File c : a) addZip(o, c, n + "/" + c.getName()); }
        else {
            o.putNextEntry(new ZipEntry(n));
            try (InputStream in = new FileInputStream(f)) { byte[] bf = new byte[65536]; int k; while ((k = in.read(bf)) > 0) o.write(bf, 0, k); }
            o.closeEntry();
        }
    }

    void doShare(List<File> l) {
        ArrayList<Uri> u = new ArrayList<>(); String mt = null;
        for (File f : l) {
            u.add(uri(f));
            String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(f)); if (m == null) m = "application/octet-stream";
            if (mt == null) mt = m;
            else if (!mt.equals(m)) mt = mt.split("/")[0].equals(m.split("/")[0]) ? mt.split("/")[0] + "/*" : "*/*";
        }
        Intent i = new Intent(u.size() == 1 ? Intent.ACTION_SEND : Intent.ACTION_SEND_MULTIPLE); i.setType(mt);
        if (u.size() == 1) i.putExtra(Intent.EXTRA_STREAM, u.get(0)); else i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, u);
        ClipData cd = ClipData.newRawUri("file", u.get(0)); for (int k = 1; k < u.size(); k++) cd.addItem(new ClipData.Item(u.get(k)));
        i.setClipData(cd); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "Bagikan lewat"));
    }

    void info(File f) {
        String s = "Nama: " + f.getName() + "\nLokasi: " + f.getParent() + "\nUkuran: " + fmt(size(f)) + "\nDiubah: " + DTF.format(new Date(f.lastModified()));
        new AlertDialog.Builder(this).setTitle("Info").setMessage(s).setPositiveButton("OK", null).show();
    }

    long size(File f) { if (f.isFile()) return f.length(); long t = 0; File[] a = f.listFiles(); if (a != null) for (File c : a) t += size(c); return t; }
    String date(File f) { return DF.format(new Date(f.lastModified())); }
    String fmt(long b) {
        if (b < 1024) return b + " B";
        double v = b / 1024.0; String[] u = {"KB", "MB", "GB", "TB"}; int i = 0;
        while (v >= 1024 && i < 3) { v /= 1024; i++; }
        return String.format(Locale.getDefault(), "%.1f %s", v, u[i]);
    }

    // =====================================================================
    //  Ikon file / folder
    // =====================================================================
    int badgeFor(String n) {
        switch (n.toLowerCase()) {
            case "bluetooth": return R.drawable.ic_badge_bluetooth;
            case "dcim": case "camera": return R.drawable.ic_badge_camera;
            case "download": case "downloads": return R.drawable.ic_badge_download;
            case "music": case "audio": return R.drawable.ic_badge_music;
            case "pictures": case "images": return R.drawable.ic_badge_image;
            case "movies": case "video": case "videos": return R.drawable.ic_badge_movie;
            case "documents": return R.drawable.ic_badge_doc;
            default: return 0;
        }
    }

    Bitmap folderIcon(File f, boolean items, int S) {
        int br = badgeFor(f.getName());
        String k = "dir|" + items + "|" + br + "|" + S;
        Bitmap b = cache.get(k);
        if (b == null) { b = Art.folder(this, S, items, br); cache.put(k, b); }
        return b;
    }

    int color(String e) {
        switch (e) {
            case "zip": case "jar": return 0xFFFF6F00;
            case "rar": return 0xFF8E24AA;
            case "7z": case "tar": case "gz": return 0xFF00897B;
            case "pdf": return 0xFFE53935;
            case "doc": case "docx": return 0xFF1E88E5;
            case "xls": case "xlsx": case "csv": return 0xFF2E7D32;
            case "ppt": case "pptx": return 0xFFEF6C00;
            case "txt": case "log": return 0xFF78909C;
            case "mp3": case "wav": case "m4a": case "ogg": case "flac": return 0xFFEC407A;
            case "mp4": case "mkv": case "avi": case "3gp": case "webm": return 0xFF5E35B1;
            case "apk": return 0xFF43A047;
            case "html": case "htm": case "js": case "json": case "xml": return 0xFF039BE5;
            default: return 0xFF607D8B;
        }
    }

    /** Ikon file generik: kotak berwarna dengan label ekstensi. */
    Bitmap extIcon(File f, int S) {
        String e = ext(f); String k = "ext|" + e + "|" + S;
        Bitmap b = cache.get(k); if (b != null) return b;
        b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color(e)); c.drawRoundRect(new RectF(S * .14f, S * .04f, S * .86f, S * .96f), S * .12f, S * .12f, p);
        p.setColor(-1); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD);
        String L = e.isEmpty() ? "FILE" : e.toUpperCase(); if (L.length() > 4) L = L.substring(0, 4);
        p.setTextSize(S * (L.length() > 3 ? .2f : .26f)); c.drawText(L, S / 2f, S * .6f, p);
        cache.put(k, b); return b;
    }

    Bitmap thumb(File f, int S) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true; BitmapFactory.decodeFile(f.getPath(), o);
            if (o.outWidth <= 0) return null;
            o.inSampleSize = Math.max(1, Math.min(o.outWidth, o.outHeight) / S); o.inJustDecodeBounds = false;
            Bitmap s = BitmapFactory.decodeFile(f.getPath(), o); if (s == null) return null;
            Bitmap sq = ThumbnailUtils.extractThumbnail(s, S, S);
            Bitmap out = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setShader(new BitmapShader(sq, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            new Canvas(out).drawRoundRect(new RectF(0, 0, S, S), S * .1f, S * .1f, p);
            return out;
        } catch (Throwable t) { return null; }
    }

    Bitmap apkIcon(File f, int S) {
        try {
            PackageManager pm = getPackageManager(); PackageInfo pi = pm.getPackageArchiveInfo(f.getPath(), 0); if (pi == null) return null;
            ApplicationInfo ai = pi.applicationInfo; ai.sourceDir = f.getPath(); ai.publicSourceDir = f.getPath();
            Drawable d = ai.loadIcon(pm); Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
            d.setBounds(0, 0, S, S); d.draw(new Canvas(b)); return b;
        } catch (Throwable t) { return null; }
    }

    // =====================================================================
    //  Adapter
    // =====================================================================
    Holder makeCell() {
        Holder hd = new Holder();
        int L = cfg.layout, T = cfg.thumb;
        int sz = L == 0 ? dp(T == 0 ? 44 : 64) : L == 2 ? dp(T == 0 ? 34 : 52) : dp(T == 0 ? 56 : 84);
        hd.S = sz;
        FrameLayout ib = new FrameLayout(this);
        hd.icon = new ImageView(this); ib.addView(hd.icon, new FrameLayout.LayoutParams(sz, sz));
        hd.chk = new TextView(this); hd.chk.setText("✓"); hd.chk.setTextColor(-1); hd.chk.setTextSize(12); hd.chk.setGravity(Gravity.CENTER);
        hd.chk.setTypeface(null, Typeface.BOLD); hd.chk.setIncludeFontPadding(false);
        GradientDrawable cg = new GradientDrawable(); cg.setShape(GradientDrawable.OVAL); cg.setColor(TEAL); cg.setStroke(Math.max(1, dp(1)), -1);
        hd.chk.setBackground(cg); hd.chk.setVisibility(View.GONE);
        ib.addView(hd.chk, new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.BOTTOM | Gravity.END));
        hd.name = tv("", L == 1 ? 13 : L == 2 ? 16 : 18, 0xFF000000);
        hd.sub = tv("", L == 1 ? 11 : L == 2 ? 13 : 14, SUB); hd.sub.setSingleLine(true);
        if (L == 1) {
            LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER_HORIZONTAL);
            c.setPadding(dp(4), dp(8), dp(4), dp(8));
            c.addView(ib, new LinearLayout.LayoutParams(sz, sz));
            hd.name.setGravity(Gravity.CENTER); hd.name.setMaxLines(2); hd.name.setEllipsize(TextUtils.TruncateAt.END); hd.name.setPadding(0, dp(4), 0, 0);
            hd.sub.setGravity(Gravity.CENTER);
            c.addView(hd.name, new LinearLayout.LayoutParams(-1, -2));
            c.addView(hd.sub, new LinearLayout.LayoutParams(-1, -2));
            hd.root = c;
        } else {
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), dp(L == 2 ? 4 : 6), dp(12), dp(L == 2 ? 4 : 6)); row.setMinimumHeight(dp(L == 2 ? 48 : 57));
            row.addView(ib, new LinearLayout.LayoutParams(sz, sz));
            LinearLayout col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(8), 0, 0, 0);
            hd.name.setSingleLine(true); hd.name.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(hd.name);
            if (L == 0) {
                LinearLayout l2 = new LinearLayout(this); l2.setGravity(Gravity.CENTER_VERTICAL);
                l2.addView(hd.sub, new LinearLayout.LayoutParams(0, -2, 1));
                hd.date = tv("", 14, SUB); hd.date.setSingleLine(true);
                l2.addView(hd.date);
                col.addView(l2);
            } else col.addView(hd.sub);
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            hd.root = row;
        }
        hd.root.setTag(hd);
        return hd;
    }

    String countKey(File f) { return f.getPath() + "|" + f.lastModified() + "|" + hidden; }

    String fileSub(File f) {
        String s = fmt(f.length());
        if ((mode == M_CAT || searching) && f.getParentFile() != null) s += " • " + f.getParentFile().getName();
        return s;
    }

    void bind(final Holder hd, final File f) {
        hd.name.setText(f.getName());
        hd.chk.setVisibility(sel.contains(f) ? View.VISIBLE : View.GONE);
        hd.root.setBackground(ripple(sel.contains(f) ? SEL_BG : BG, 0x22000000));
        final String when = cfg.layout == 2 ? DTF.format(new Date(f.lastModified())) : date(f);
        if (hd.date != null) hd.date.setText(date(f));
        hd.key = f.getPath() + "|" + f.lastModified() + "|" + hd.S;
        final String hk = hd.key;

        if (f.isDirectory()) {
            Integer cnt = counts.get(countKey(f));
            if (cnt == null) {
                hd.sub.setText(cfg.layout == 2 ? when : "");
                hd.icon.setImageBitmap(folderIcon(f, false, hd.S));
                pool.execute(() -> {
                    String[] a = f.list(); int n = 0;
                    if (a != null) for (String s : a) if (hidden || !s.startsWith(".")) n++;
                    final int c = n; counts.put(countKey(f), c);
                    h.post(() -> {
                        if (!hk.equals(hd.key)) return;
                        hd.sub.setText(subDir(c, when));
                        hd.icon.setImageBitmap(folderIcon(f, c > 0, hd.S));
                    });
                });
            } else {
                hd.sub.setText(subDir(cnt, when));
                hd.icon.setImageBitmap(folderIcon(f, cnt > 0, hd.S));
            }
        } else {
            String base = fileSub(f);
            hd.sub.setText(cfg.layout == 2 ? base + " • " + when : base);
            final String e = ext(f);
            Bitmap b = cache.get(hk);
            if (b != null) hd.icon.setImageBitmap(b);
            else {
                hd.icon.setImageBitmap(extIcon(f, hd.S));
                if (IMG.contains(e) || e.equals("apk")) {
                    final int S = hd.S;
                    pool.execute(() -> {
                        Bitmap t = IMG.contains(e) ? thumb(f, S) : apkIcon(f, S);
                        if (t == null) return;
                        cache.put(hk, t);
                        h.post(() -> { if (hk.equals(hd.key)) hd.icon.setImageBitmap(t); });
                    });
                }
            }
        }
    }

    String subDir(int cnt, String when) { return cfg.layout == 2 ? cnt + " item • " + when : cnt + " item"; }

    class FA extends BaseAdapter {
        public int getCount() { return shown.size(); }
        public Object getItem(int i) { return shown.get(i); }
        public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 3; }
        @Override public int getItemViewType(int i) { return cfg.layout; }
        public View getView(int i, View cv, ViewGroup parent) {
            Holder hd = cv == null ? makeCell() : (Holder) cv.getTag();
            bind(hd, shown.get(i));
            return hd.root;
        }
    }
}
