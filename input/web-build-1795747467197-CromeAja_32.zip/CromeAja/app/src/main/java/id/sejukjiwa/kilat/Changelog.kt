package id.sejukjiwa.kilat

/**
 * Riwayat perubahan yang tampil di menu "Tentang CromeAja".
 * Tiap ada perubahan: tambahkan baris baru di ATAS dan samakan angka versinya dengan versionName di app/build.gradle.
 */
object Changelog {
    val ENTRIES = listOf(
        "1.15" to "File manager: warna ikon ekstensi lebih cerah (tanpa abu-abu); menu ⋮ punya pilihan Folder di atas berkas",
        "1.14" to "File manager: folder kembali di atas berkas; ikon berkas berwarna per jenis (APK hijau, ZIP cokelat, PDF merah, dst.) dengan label ekstensi",
        "1.13" to "File manager: berkas tampil dulu, folder di bawahnya; pintasan folder kembali di atas (yang aktif tetap ditandai)",
        "1.12" to "File manager: ikon folder lebih jelas, pintasan folder pindah ke bawah dan yang aktif ditandai, selalu mulai dari penyimpanan internal / Unduhan",
        "1.11" to "File manager bawaan (menu \"File manager\"): jelajah berkas urut terbaru, dan dipakai sebagai pemilih berkas saat situs meminta unggahan (tanpa pemilih berkas sistem)",
        "1.10" to "Pemilih berkas langsung membuka folder Unduhan",
        "1.9" to "Saat situs meminta berkas (unggah), muncul daftar semua file manager terpasang untuk dipilih (mis. yang urutannya berdasarkan waktu terbaru); pilihan terakhir di paling atas",
        "1.8" to "Tarik-ke-bawah tidak mengganggu roda/daftar tanggal & elemen geser lain (mis. TikTok); ada menu \"Tarik untuk muat ulang\" untuk mematikannya",
        "1.7" to "Menggulir kalender/daftar di dalam halaman web tidak lagi memicu muat ulang (tarik-ke-bawah)",
        "1.6" to "Blokir iklan lebih kuat: daftar domain diperluas, skrip iklan dikenali dari pola alamat, kotak iklan disembunyikan",
        "1.5" to "Thumbnail tab aktif tidak kosong lagi; ukuran thumbnail tab dikecilkan (3 kolom)",
        "1.4" to "Tekan lama thumbnail situs di halaman utama membuka dialog ubah (ada tombol Hapus)",
        "1.3" to "Perbaikan unduhan gagal \"Failed to build unique file\": nama file otomatis diganti bila bentrok",
        "1.2" to "Versi sebelumnya"
    )
}
