package com.example.fm

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import android.view.*
import android.webkit.MimeTypeMap
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipFile

class MainActivity : Activity() {
    enum class Sort(val label: String) { NEWEST("Waktu terbaru"), NAME("Nama (A-Z)"), OLDEST("Waktu terlama") }
    data class Item(val name: String, val dir: Boolean, val size: Long, val time: Long, val file: File?, val path: String?)

    private val root: File = Environment.getExternalStorageDirectory()
    private var dir = root
    private var zip: File? = null          // sedang membuka ZIP?
    private var prefix = ""                // folder di dalam ZIP
    private var sort = Sort.NEWEST         // default: waktu terbaru
    private var clip: List<File> = emptyList()
    private var cut = false
    private var items = listOf<Item>()
    private lateinit var list: ListView
    private val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        list = ListView(this); setContentView(list)
        list.setOnItemClickListener { _, _, p, _ -> click(items[p]) }
        list.setOnItemLongClickListener { _, _, p, _ -> if (zip == null) longClick(items[p].file!!); true }
        if (!hasAccess()) askAccess()
        handleIntent(intent)
        refresh()
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handleIntent(i); refresh() }
    override fun onResume() { super.onResume(); if (items.isEmpty() && hasAccess()) refresh() }

    // ---------- Izin ----------
    private fun hasAccess() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun askAccess() {
        if (Build.VERSION.SDK_INT >= 30)
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        else requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { refresh() }

    // ---------- Intent masuk (jika dijadikan default) ----------
    private fun handleIntent(i: Intent?) {
        val u = i?.data ?: return
        if (i.action != Intent.ACTION_VIEW) return
        if (u.scheme == "file") { openPath(File(u.path!!)); return }
        bg({
            val f = File(cacheDir, "incoming_" + (u.lastPathSegment ?: "file").substringAfterLast('/'))
            contentResolver.openInputStream(u)?.use { s -> f.outputStream().use { s.copyTo(it) } }
            f
        }) { f ->
            val type = contentResolver.getType(u) ?: ""
            if (type.contains("android.package-archive") || f.name.endsWith(".apk", true)) install(f)
            else { zip = f; prefix = ""; refresh() }
        }
    }

    private fun openPath(f: File) {
        when {
            f.isDirectory -> { dir = f; zip = null; refresh() }
            f.extension.equals("zip", true) -> { zip = f; prefix = ""; refresh() }
            else -> openFile(f)
        }
    }

    // ---------- Daftar ----------
    private fun refresh() {
        val z = zip
        val raw = if (z == null) (dir.listFiles() ?: emptyArray()).map { Item(it.name, it.isDirectory, it.length(), it.lastModified(), it, null) }
                  else listZip(z)
        val c: Comparator<Item> = when (sort) {
            Sort.NAME -> compareBy { it.name.lowercase() }
            Sort.NEWEST -> compareByDescending { it.time }
            Sort.OLDEST -> compareBy { it.time }
        }
        items = raw.sortedWith(compareByDescending<Item> { it.dir }.then(c))
        title = if (z == null) dir.absolutePath else "${z.name}/$prefix"
        actionBar?.subtitle = "Urut: ${sort.label}"
        list.adapter = object : ArrayAdapter<Item>(this, android.R.layout.simple_list_item_2, android.R.id.text1, items) {
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val r = super.getView(p, v, g); val i = getItem(p)!!
                r.findViewById<TextView>(android.R.id.text1).text = (if (i.dir) "📁 " else "📄 ") + i.name
                r.findViewById<TextView>(android.R.id.text2).text =
                    fmt.format(Date(i.time)) + (if (i.dir) "" else "  •  " + Formatter.formatFileSize(context, i.size))
                return r
            }
        }
    }

    private fun listZip(z: File): List<Item> {
        val map = LinkedHashMap<String, Item>()
        try {
            ZipFile(z).use { zf ->
                for (e in zf.entries()) {
                    if (!e.name.startsWith(prefix)) continue
                    val rest = e.name.removePrefix(prefix)
                    if (rest.isEmpty()) continue
                    val idx = rest.indexOf('/')
                    val seg = if (idx < 0) rest else rest.substring(0, idx)
                    map.putIfAbsent(seg, Item(seg, idx >= 0, e.size, e.time, null, prefix + seg + if (idx >= 0) "/" else ""))
                }
            }
        } catch (e: Exception) { toast("Gagal membaca ZIP: ${e.message}") }
        return map.values.toList()
    }

    // ---------- Klik ----------
    private fun click(i: Item) {
        if (zip == null) {
            val f = i.file!!
            if (f.isDirectory) { dir = f; refresh() }
            else if (f.extension.equals("zip", true)) { zip = f; prefix = ""; refresh() }
            else openFile(f)
        } else if (i.dir) { prefix = i.path!!; refresh() }
        else {
            val out = File(cacheDir, "zv/" + i.name)
            bg({ out.parentFile!!.mkdirs(); extractEntry(zip!!, i.path!!, out); out }) { openFile(it) }
        }
    }

    private fun longClick(f: File) {
        AlertDialog.Builder(this).setTitle(f.name)
            .setItems(arrayOf("Salin", "Potong", "Ganti nama", "Hapus")) { _, w ->
                when (w) {
                    0 -> { clip = listOf(f); cut = false; toast("Disalin. Pilih menu Tempel di folder tujuan") }
                    1 -> { clip = listOf(f); cut = true; toast("Dipotong. Pilih menu Tempel di folder tujuan") }
                    2 -> input("Nama baru", f.name) { n -> if (!f.renameTo(File(f.parentFile, n))) toast("Gagal"); refresh() }
                    3 -> AlertDialog.Builder(this).setMessage("Hapus ${f.name}?")
                        .setPositiveButton("Hapus") { _, _ -> bg({ f.deleteRecursively() }) { refresh() } }
                        .setNegativeButton("Batal", null).show()
                }
            }.show()
    }

    // ---------- Buka & instal ----------
    private fun uriOf(f: File) = FileProvider.getUriForFile(this, "$packageName.provider", f)

    private fun openFile(f: File) {
        if (f.extension.equals("apk", true)) { install(f); return }
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(uriOf(f), mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Buka dengan"))
        } catch (e: Exception) { toast("Tidak ada aplikasi untuk membuka file ini") }
    }

    private fun install(f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            toast("Izinkan instal dari aplikasi ini, lalu coba lagi")
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))); return
        }
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uriOf(f), "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- ZIP ----------
    private fun extractEntry(z: File, path: String, out: File) {
        ZipFile(z).use { zf -> zf.getInputStream(zf.getEntry(path)).use { s -> out.outputStream().use { s.copyTo(it) } } }
    }

    private fun extractAll(z: File) {
        val dest = File(z.parentFile, z.nameWithoutExtension)
        bg({
            dest.mkdirs()
            ZipFile(z).use { zf ->
                for (e in zf.entries()) {
                    val out = File(dest, e.name)
                    if (!out.canonicalPath.startsWith(dest.canonicalPath + File.separator)) continue // anti Zip-Slip
                    if (e.isDirectory) out.mkdirs()
                    else { out.parentFile?.mkdirs(); zf.getInputStream(e).use { s -> out.outputStream().use { s.copyTo(it) } } }
                }
            }
        }) { toast("Diekstrak ke ${dest.absolutePath}") }
    }

    // ---------- Salin / tempel ----------
    private fun paste() {
        if (clip.isEmpty()) { toast("Clipboard kosong"); return }
        val target = dir
        bg({
            for (f in clip) {
                var t = File(target, f.name)
                if (f.isDirectory && t.canonicalPath.startsWith(f.canonicalPath + File.separator)) continue
                var n = 1
                while (t.exists()) { t = File(target, f.nameWithoutExtension + "_$n" + (if (f.extension.isEmpty()) "" else "." + f.extension)); n++ }
                if (cut) { if (!f.renameTo(t)) { f.copyRecursively(t); f.deleteRecursively() } } else f.copyRecursively(t)
            }
        }) { if (cut) clip = emptyList(); refresh() }
    }

    // ---------- Menu ----------
    override fun onCreateOptionsMenu(m: Menu): Boolean {
        m.add(0, 1, 0, "Urutkan"); m.add(0, 2, 1, "Tempel"); m.add(0, 3, 2, "Ekstrak ZIP ke sini"); m.add(0, 4, 3, "Folder baru")
        return true
    }

    override fun onOptionsItemSelected(i: MenuItem): Boolean {
        when (i.itemId) {
            1 -> AlertDialog.Builder(this).setTitle("Urutkan")
                .setSingleChoiceItems(Sort.values().map { it.label }.toTypedArray(), sort.ordinal) { d, w -> sort = Sort.values()[w]; d.dismiss(); refresh() }.show()
            2 -> if (zip == null) paste() else toast("Tidak bisa menempel di dalam ZIP")
            3 -> zip?.let { extractAll(it) } ?: toast("Buka file ZIP dulu")
            4 -> if (zip == null) input("Nama folder", "") { n -> File(dir, n).mkdirs(); refresh() }
        }
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            zip != null -> if (prefix.isNotEmpty()) {
                val up = prefix.dropLast(1).substringBeforeLast('/', "")
                prefix = if (up.isEmpty()) "" else "$up/"
            } else zip = null
            dir != root && dir.parentFile != null -> dir = dir.parentFile!!
            else -> { super.onBackPressed(); return }
        }
        refresh()
    }

    // ---------- Util ----------
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun input(hint: String, def: String, ok: (String) -> Unit) {
        val e = EditText(this).apply { setText(def); setHint(hint) }
        AlertDialog.Builder(this).setView(e).setPositiveButton("OK") { _, _ -> if (e.text.isNotBlank()) ok(e.text.toString().trim()) }
            .setNegativeButton("Batal", null).show()
    }

    private fun <T> bg(work: () -> T, done: (T) -> Unit) {
        Thread {
            try { val r = work(); runOnUiThread { done(r) } }
            catch (e: Exception) { runOnUiThread { toast("Error: ${e.message}") } }
        }.start()
    }
}
