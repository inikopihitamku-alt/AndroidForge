package com.example.pemutarmusik

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Mode aplikasi: pemutar file MP3 atau radio streaming. */
enum class AppMode { MP3, RADIO }

/** Stasiun radio. [freq] = frekuensi FM dalam MHz (boleh kosong), mis. "99.5". [url] = alamat stream audio. */
data class RadioStation(val id: Long, val name: String, val freq: String, val url: String)

/** Frekuensi FM sebagai angka (MHz), null kalau belum diisi / tidak valid. */
val RadioStation.freqValue: Float? get() = freq.replace(',', '.').toFloatOrNull()

/** Urut dari frekuensi terkecil; stasiun tanpa frekuensi ditaruh paling bawah (urut nama). */
fun sortByFreq(list: List<RadioStation>): List<RadioStation> =
    list.sortedWith(
        compareBy<RadioStation>({ it.freqValue == null }, { it.freqValue ?: 0f }, { it.name.lowercase() })
    )

/** Penyimpanan stasiun radio + mode terakhir di SharedPreferences. */
object RadioStore {
    private const val PREFS = "radio"
    private const val KEY_STATIONS = "stations"
    private const val KEY_RADIO_MODE = "radio_mode"
    private const val KEY_LAST = "last_station"

    private const val KEY_SEED = "seed_version"
    private const val SEED_VERSION = 3

    /** Channel bawaan: [key] (huruf kecil, tanpa spasi) dipakai mencocokkan dengan channel yang sudah ada saat pembaruan. */
    private data class Seed(val key: String, val name: String, val freq: String, val url: String)

    /**
     * Channel bawaan (daftar alamat stream dari pengguna). Frekuensi FM dari direktori radio Streema;
     * Top FM Bumiayu diambil dari alamat stream-nya (95.1). Paramount FM dan Shahabat FM belum ditemukan
     * frekuensinya sehingga dikosongkan. Semuanya bisa diedit (tekan lama pada channel).
     */
    private val SEEDS = listOf(
        Seed("sebayu", "SEBAYU FM", "94.0", "https://radio-streaming.tegalkota.go.id/stream/1/"),
        Seed("slawi", "SLAWI FM", "99.3", "http://i.klikhost.com/9032/;"),
        Seed("sananta", "SANANTA FM", "105.8", "http://i.klikhost.com:8500/;"),
        Seed("elshinta", "ELSHINTA", "90.0", "https://stream-ssl.arenastreaming.com:8000/jakarta"),
        Seed("gama", "GAMA FM", "90.0", "https://stream.zeno.fm/wvq442iwm6ztv"),
        Seed("topfm", "TOP FM BUMIAYU", "95.1", "http://streaming.topfm951.net:9510/stream"),
        Seed("anita", "ANITA FM", "106.6", "http://stream-148.zeno.fm/iln4upodbvuuv"),
        Seed("roshinta", "THOMPSON ROSHINTA FM", "100.7", "https://stream-150.zeno.fm/9ezblydred2uv"),
        Seed("paramount", "PARAMOUNT FM", "", "https://stream.pasopatiradio.com/paramountfm"),
        Seed("cbs", "RADIO CBS TEGAL", "104.4", "http://a5.siar.us/radio/8010/radio"),
        Seed("shahabat", "SHAHABAT FM", "", "http://streaming.girifm.com:8010/;stream.nsv?type=.mp3/;stream.mp3&autostart=1"),
    )

    fun defaults(): List<RadioStation> = sortByFreq(
        SEEDS.mapIndexed { i, sd -> RadioStation(i + 1L, sd.name, sd.freq, sd.url) }
    )

    /**
     * Perbarui daftar lama ke daftar channel baru: channel yang cocok (nama memuat kunci bawaan) diganti nama dan
     * alamat streamnya, yang belum ada ditambahkan. Channel buatan pengguna yang tidak cocok dibiarkan.
     */
    private fun migrate(list: List<RadioStation>): List<RadioStation> {
        val out = list.toMutableList()
        var nextId = (list.maxOfOrNull { it.id } ?: 0L) + 1
        val used = HashSet<Int>()
        for (sd in SEEDS) {
            val i = out.indices.firstOrNull { it !in used && out[it].name.lowercase().replace(" ", "").contains(sd.key) }
            if (i == null) {
                out += RadioStation(nextId++, sd.name, sd.freq, sd.url)
                used += out.lastIndex
            } else {
                out[i] = out[i].copy(name = sd.name, url = sd.url, freq = sd.freq.ifBlank { out[i].freq })
                used += i
            }
        }
        return out
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(context: Context): List<RadioStation> {
        val raw = prefs(context).getString(KEY_STATIONS, null) ?: return defaults()
        return try {
            val arr = JSONArray(raw)
            val list = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                RadioStation(o.getLong("id"), o.getString("name"), o.optString("freq", ""), o.getString("url"))
            }
            if (prefs(context).getInt(KEY_SEED, 0) >= SEED_VERSION) {
                sortByFreq(list)
            } else {
                sortByFreq(migrate(list)).also { save(context, it) }
            }
        } catch (e: Exception) {
            defaults()
        }
    }

    fun save(context: Context, stations: List<RadioStation>) {
        val arr = JSONArray()
        for (s in stations) {
            arr.put(JSONObject().put("id", s.id).put("name", s.name).put("freq", s.freq).put("url", s.url))
        }
        prefs(context).edit().putString(KEY_STATIONS, arr.toString()).putInt(KEY_SEED, SEED_VERSION).apply()
    }

    fun isRadioMode(context: Context): Boolean = prefs(context).getBoolean(KEY_RADIO_MODE, false)

    fun setRadioMode(context: Context, radio: Boolean) {
        prefs(context).edit().putBoolean(KEY_RADIO_MODE, radio).apply()
    }

    /** Stasiun terakhir dipilih, null kalau belum ada. */
    fun lastStation(context: Context): Long? =
        prefs(context).getLong(KEY_LAST, -1L).takeIf { it >= 0 }

    fun setLastStation(context: Context, id: Long?) {
        prefs(context).edit().putLong(KEY_LAST, id ?: -1L).apply()
    }
}
