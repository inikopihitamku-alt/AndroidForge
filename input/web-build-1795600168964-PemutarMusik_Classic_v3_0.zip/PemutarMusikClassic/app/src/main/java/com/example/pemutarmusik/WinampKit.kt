package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.SpectrumAnalyzer
import android.content.Context
import kotlin.math.max
import kotlin.math.sin
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath

// ------------------------------------------------------------------ skin (OCEAN biru-perak / GOM hitam-oranye)

// Nama-nama warna lama dipertahankan, tetapi nilainya mengikuti skin yang sedang dipilih (Skin.t).
val WA_DESK: Color get() = Skin.t.desk                  // latar aplikasi
val WA_SILVER_HI: Color get() = Skin.t.silverHi         // logam terang (atas)
val WA_SILVER_LO: Color get() = Skin.t.silverLo         // logam gelap (bawah)
val WA_PANEL: Color get() = Skin.t.panel                // penanda panel logam (dipakai bevel)
val WA_BORDER: Color get() = Skin.t.border              // garis tepi
val WA_HI: Color get() = Skin.t.hi
val WA_LO: Color get() = Skin.t.lo
val WA_INK: Color get() = Skin.t.ink                    // teks di atas panel
val WA_TEXT: Color get() = Skin.t.ink
val WA_LCD: Color get() = Skin.t.lcd                    // layar LCD / daftar lagu
val WA_LCD_DARK: Color get() = Skin.t.lcdDark
val WA_GREEN: Color get() = Skin.t.lcdText              // teks terang di layar (nama lama dipertahankan)
val WA_GREEN_DIM: Color get() = Skin.t.lcdTextDim       // teks redup di layar
val WA_LAMP_ON: Color get() = Skin.t.lampOn
val WA_LAMP_OFF: Color get() = Skin.t.lampOff
val WA_BLUE: Color get() = Skin.t.active                // tombol aktif
val WA_GROOVE: Color get() = Skin.t.groove
val WA_SEL: Color get() = Skin.t.sel                    // baris daftar terpilih
/** Huruf utama: monospace untuk skin lama, serif klasik untuk skin VINTAGE. */
val MONO: FontFamily get() = if (Skin.t.vintage) FontFamily.Serif else FontFamily.Monospace
val WA_BRIGHT: Color get() = Skin.t.bright                // teks paling terang di layar / dialog
val WA_LIT_TEXT: Color get() = Skin.t.litText             // teks di atas tombol yang menyala

// ------------------------------------------------------------------ variasi warna lampu LED

class LedPalette(
    val name: String,
    val c1: Color, val c2: Color, val c3: Color, val c4: Color,
    val specLow: Color, val specHigh: Color,
)

/** Semua warna yang berubah saat skin diganti. */
class SkinTheme(
    val name: String,
    val dark: Boolean,
    val desk: Color, val silverHi: Color, val silverMid: Color, val silverLo: Color, val panel: Color,
    val border: Color, val hi: Color, val lo: Color, val ink: Color,
    val lcd: Color, val lcdDark: Color, val lcdText: Color, val lcdTextDim: Color,
    val lampOn: Color, val lampOff: Color, val active: Color, val groove: Color, val sel: Color,
    val titleGrad: List<Color>, val titleText: Color, val stripe: Color,
    val minBtn: List<Color>, val modeOn: List<Color>,
    val ledRing: List<Color>, val ledOff: Color,
    val iconTint: Color, val well: Color, val accentText: Color,
    val grooveDark: Color, val grooveLight: Color, val thumb: List<Color>, val thumbOff: List<Color>, val grip: Color,
    val disabledFill: Color,
    val dialogBg: Color, val dialogEdge: Color, val dialogLine: Color, val menuBg: Color,
    val knobBody: List<Color>, val knobCap: List<Color>, val knobCapVu: List<Color>,
    val knobPointer: Color, val knobPointerVu: Color, val knobTickOff: Color,
    val vuBezel: List<Color>, val vuBezelLine: Color, val vuInk: Color,
    val vuTickLit: Color, val vuTickOff: Color, val vuKnobAccent: Color,
    val vuLedHouse: List<Color>, val vuLedSegOff: List<Color>,
    val radioBody: List<Color>, val radioBodyEdge: Color, val radioDisp: List<Color>, val radioDispEdge: Color,
    val radioText: Color, val radioTextDim: Color,
    val palette: LedPalette,
    val vintage: Boolean = false,
    val litText: Color = Color.White,
    val bright: Color = Color.White,
    val closeBtn: List<Color> = listOf(Color(0xFFFF7A6B), Color(0xFFD62B2B)),
    val knobTooth: Color = Color(0xCC111C3F),
    val vuFace: List<Color> = listOf(Color(0xFFC9CDD3), Color(0xFFB4B9C1), Color(0xFFA2A8B1)),
    val vuNeedle: Color = Color(0xFF070B1C),
    val vuGlow: Color = Color.Transparent,
    val woodLight: Color = Color(0x00000000),
    val woodDark: Color = Color(0x00000000),
)

private val THEME_OCEAN = SkinTheme(
    name = "OCEAN", dark = false,
    desk = Color(0xFF0A1530), silverHi = Color(0xFFE6EAF2), silverMid = Color(0xFFC9D0DF), silverLo = Color(0xFF9AA4BA),
    panel = Color(0xFFB5BDCC), border = Color(0xFF16244A), hi = Color(0xFFF4F7FC), lo = Color(0xFF16244A), ink = Color(0xFF1B2A55),
    lcd = Color(0xFF173E86), lcdDark = Color(0xFF0F2C66), lcdText = Color(0xFFEAF2FF), lcdTextDim = Color(0xFF6F8CC8),
    lampOn = Color(0xFF1F5BE0), lampOff = Color(0xFF7B879F), active = Color(0xFF2C5FC8), groove = Color(0xFF26314F), sel = Color(0xFF6F8FD0),
    titleGrad = listOf(Color(0xFF5A82D0), Color(0xFF34569E), Color(0xFF1A2A5E), Color(0xFF14224C)),
    titleText = Color(0xFFC9D3EA), stripe = Color(0x66C9D3EA),
    minBtn = listOf(Color(0xFF7FEBFF), Color(0xFF1C86FF)), modeOn = listOf(Color(0xFF5B93F0), Color(0xFF2C5FC8)),
    ledRing = listOf(Color(0xFFF4F7FC), Color(0xFF6F7A94), Color(0xFFCBD3E4)), ledOff = Color(0xFF111A3C),
    iconTint = Color(0xFF0B1330), well = Color(0xFFC2C9D9), accentText = Color(0xFF7FEBFF),
    grooveDark = Color(0xFF0E1630), grooveLight = Color(0xFF2E3A60),
    thumb = listOf(Color(0xFFFAFBFF), Color(0xFFC3CBDD), Color(0xFF8F9AB5)),
    thumbOff = listOf(Color(0xFFA3ACBF), Color(0xFF7B859B), Color(0xFF677189)),
    grip = Color(0xFF55607E), disabledFill = Color(0xFF3A4766),
    dialogBg = Color(0xFF1B2F66), dialogEdge = Color(0xFF6F8FD0), dialogLine = Color(0xFF3F5A9A), menuBg = Color(0xFFD5DBE8),
    knobBody = listOf(Color(0xFF9BAEDB), Color(0xFF22335F), Color(0xFF7488BE), Color(0xFF1A2850), Color(0xFF9BAEDB)),
    knobCap = listOf(Color(0xFFF7F9FD), Color(0xFF98A3BD), Color(0xFFE9EEF8), Color(0xFF7F8BA8), Color(0xFFF7F9FD)),
    knobCapVu = listOf(Color(0xFF3C63C2), Color(0xFF0B1F5C), Color(0xFF2A4A9E), Color(0xFF081646), Color(0xFF3C63C2)),
    knobPointer = Color(0xFF1B2A55), knobPointerVu = Color(0xFFE8EEFF), knobTickOff = Color(0xFF3F5A9A),
    vuBezel = listOf(Color(0xFF3558B8), Color(0xFF12297A), Color(0xFF071345)), vuBezelLine = Color(0xFF040B2B), vuInk = Color(0xFF0B1B44),
    vuTickLit = Color(0xFF0A3FD0), vuTickOff = Color(0xFF5A6684), vuKnobAccent = Color(0xFF8FC1FF),
    vuLedHouse = listOf(Color(0xFF03081A), Color(0xFF0E1B40), Color(0xFF03081A)),
    vuLedSegOff = listOf(Color(0xFF22366B), Color(0xFF0C1735)),
    radioBody = listOf(Color(0xFF2A56B0), Color(0xFF16356F), Color(0xFF0E2250)), radioBodyEdge = Color(0xFF9AA4BA),
    radioDisp = listOf(Color(0xFF071A4A), Color(0xFF0B2159)), radioDispEdge = Color(0xFF6F8FD0),
    radioText = Color(0xFFD6E2FA), radioTextDim = Color(0xFF7F9BD6),
    palette = LedPalette("OCEAN", Color(0xFF35E0FF), Color(0xFF4DFF9A), Color(0xFF4D8DFF), Color(0xFFFFC24D), Color(0xFF5E9BFF), Color(0xFFFFFFFF)),
)

/** Skin hitam + oranye ala GOM Player. */
private val THEME_GOM = SkinTheme(
    name = "GOM HITAM-ORANYE", dark = true,
    desk = Color(0xFF070707), silverHi = Color(0xFF3C3C3E), silverMid = Color(0xFF262628), silverLo = Color(0xFF111112),
    panel = Color(0xFF2A2A2C), border = Color(0xFF000000), hi = Color(0xFF5A5A5C), lo = Color(0xFF000000), ink = Color(0xFFFF9A2E),
    lcd = Color(0xFF0C0C0D), lcdDark = Color(0xFF000000), lcdText = Color(0xFFFFC27A), lcdTextDim = Color(0xFFB0702A),
    lampOn = Color(0xFFFF8A00), lampOff = Color(0xFF4A4A4C), active = Color(0xFFE8780C), groove = Color(0xFF2A2A2C), sel = Color(0xFF8A4A10),
    titleGrad = listOf(Color(0xFF3E3E40), Color(0xFF212123), Color(0xFF0F0F10), Color(0xFF050505)),
    titleText = Color(0xFFFF9B2E), stripe = Color(0x66FF9B2E),
    minBtn = listOf(Color(0xFFFFC27A), Color(0xFFE8780C)), modeOn = listOf(Color(0xFFFFA43A), Color(0xFFE8780C)),
    ledRing = listOf(Color(0xFF8E8E90), Color(0xFF2A2A2C), Color(0xFF5E5E60)), ledOff = Color(0xFF1C1108),
    iconTint = Color(0xFFFFA23C), well = Color(0xFF101011), accentText = Color(0xFFFFB347),
    grooveDark = Color(0xFF040404), grooveLight = Color(0xFF2C2C2E),
    thumb = listOf(Color(0xFF727274), Color(0xFF3C3C3E), Color(0xFF1C1C1E)),
    thumbOff = listOf(Color(0xFF4A4A4C), Color(0xFF343436), Color(0xFF242426)),
    grip = Color(0xFFFF9A2E), disabledFill = Color(0xFF4A3A2A),
    dialogBg = Color(0xFF161616), dialogEdge = Color(0xFFB4620E), dialogLine = Color(0xFF5A3A12), menuBg = Color(0xFF2A2A2C),
    knobBody = listOf(Color(0xFF6A6A6C), Color(0xFF161617), Color(0xFF4A4A4C), Color(0xFF0E0E0F), Color(0xFF6A6A6C)),
    knobCap = listOf(Color(0xFF5E5E60), Color(0xFF1A1A1B), Color(0xFF424244), Color(0xFF101011), Color(0xFF5E5E60)),
    knobCapVu = listOf(Color(0xFF58585A), Color(0xFF111112), Color(0xFF3A3A3C), Color(0xFF090909), Color(0xFF58585A)),
    knobPointer = Color(0xFFFF8A00), knobPointerVu = Color(0xFFFF8A00), knobTickOff = Color(0xFF4A4A4C),
    vuBezel = listOf(Color(0xFFD9760C), Color(0xFF8A4300), Color(0xFF3A1D00)), vuBezelLine = Color(0xFF140900), vuInk = Color(0xFF1A1208),
    vuTickLit = Color(0xFFFF8A00), vuTickOff = Color(0xFF4A4A4C), vuKnobAccent = Color(0xFFFFB347),
    vuLedHouse = listOf(Color(0xFF050505), Color(0xFF161616), Color(0xFF050505)),
    vuLedSegOff = listOf(Color(0xFF2E2E30), Color(0xFF111112)),
    radioBody = listOf(Color(0xFF3A3A3C), Color(0xFF1E1E20), Color(0xFF0E0E0F)), radioBodyEdge = Color(0xFFB4620E),
    radioDisp = listOf(Color(0xFF050505), Color(0xFF121212)), radioDispEdge = Color(0xFFB4620E),
    radioText = Color(0xFFFFC27A), radioTextDim = Color(0xFFB0702A),
    palette = LedPalette("GOM", Color(0xFFFFB347), Color(0xFFFF7A00), Color(0xFFFF8A00), Color(0xFFFFD24D), Color(0xFFFF7A00), Color(0xFFFFE2A8)),
)


/**
 * Skin VINTAGE: hi-fi klasik kelas atas. Muka champagne-gold sikat, bingkai kayu walnut, layar kaca hitam dengan
 * tulisan amber, VU meter berlatar krem dengan lampu belakang amber, knob kuningan bergerigi.
 */
private val THEME_VINTAGE = SkinTheme(
    name = "VINTAGE", dark = false,
    desk = Color(0xFF1C0F07), silverHi = Color(0xFFF1E2B6), silverMid = Color(0xFFD8C386), silverLo = Color(0xFFAE9358),
    panel = Color(0xFFC9B27A), border = Color(0xFF241506), hi = Color(0xFFFFF3CF), lo = Color(0xFF241506), ink = Color(0xFF2B1B0A),
    lcd = Color(0xFF0B0805), lcdDark = Color(0xFF000000), lcdText = Color(0xFFFFC76A), lcdTextDim = Color(0xFF9A6A2A),
    lampOn = Color(0xFFFFB02E), lampOff = Color(0xFF6E5B3A), active = Color(0xFFDCA032), groove = Color(0xFF2A1A08), sel = Color(0xFF5C3B14),
    titleGrad = listOf(Color(0xFF4A3018), Color(0xFF2E1C0C), Color(0xFF1A0F06), Color(0xFF120A04)),
    titleText = Color(0xFFEBCB85), stripe = Color(0x55D4AF5C),
    minBtn = listOf(Color(0xFFF4DC9C), Color(0xFFB98A33)), modeOn = listOf(Color(0xFFFFD98A), Color(0xFFC8872A)),
    ledRing = listOf(Color(0xFFFFF0C4), Color(0xFF7A5E2A), Color(0xFFE6CC8A)), ledOff = Color(0xFF1E1206),
    iconTint = Color(0xFF2B1B0A), well = Color(0xFFB8A068), accentText = Color(0xFFF1D794),
    grooveDark = Color(0xFF1B1108), grooveLight = Color(0xFF6A5330),
    thumb = listOf(Color(0xFFFFF4D6), Color(0xFFD9C48A), Color(0xFF9C8248)),
    thumbOff = listOf(Color(0xFFB3A27A), Color(0xFF8F7F5C), Color(0xFF776948)),
    grip = Color(0xFF5A4318), disabledFill = Color(0xFF5A4A30),
    dialogBg = Color(0xFF21150B), dialogEdge = Color(0xFFC9A24D), dialogLine = Color(0xFF5E4720), menuBg = Color(0xFFE9DAB0),
    knobBody = listOf(Color(0xFFF3DFA2), Color(0xFF6B5222), Color(0xFFD2B46A), Color(0xFF4D3A15), Color(0xFFF3DFA2)),
    knobCap = listOf(Color(0xFFFFF1C8), Color(0xFFA88A48), Color(0xFFF0DCA0), Color(0xFF8A6E32), Color(0xFFFFF1C8)),
    knobCapVu = listOf(Color(0xFF45413A), Color(0xFF0C0A07), Color(0xFF2E2A24), Color(0xFF050403), Color(0xFF45413A)),
    knobPointer = Color(0xFF2B1B0A), knobPointerVu = Color(0xFFFFD27A), knobTickOff = Color(0xFF6E5A38),
    vuBezel = listOf(Color(0xFFF7E4A8), Color(0xFF9A7A34), Color(0xFF4A3510)), vuBezelLine = Color(0xFF1A1006), vuInk = Color(0xFF2A1808),
    vuTickLit = Color(0xFFB5560A), vuTickOff = Color(0xFF7A6232), vuKnobAccent = Color(0xFFFFD27A),
    vuLedHouse = listOf(Color(0xFF050301), Color(0xFF1A1208), Color(0xFF050301)),
    vuLedSegOff = listOf(Color(0xFF3A2A12), Color(0xFF140D05)),
    radioBody = listOf(Color(0xFF5A3A1E), Color(0xFF3A2410), Color(0xFF22140A)), radioBodyEdge = Color(0xFFC9A24D),
    radioDisp = listOf(Color(0xFF0A0603), Color(0xFF171009)), radioDispEdge = Color(0xFFC9A24D),
    radioText = Color(0xFFF1D794), radioTextDim = Color(0xFFA98A4C),
    palette = LedPalette("VINTAGE", Color(0xFFFFC76A), Color(0xFFFFA83A), Color(0xFFFFB02E), Color(0xFFFF6A3A), Color(0xFFE08A1E), Color(0xFFFFF0C8)),
    vintage = true,
    litText = Color(0xFF2B1604), bright = Color(0xFFFFEBBE),
    closeBtn = listOf(Color(0xFFC8564A), Color(0xFF7A1A14)),
    knobTooth = Color(0xCC2A1A08),
    vuFace = listOf(Color(0xFFF6E7BE), Color(0xFFEAD6A0), Color(0xFFD9C183)),
    vuNeedle = Color(0xFF1A0E04), vuGlow = Color(0xAAFFC864),
    woodLight = Color(0xFF8A5A2B), woodDark = Color(0xFF1C0F07),
)

object Skin {
    val themes = listOf(THEME_VINTAGE, THEME_OCEAN, THEME_GOM)
    /** Indeks skin aktif; berupa state Compose sehingga seluruh layar ikut berganti warna saat diubah. */
    var index by mutableIntStateOf(0)
        private set
    val t: SkinTheme get() = themes[index.coerceIn(0, themes.lastIndex)]
    val p: LedPalette get() = t.palette

    private const val PREFS = "skin"
    private const val KEY = "index_classic"

    fun init(context: Context) {
        index = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY, 0).coerceIn(0, themes.lastIndex)
    }

    /** Ganti ke skin berikutnya dan simpan pilihan. */
    fun next(context: Context) {
        index = (index + 1) % themes.size
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY, index).apply()
    }
}

/** Lampu LED bulat 3D: cincin krom, lensa kaca dengan kilap, dan cahaya (glow) saat menyala. */
@Composable
fun Led(color: Color, on: Boolean, modifier: Modifier = Modifier, diameter: Dp = 9.dp) {
    Canvas(modifier.size(diameter + 6.dp)) {
        val c = center
        val r = diameter.toPx() / 2f
        val ring = r + 1.6.dp.toPx()
        if (on) {
            drawCircle(
                Brush.radialGradient(listOf(color.copy(alpha = 0.55f), Color.Transparent), c, r * 2.6f),
                radius = r * 2.6f,
                center = c,
            )
        }
        // cincin krom
        drawCircle(
            Brush.verticalGradient(Skin.t.ledRing, c.y - ring, c.y + ring),
            radius = ring, center = c,
        )
        drawCircle(WA_BORDER, radius = ring, center = c, style = Stroke(0.8.dp.toPx()))
        // lensa
        if (on) {
            drawCircle(
                Brush.radialGradient(listOf(Color.White, color, color.copy(alpha = 0.7f)), c - Offset(r * 0.3f, r * 0.3f), r * 1.4f),
                radius = r, center = c,
            )
        } else {
            drawCircle(
                Brush.radialGradient(listOf(color.copy(alpha = 0.38f), Skin.t.ledOff), c - Offset(r * 0.2f, r * 0.2f), r * 1.3f),
                radius = r, center = c,
            )
        }
        // kilap kaca
        drawOval(
            Brush.verticalGradient(listOf(Color.White.copy(alpha = if (on) 0.75f else 0.32f), Color.Transparent), c.y - r, c.y),
            topLeft = Offset(c.x - r * 0.62f, c.y - r * 0.86f),
            size = Size(r * 1.24f, r * 0.8f),
        )
        drawCircle(Color(0x88000000), radius = r, center = c, style = Stroke(0.8.dp.toPx()))
    }
}

/**
 * Panel logam 3D. raised = menonjol (kilap di atas, bayangan di bawah, tepi terang),
 * tidak raised = cekung (bayangan dalam di atas, tepi bawah terang).
 */
fun Modifier.bevel(raised: Boolean = true, fill: Color = WA_PANEL, radius: Dp = 3.dp): Modifier = this.drawBehind {
    val r = CornerRadius(radius.toPx())
    val t = 1.dp.toPx()
    val w = size.width
    val h = size.height
    if (raised && fill == WA_PANEL) {
        drawRoundRect(Brush.verticalGradient(listOf(WA_SILVER_HI, Skin.t.silverMid, WA_SILVER_LO)), cornerRadius = r)
        if (Skin.t.vintage && h > 14.dp.toPx()) {
            // goresan logam sikat (brushed metal): garis halus terang-gelap bergantian, dipotong mengikuti sudut panel
            val clip = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, r)) }
            clipPath(clip) {
                var y = 0f
                var i = 0
                val step = 1.3.dp.toPx()
                while (y < h) {
                    drawLine(if (i % 2 == 0) Color(0x14FFFFFF) else Color(0x0F3A2808), Offset(0f, y), Offset(w, y), 0.7.dp.toPx())
                    y += step
                    i++
                }
            }
        }
    } else {
        drawRoundRect(fill, cornerRadius = r)
    }
    val iw = (w - 2 * t).coerceAtLeast(0f)
    if (raised) {
        // kilap lembut di bagian atas
        val gh = minOf(h * 0.5f, 26.dp.toPx())
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0x66FFFFFF), Color(0x00FFFFFF)), 0f, gh),
            topLeft = Offset(t, t), size = Size(iw, gh.coerceAtLeast(0f)), cornerRadius = r,
        )
        // bayangan di tepi bawah
        val sh = minOf(h * 0.3f, 6.dp.toPx())
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0x00000000), Color(0x44000000)), h - sh, h),
            topLeft = Offset(t, h - sh), size = Size(iw, (sh - t).coerceAtLeast(0f)), cornerRadius = r,
        )
    } else {
        // bayangan dalam (cekung)
        val sh = minOf(h * 0.45f, 8.dp.toPx())
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0x80000000), Color(0x00000000)), 0f, sh),
            topLeft = Offset(t, t), size = Size(iw, sh.coerceAtLeast(0f)), cornerRadius = r,
        )
    }
    drawRoundRect(
        color = if (raised) WA_BORDER else Color(0x66FFFFFF),
        topLeft = Offset(t / 2, t / 2),
        size = Size((w - t).coerceAtLeast(0f), (h - t).coerceAtLeast(0f)),
        cornerRadius = r,
        style = Stroke(t),
    )
    if (raised) {
        // garis terang tipis di dalam tepi atas
        drawRoundRect(
            color = Color(0x99FFFFFF),
            topLeft = Offset(t * 1.5f, t * 1.5f),
            size = Size((w - t * 3f).coerceAtLeast(0f), (h - t * 3f).coerceAtLeast(0f)),
            cornerRadius = CornerRadius((radius.toPx() - t).coerceAtLeast(0f)),
            style = Stroke(0.8.dp.toPx()),
        )
    }
}

/**
 * Latar kayu walnut: gradasi dasar + urat kayu bergelombang yang digambar sekali (tidak digambar ulang saat isi berubah).
 * [light] dan [dark] = warna urat terang / gelap; [vertical] = arah gradasi dasar.
 */
fun Modifier.woodGrain(base: List<Color>, light: Color, dark: Color, vertical: Boolean = true): Modifier = this.drawBehind {
    val w = size.width
    val h = size.height
    drawRect(if (vertical) Brush.verticalGradient(base) else Brush.horizontalGradient(base))
    val step = 2.4.dp.toPx()
    var y = -step
    var i = 0
    while (y < h + step) {
        val n = ((i * 7919 + 131) % 97) / 97f
        val amp = (1.2f + n * 3.8f).dp.toPx()
        val ph = n * 6.28f
        val path = Path()
        path.moveTo(0f, y)
        val seg = w / 7f
        var x = 0f
        for (k in 1..7) {
            val cy = y + sin(ph + k * 0.9f) * amp
            val ey = y + sin(ph + k * 0.6f + 0.8f) * amp * 0.45f
            path.quadraticBezierTo(x + seg * 0.5f, cy, x + seg, ey)
            x += seg
        }
        val c = when (i % 4) {
            0 -> dark.copy(alpha = 0.30f)
            1 -> light.copy(alpha = 0.16f)
            2 -> dark.copy(alpha = 0.14f)
            else -> light.copy(alpha = 0.07f)
        }
        drawPath(path, c, style = Stroke(width = (0.6f + n * 1.4f).dp.toPx()))
        y += step * (0.7f + n * 0.9f)
        i++
    }
    // vinyet halus: tepi lebih gelap seperti kayu berpelitur
    drawRect(Brush.verticalGradient(listOf(Color(0x33000000), Color(0x00000000), Color(0x44000000))))
}

// ------------------------------------------------------------------ jendela

/** Teks satu baris yang tepat di tengah secara vertikal (tanpa ruang kosong ekstra di atas/bawah huruf). Pakai bersama lineHeight. */
val CenteredLine = TextStyle(
    lineHeightStyle = LineHeightStyle(
        alignment = LineHeightStyle.Alignment.Center,
        trim = LineHeightStyle.Trim.Both,
    )
)

/** Tinggi baris judul jendela yang dipakai player (kiri atas) dan playlist (kanan) supaya sama; menyesuaikan tinggi layar HP (22..30 dp). */
@Composable
fun rememberTitleBarHeight(): Dp {
    val screenH = LocalConfiguration.current.screenHeightDp
    return maxOf(22f, minOf(30f, screenH * 0.065f)).dp
}

@Composable
fun WaWindow(
    title: String,
    modifier: Modifier = Modifier,
    fill: Boolean = false,
    contentPadding: Dp = 5.dp,
    titleHeight: Dp = 17.dp,
    actions: (@Composable androidx.compose.foundation.layout.RowScope.() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .shadow(5.dp, RoundedCornerShape(8.dp), clip = false)
            .clip(RoundedCornerShape(8.dp))
            .bevel(true, WA_PANEL, 8.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(titleHeight)
                .background(Brush.verticalGradient(Skin.t.titleGrad))
                .drawBehind {
                    drawLine(if (Skin.t.vintage) Color(0xAAF1D794) else Color(0x66FFFFFF), Offset(0f, 0.5.dp.toPx()), Offset(size.width, 0.5.dp.toPx()), 1.dp.toPx())
                    drawLine(if (Skin.t.vintage) Color(0xFFB98A33) else Color(0x99060C20), Offset(0f, size.height - 0.5.dp.toPx()), Offset(size.width, size.height - 0.5.dp.toPx()), 1.dp.toPx())
                }
                .padding(start = 4.dp, end = if (actions != null) 0.dp else 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Stripes(Modifier.weight(1f))
            Text(
                title,
                color = Skin.t.titleText,
                fontSize = 10.sp,
                fontFamily = MONO,
                fontWeight = FontWeight.Bold,
                letterSpacing = if (Skin.t.vintage) 3.sp else 1.5.sp,
                lineHeight = 12.sp,
                style = CenteredLine,
                modifier = Modifier.padding(horizontal = 7.dp),
            )
            Stripes(Modifier.weight(1f))
            actions?.invoke(this)
        }
        val inner = if (fill) Modifier.weight(1f) else Modifier
        Column(inner.padding(contentPadding), content = content)
    }
}

/**
 * Tombol di baris judul: minimize (biru muda, tanda "–") atau tutup (merah, tanda "×").
 * Digambar dengan garis putih tebal di atas warna solid supaya jelas terlihat; ukuran mengikuti tinggi baris judul
 * (barHeight), sehingga menyesuaikan layar HP yang berbeda.
 */
@Composable
fun WaTitleButton(close: Boolean, description: String, barHeight: Dp, onClick: () -> Unit) {
    val h = barHeight - 6.dp
    Box(
        Modifier
            .width(barHeight * 1.8f)
            .fillMaxHeight()
            .semantics { contentDescription = description }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.size(width = h * 1.5f, height = h)) {
            val r = CornerRadius(5.dp.toPx())
            val colors = if (close) Skin.t.closeBtn else Skin.t.minBtn
            drawRoundRect(Brush.verticalGradient(colors), cornerRadius = r)
            drawRoundRect(if (Skin.t.vintage) Color(0xFF241506) else Color(0xFF0B1330), cornerRadius = r, style = Stroke(1.5.dp.toPx()))
            val cx = size.width / 2f
            val cy = size.height / 2f
            val a = size.height * 0.2f
            val w = 2.6.dp.toPx()
            val cap = androidx.compose.ui.graphics.StrokeCap.Round
            if (close) {
                drawLine(Color.White, Offset(cx - a, cy - a), Offset(cx + a, cy + a), w, cap)
                drawLine(Color.White, Offset(cx - a, cy + a), Offset(cx + a, cy - a), w, cap)
            } else {
                drawLine(if (Skin.t.vintage) Color(0xFF2B1604) else Color.White, Offset(cx - a * 1.3f, cy), Offset(cx + a * 1.3f, cy), w, cap)
            }
        }
    }
}

/** Tombol SKIN di baris judul: tekan untuk ganti skin (OCEAN biru-perak <-> GOM hitam-oranye). */
@Composable
fun SkinButton(barHeight: Dp) {
    val context = LocalContext.current
    val h = barHeight - 8.dp
    val shape = RoundedCornerShape(h / 2)
    Box(
        Modifier
            .fillMaxHeight()
            .padding(horizontal = 4.dp)
            .semantics { contentDescription = "Ganti skin" }
            .clickable {
                Skin.next(context)
                android.widget.Toast.makeText(context, "Skin: ${Skin.t.name}", android.widget.Toast.LENGTH_SHORT).show()
            },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier
                .height(h)
                .clip(shape)
                .background(Brush.verticalGradient(Skin.t.modeOn))
                .border(1.dp, if (Skin.t.vintage) Color(0xFF241506) else Color(0xFF0B1330), shape)
                .padding(horizontal = 9.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "SKIN",
                color = WA_LIT_TEXT,
                fontSize = 9.sp,
                fontFamily = MONO,
                fontWeight = FontWeight.Bold,
                lineHeight = 10.sp,
                style = CenteredLine,
            )
        }
    }
}

/**
 * Dua tombol mode di baris judul player: [MP3] dan [RADIO], masing-masing dengan LED biru di sampingnya.
 * Tombol yang sedang aktif berwarna biru dan LED-nya menyala.
 */
@Composable
fun ModeButtons(mode: AppMode, onChange: (AppMode) -> Unit, barHeight: Dp) {
    val h = barHeight - 8.dp
    val shape = RoundedCornerShape(h / 2)
    Row(
        Modifier.fillMaxHeight().padding(end = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        listOf(AppMode.MP3 to "MP3", AppMode.RADIO to "RADIO").forEach { (m, label) ->
            val on = mode == m
            Row(
                Modifier
                    .fillMaxHeight()
                    .semantics { contentDescription = "Mode $label" }
                    .clickable { onChange(m) },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .height(h)
                        .clip(shape)
                        .background(
                            Brush.verticalGradient(
                                if (on) Skin.t.modeOn
                                else listOf(WA_SILVER_HI, WA_SILVER_LO)
                            )
                        )
                        .border(1.dp, WA_BORDER, shape)
                        .padding(horizontal = 9.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label,
                        color = if (on) WA_LIT_TEXT else WA_INK,
                        fontSize = 9.sp,
                        fontFamily = MONO,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 10.sp,
                        style = CenteredLine,
                    )
                }
                Spacer(Modifier.width(3.dp))
                Led(Skin.p.c3, on, diameter = 7.dp)
            }
        }
    }
}

@Composable
private fun Stripes(modifier: Modifier) {
    Canvas(modifier.height(11.dp)) {
        for (y in listOf(2.5.dp, 5.5.dp, 8.5.dp)) {
            val py = y.toPx()
            drawLine(Skin.t.stripe, Offset(0f, py), Offset(size.width, py), strokeWidth = 1.dp.toPx())
        }
    }
}

// ------------------------------------------------------------------ tombol

/** Tombol pil: biru + teks putih saat aktif, perak + teks biru tua saat tidak. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WaButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    onLongClick: (() -> Unit)? = null,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val lit = active || pressed
    Box(
        modifier
            .height(22.dp)
            .bevel(!lit, if (pressed) Skin.p.c3 else if (active) WA_BLUE else WA_PANEL, 11.dp)
            .combinedClickable(interactionSource = source, indication = null, onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontSize = 9.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            color = if (lit) WA_LIT_TEXT else WA_INK,
        )
    }
}

/** Tombol transport bulat perak dengan ikon hitam. */
@Composable
fun WaIconButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    buttonSize: Dp = 34.dp,
    iconSize: Dp = 18.dp,
    accent: Color = Skin.p.c3,
    active: Boolean = false,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val c = accent
    val lit = pressed || active
    val fill = if (lit) listOf(lerp(c, Color.White, 0.45f), c, lerp(c, Color.Black, 0.3f)) else listOf(WA_SILVER_HI, Skin.t.silverMid, WA_SILVER_LO)
    Box(
        modifier
            .size(buttonSize)
            .shadow(if (pressed) 1.dp else 4.dp, CircleShape)
            .background(Brush.verticalGradient(fill), CircleShape)
            .border(1.5.dp, WA_BORDER, CircleShape)
            .drawBehind {
                val rr = size.minDimension / 2f
                // cincin terang di dalam tepi
                drawCircle(Color(0x88FFFFFF), rr - 2.5.dp.toPx(), style = Stroke(0.8.dp.toPx()))
                // kilap kaca di bagian atas
                drawOval(
                    Brush.verticalGradient(listOf(Color(0xAAFFFFFF), Color(0x00FFFFFF)), 0f, size.height * 0.5f),
                    topLeft = Offset(size.width * 0.16f, size.height * 0.07f),
                    size = Size(size.width * 0.68f, size.height * 0.42f),
                )
            }
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = description,
            tint = if (lit) WA_LIT_TEXT else Skin.t.iconTint,
            modifier = Modifier.size(iconSize),
        )
    }
}

// ------------------------------------------------------------------ slider

/**
 * Slider gaya perak: alur gelap, gagang perak membulat.
 * centered = true: isi warna dari titik tengah (dipakai untuk EQ +/- dB).
 */
@Composable
fun WaSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    vertical: Boolean = false,
    centered: Boolean = false,
    enabled: Boolean = true,
    onDone: () -> Unit = {},
    thumb: Dp = 14.dp,
) {
    val change by rememberUpdatedState(onValueChange)
    val done by rememberUpdatedState(onDone)

    Canvas(
        modifier.pointerInput(enabled, vertical, range) {
            if (!enabled) return@pointerInput
            val pad = thumb.toPx() / 2f
            fun update(p: Offset) {
                val len = (if (vertical) size.height else size.width).toFloat()
                val pos = if (vertical) p.y else p.x
                var frac = ((pos - pad) / max(len - 2 * pad, 1f)).coerceIn(0f, 1f)
                if (vertical) frac = 1f - frac
                change(range.start + frac * (range.endInclusive - range.start))
            }
            awaitEachGesture {
                val down = awaitFirstDown()
                update(down.position)
                down.consume()
                drag(down.id) {
                    update(it.position)
                    it.consume()
                }
                done()
            }
        }
    ) {
        val pad = thumb.toPx() / 2f
        val grooveW = 5.dp.toPx()
        val frac = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
        val len = if (vertical) size.height else size.width
        val cross = if (vertical) size.width else size.height
        val track = len - 2 * pad
        val pos = pad + (if (vertical) (1f - frac) else frac) * track
        val centerPos = pad + track / 2f
        val gTop = (cross - grooveW) / 2f
        val rad = CornerRadius(grooveW / 2f)

        // alur gelap cekung (bayangan dalam + tepi bawah terang)
        if (vertical) {
            drawRoundRect(Color(0x55FFFFFF), Offset(gTop + 1.dp.toPx(), pad + 1.dp.toPx()), Size(grooveW, track), rad)
            drawRoundRect(Brush.horizontalGradient(listOf(Skin.t.grooveDark, Skin.t.grooveLight), gTop, gTop + grooveW), Offset(gTop, pad), Size(grooveW, track), rad)
        } else {
            drawRoundRect(Color(0x55FFFFFF), Offset(pad + 1.dp.toPx(), gTop + 1.dp.toPx()), Size(track, grooveW), rad)
            drawRoundRect(Brush.verticalGradient(listOf(Skin.t.grooveDark, Skin.t.grooveLight), gTop, gTop + grooveW), Offset(pad, gTop), Size(track, grooveW), rad)
        }

        // isi warna (biru; mendekati ujung berubah kuning/merah sebagai peringatan clipping)
        val a = if (centered) centerPos else (if (vertical) pad + track else pad)
        val lo = minOf(a, pos)
        val hi = maxOf(a, pos)
        val dev = if (centered) kotlin.math.abs(frac - 0.5f) * 2f else frac * 0.6f
        var fillColor = if (!enabled) Skin.t.disabledFill else Skin.p.c3
        if (enabled && dev > 0.6f) fillColor = lerp(fillColor, Color(0xFFFFB020), ((dev - 0.6f) * 2.5f).coerceIn(0f, 1f))
        if (enabled && dev > 0.85f) fillColor = lerp(fillColor, Color(0xFFFF4020), ((dev - 0.85f) * 6.6f).coerceIn(0f, 1f))
        if (vertical) {
            if (enabled) drawRoundRect(fillColor.copy(alpha = 0.28f), Offset(gTop - 1.5.dp.toPx(), lo), Size(grooveW + 3.dp.toPx(), hi - lo), CornerRadius(grooveW))
            drawRoundRect(fillColor, Offset(gTop, lo), Size(grooveW, hi - lo), rad)
        } else {
            if (enabled) drawRoundRect(fillColor.copy(alpha = 0.28f), Offset(lo, gTop - 1.5.dp.toPx()), Size(hi - lo, grooveW + 3.dp.toPx()), CornerRadius(grooveW))
            drawRoundRect(fillColor, Offset(lo, gTop), Size(hi - lo, grooveW), rad)
        }

        // garis tengah
        if (centered) {
            val tick = Color(0x99FFFFFF)
            if (vertical) drawLine(tick, Offset(0f, centerPos), Offset(size.width, centerPos), 1.dp.toPx())
            else drawLine(tick, Offset(centerPos, 0f), Offset(centerPos, size.height), 1.dp.toPx())
        }

        // gagang perak membulat
        val tw = thumb.toPx()
        val topLeft = if (vertical) Offset(1.dp.toPx(), pos - tw / 2f) else Offset(pos - tw / 2f, 1.dp.toPx())
        val sz = if (vertical) Size(size.width - 2.dp.toPx(), tw) else Size(tw, size.height - 2.dp.toPx())
        val corner = CornerRadius(4.dp.toPx())
        val body = if (enabled) Skin.t.thumb else Skin.t.thumbOff
        // bayangan jatuh gagang
        drawRoundRect(Color(0x66000000), topLeft + Offset(0f, 1.6.dp.toPx()), sz, corner)
        drawRoundRect(Brush.verticalGradient(body, startY = topLeft.y, endY = topLeft.y + sz.height), topLeft, sz, corner)
        // kilap atas gagang
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0x88FFFFFF), Color(0x00FFFFFF)), topLeft.y, topLeft.y + sz.height * 0.5f),
            topLeft + Offset(1.dp.toPx(), 1.dp.toPx()), Size((sz.width - 2.dp.toPx()).coerceAtLeast(0f), sz.height * 0.45f), corner,
        )
        drawRoundRect(WA_BORDER, topLeft, sz, corner, style = Stroke(1.dp.toPx()))
        val gripDark = Skin.t.grip
        val gripLight = Color(0xCCFFFFFF)
        if (vertical) {
            val x0 = topLeft.x + 3.dp.toPx(); val x1 = topLeft.x + sz.width - 3.dp.toPx()
            drawLine(gripDark, Offset(x0, pos), Offset(x1, pos), 1.dp.toPx())
            drawLine(gripLight, Offset(x0, pos + 1.dp.toPx()), Offset(x1, pos + 1.dp.toPx()), 0.8.dp.toPx())
        } else {
            val y0 = topLeft.y + 3.dp.toPx(); val y1 = topLeft.y + sz.height - 3.dp.toPx()
            drawLine(gripDark, Offset(pos, y0), Offset(pos, y1), 1.dp.toPx())
            drawLine(gripLight, Offset(pos + 1.dp.toPx(), y0), Offset(pos + 1.dp.toPx(), y1), 0.8.dp.toPx())
        }
    }
}

// ------------------------------------------------------------------ spectrum analyzer

@Composable
fun SpectrumView(playing: Boolean, modifier: Modifier = Modifier) {
    val analyzer = remember { SpectrumAnalyzer(AudioEngine.processor) }
    val bars0 = SpectrumAnalyzer.BARS
    var bars by remember { mutableStateOf(FloatArray(bars0)) }
    val peaks = remember { FloatArray(bars0) }
    val playingNow by rememberUpdatedState(playing)

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 30_000_000L) continue
            last = now
            val old = bars
            val idle = !playingNow && old.all { it <= 0f } && peaks.all { it <= 0f }
            if (idle) continue
            val fresh = if (playingNow) analyzer.compute() else FloatArray(bars0)
            val next = FloatArray(bars0) { i -> max(fresh[i], old[i] - 0.07f) }
            for (i in 0 until bars0) peaks[i] = max(next[i], max(peaks[i] - 0.015f, 0f))
            bars = next
        }
    }

    Canvas(modifier) {
        val b = bars
        val n = b.size
        val gap = 1.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        val segs = 14
        val segH = size.height / segs
        for (i in 0 until n) {
            val x = i * (w + gap)
            val lit = (b[i] * segs).toInt()
            for (s in 0 until lit) {
                val t = s / (segs - 1f)
                val color = lerp(Skin.p.specLow, Skin.p.specHigh, t)
                val y = size.height - (s + 1) * segH
                drawRect(color, Offset(x, y + 0.5f), Size(w, segH - 1f))
            }
            val pk = (peaks[i] * segs).toInt().coerceIn(0, segs - 1)
            if (peaks[i] > 0.02f) {
                val y = size.height - (pk + 1) * segH
                drawRect(Skin.p.specHigh, Offset(x, y + 0.5f), Size(w, segH - 1f))
            }
        }
    }
}
