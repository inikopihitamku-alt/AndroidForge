package com.hangat.amp
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView

class MainActivity : Activity() {
 private lateinit var web: WebView
 private var chooser: ValueCallback<Array<Uri>>? = null
 private var pendingPerm: PermissionRequest? = null

 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK
  if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
  startForegroundService(Intent(this, KeepAliveService::class.java))

  web = WebView(this); web.setBackgroundColor(Color.BLACK); setContentView(web)
  web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = false }
  web.webChromeClient = object : WebChromeClient() {
   override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
    chooser?.onReceiveValue(null); chooser = cb
    val pick = Intent(Intent.ACTION_GET_CONTENT).apply { type = "audio/*"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true) }
    startActivityForResult(Intent.createChooser(pick, "Pilih lagu"), 7); return true
   }
   override fun onPermissionRequest(r: PermissionRequest) {
    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) r.grant(r.resources)
    else { pendingPerm = r; requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 8) }
   }
  }
  val html = assets.open("index.html").bufferedReader().use { it.readText() }
  web.loadDataWithBaseURL("https://amp.local/", html, "text/html", "utf-8", null)
 }
 override fun onActivityResult(req: Int, res: Int, data: Intent?) {
  if (req == 7) { chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); chooser = null }
  else super.onActivityResult(req, res, data)
 }
 override fun onRequestPermissionsResult(req: Int, p: Array<out String>, r: IntArray) {
  if (req == 8) { val q = pendingPerm; pendingPerm = null
   if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) q?.grant(q.resources) else q?.deny() }
 }
 override fun onBackPressed() { moveTaskToBack(true) }
 override fun onDestroy() { if (isFinishing) stopService(Intent(this, KeepAliveService::class.java)); web.destroy(); super.onDestroy() }
}
