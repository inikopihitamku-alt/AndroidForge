package com.hangat.amp
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** Menjaga pemutar tetap hidup saat layar mati atau aplikasi di latar belakang. */
class KeepAliveService : Service() {
 private var wl: PowerManager.WakeLock? = null
 override fun onBind(i: Intent?): IBinder? = null
 override fun onCreate() {
  super.onCreate()
  getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("amp", "Pemutar", NotificationManager.IMPORTANCE_LOW))
  val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
  val n = Notification.Builder(this, "amp").setContentTitle("Amplifier Hangat").setContentText("Pemutar aktif")
   .setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(true).build()
  if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(1, n)
  wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "amp:play").apply { acquire() }
 }
 override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
 override fun onDestroy() { wl?.release(); super.onDestroy() }
}
