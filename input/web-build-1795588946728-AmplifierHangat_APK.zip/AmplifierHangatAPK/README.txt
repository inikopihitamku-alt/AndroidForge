AMPLIFIER HANGAT - proyek APK
Build:
1. Android Studio > File > Open > pilih folder AmplifierHangatAPK. Tunggu Gradle sync (butuh internet pertama kali).
2. Build > Build Bundle(s)/APK(s) > Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk. Pasang di HP (Android 8.0+).
Ubah tampilan/suara: edit app/src/main/assets/index.html (sama dengan file preview), lalu build ulang.
