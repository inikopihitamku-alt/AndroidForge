package id.sejukjiwa.kilat

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.text.format.DateUtils
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat

/**
 * Daftar file terbaru (diurutkan dari yang paling baru diubah) untuk dialog "pilih file"
 * saat halaman web meminta unggah file. Pemilih file bawaan Android tidak bisa dipaksa
 * mengurutkan berdasarkan waktu, jadi daftar ini dibuat sendiri dari MediaStore.
 */
object RecentFiles {

    class Item(val uri: Uri, val name: String, val size: Long, val modifiedSec: Long) {
        fun label(ctx: Context): String {
            val whenTxt = DateUtils.getRelativeTimeSpanString(
                modifiedSec * 1000L, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS
            )
            return "$name\n$whenTxt · ${Formatter.formatShortFileSize(ctx, size)}"
        }
    }

    /** Izin yang perlu diminta untuk membaca daftar media di perangkat ini. */
    fun permissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_AUDIO
        ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    fun hasAccess(ctx: Context): Boolean = permissions().any {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    /** Ubah accept="" milik <input type=file> (mis. "image/*", ".pdf") menjadi daftar MIME. */
    private fun mimes(acceptTypes: Array<String>?): List<String> {
        val out = ArrayList<String>()
        for (raw in acceptTypes.orEmpty()) {
            for (t in raw.split(',')) {
                val s = t.trim().lowercase()
                when {
                    s.isEmpty() -> {}
                    s.contains('/') -> out.add(s)
                    s.startsWith(".") ->
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension(s.substring(1))?.let { out.add(it) }
                }
            }
        }
        return out
    }

    /**
     * Apakah daftar MediaStore berguna untuk permintaan ini? Mulai Android 11 dokumen biasa
     * (pdf, zip, dst.) tidak terlihat oleh MediaStore, jadi untuk itu langsung pakai pemilih sistem.
     */
    fun worthIt(acceptTypes: Array<String>?): Boolean {
        val m = mimes(acceptTypes)
        if (m.isEmpty() || Build.VERSION.SDK_INT < 30) return true
        return m.any { it == "*/*" || it.startsWith("image/") || it.startsWith("video/") || it.startsWith("audio/") }
    }

    /** Ambil sampai [limit] file terbaru yang cocok dengan [acceptTypes], paling baru di atas. */
    fun query(ctx: Context, acceptTypes: Array<String>?, limit: Int = 150): List<Item> {
        val base = MediaStore.Files.getContentUri("external")
        val m = mimes(acceptTypes).filter { it != "*/*" }

        val where = StringBuilder("${MediaStore.Files.FileColumns.SIZE} > 0")
        val args = ArrayList<String>()
        if (m.isNotEmpty()) {
            where.append(" AND (")
            m.forEachIndexed { i, mime ->
                if (i > 0) where.append(" OR ")
                if (mime.endsWith("/*")) {
                    where.append("${MediaStore.Files.FileColumns.MIME_TYPE} LIKE ?")
                    args.add(mime.removeSuffix("*") + "%")
                } else {
                    where.append("${MediaStore.Files.FileColumns.MIME_TYPE} = ?")
                    args.add(mime)
                }
            }
            where.append(")")
        } else {
            // tanpa filter: hanya file yang punya tipe media (hindari folder/entri kosong)
            where.append(" AND ${MediaStore.Files.FileColumns.MEDIA_TYPE} != ${MediaStore.Files.FileColumns.MEDIA_TYPE_NONE}")
        }

        val cols = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )
        val res = ArrayList<Item>()
        try {
            ctx.contentResolver.query(
                base, cols, where.toString(), args.toTypedArray(),
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val iName = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val iSize = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val iMod = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                while (c.moveToNext() && res.size < limit) {
                    val name = c.getString(iName) ?: continue
                    res.add(Item(ContentUris.withAppendedId(base, c.getLong(iId)), name, c.getLong(iSize), c.getLong(iMod)))
                }
            }
        } catch (_: Exception) {
            // gagal membaca → kembalikan yang sudah ada (mungkin kosong), pemanggil akan pakai pemilih sistem
        }
        return res
    }
}
