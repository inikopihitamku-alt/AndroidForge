package id.sejukjiwa.kilat

import android.Manifest
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.TextUtils
import android.text.format.Formatter
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowInsetsControllerCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * File manager bawaan CromeAja. Dua fungsi:
 *  - menjelajah berkas (menu "File manager"), ketuk berkas untuk membuka;
 *  - pemilih berkas untuk unggahan situs (EXTRA_PICK), tanpa pemilih berkas sistem.
 * Urutan bawaan: waktu diubah terbaru (folder dulu, berkas di bawahnya).
 */
class FileManagerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PICK = "pick"
        const val EXTRA_MULTI = "multi"
        const val EXTRA_PRIVATE = "private"

        /** Hasil khusus: pengguna minta daftar aplikasi pemilih berkas lain. */
        const val RESULT_OTHER = 7001

        private val EXTRA_COLORS = intArrayOf(
            0xFFFF5252.toInt(), 0xFFE040FB.toInt(), 0xFF7C4DFF.toInt(), 0xFF40C4FF.toInt(),
            0xFF1DE9B6.toInt(), 0xFFFFAB40.toInt(), 0xFFFF4081.toInt(), 0xFF69F0AE.toInt()
        )

        private val SORTS = arrayOf("Terbaru", "Terlama", "Nama A–Z", "Nama Z–A", "Terbesar")
    }

    private class Entry(val file: File, val isDir: Boolean, val mtime: Long, val size: Long) {
        val name: String = file.name
    }

    private class Holder(
        val icon: TextView, val folder: android.widget.ImageView,
        val shape: android.widget.ImageView, val glyph: android.widget.ImageView,
        val title: TextView, val sub: TextView, val check: TextView,
        val apk: android.widget.ImageView
    ) {
        var path: String? = null
    }

    /** Bentuk + gambar + warna + label ikon sebuah jenis berkas. glyph = 0 berarti pakai label ekstensi. */
    private class Badge(val shape: Int, val glyph: Int, val color: Int, val label: String)

    private val perf by lazy { getSharedPreferences("crom_perf", Context.MODE_PRIVATE) }

    private var pick = false
    private var multi = false
    private var priv = false
    private var sort = 0
    private var showHidden = false
    private var dirsTop = true

    private lateinit var roots: List<File>
    private var cur: File = Environment.getExternalStorageDirectory()
    private val items = ArrayList<Entry>()
    private val selected = LinkedHashSet<String>()
    private var clipFiles: List<File> = emptyList()
    private var clipMove = false
    private var baseTitle = ""
    private lateinit var actionBar: LinearLayout
    private lateinit var pasteBar: LinearLayout
    private lateinit var pasteTv: TextView
    private var loadId = 0
    private var started = false

    private lateinit var titleTv: TextView
    private lateinit var pathTv: TextView
    private lateinit var sortTv: TextView
    private lateinit var listView: ListView
    private lateinit var emptyTv: TextView
    private lateinit var permView: View
    private lateinit var bottomBtn: TextView
    private lateinit var chipScroll: HorizontalScrollView
    private val chips = ArrayList<Pair<TextView, File>>()
    private var fgColor = 0
    private var onBrand = 0xFFFFFFFF.toInt()
    private lateinit var adapter: RowAdapter
    private val dateFmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale("id", "ID"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun attrColor(attr: Int): Int {
        val tv = TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        priv = intent.getBooleanExtra(EXTRA_PRIVATE, false)
        if (priv) setTheme(R.style.AppThemePrivate)
        super.onCreate(savedInstanceState)
        pick = intent.getBooleanExtra(EXTRA_PICK, false)
        multi = intent.getBooleanExtra(EXTRA_MULTI, false)
        sort = perf.getInt("fm_sort", 0).coerceIn(0, SORTS.size - 1)
        showHidden = perf.getBoolean("fm_hidden", false)
        dirsTop = perf.getBoolean("fm_dirs_top", true)

        val barBg = attrColor(R.attr.barBg)
        val barFg = attrColor(R.attr.barFg)
        val barDim = attrColor(R.attr.barDim)
        val pageBg = attrColor(R.attr.pageBg)
        val brand = attrColor(R.attr.brand)
        fgColor = barFg
        onBrand = if (ColorUtils.calculateLuminance(brand) > 0.5) 0xFF17111F.toInt() else 0xFFFFFFFF.toInt()

        window.statusBarColor = barBg
        window.navigationBarColor = pageBg
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = ColorUtils.calculateLuminance(barBg) > 0.5
            isAppearanceLightNavigationBars = ColorUtils.calculateLuminance(pageBg) > 0.5
        }

        computeRoots()
        cur = startDir()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pageBg)
        }

        // ---- bilah atas
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(barBg)
            minimumHeight = dp(56)
        }
        val back = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.ic_back)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            contentDescription = "Naik / tutup"
            setOnClickListener { if (!goUp()) finish() }
        }
        top.addView(back, LinearLayout.LayoutParams(dp(52), dp(52)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleTv = TextView(this).apply {
            setTextColor(barFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.END
        }
        pathTv = TextView(this).apply {
            setTextColor(barDim)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.START
        }
        titles.addView(titleTv)
        titles.addView(pathTv)
        top.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sortTv = TextView(this).apply {
            setTextColor(brand)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(10), dp(14), dp(6), dp(14))
            setOnClickListener { showSortDialog() }
        }
        top.addView(sortTv)
        val more = TextView(this).apply {
            text = "⋮"
            setTextColor(barFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(14), dp(8))
            setOnClickListener { showMore(this) }
        }
        top.addView(more)
        root.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- pintasan folder
        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        for ((label, dir) in shortcuts()) {
            val chip = TextView(this).apply {
                text = label
                setTextColor(barFg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setBackgroundResource(R.drawable.bg_field)
                setPadding(dp(14), dp(7), dp(14), dp(7))
                setOnClickListener {
                    cur = dir
                    load()
                }
            }
            chips.add(chip to dir)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = dp(8)
            chipRow.addView(chip, lp)
        }
        chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(barBg)
            addView(chipRow)
        }

        root.addView(chipScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- daftar + keadaan kosong + layar izin
        val body = FrameLayout(this)
        adapter = RowAdapter(barFg, barDim, brand)
        listView = ListView(this).apply {
            divider = null
            setSelector(android.R.color.transparent)
            adapter = this@FileManagerActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> onItemClick(items[pos]) }
            setOnItemLongClickListener { _, _, pos, _ ->
                if (pick) false else { toggleSel(items[pos]); true }
            }
        }
        body.addView(listView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        emptyTv = TextView(this).apply {
            setTextColor(barDim)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        body.addView(emptyTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val perm = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(pageBg)
            setPadding(dp(32), dp(32), dp(32), dp(32))
            visibility = View.GONE
            isClickable = true
        }
        perm.addView(TextView(this).apply {
            text = "File manager CromeAja perlu izin akses file agar bisa menampilkan isi penyimpanan."
            setTextColor(barFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
        })
        perm.addView(TextView(this).apply {
            text = "Beri izin"
            setTextColor(onBrand)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_chip)
            setPadding(dp(28), dp(12), dp(28), dp(12))
            setOnClickListener { requestAccess() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(20) })
        if (pick) {
            perm.addView(TextView(this).apply {
                text = "Pakai pemilih berkas lain"
                setTextColor(brand)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(14), dp(16), dp(14))
                setOnClickListener { useOther() }
            })
        }
        permView = perm
        body.addView(perm, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // ---- tombol "Pilih" (pilih banyak berkas)
        bottomBtn = TextView(this).apply {
            setTextColor(onBrand)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_chip)
            setPadding(dp(16), dp(13), dp(16), dp(13))
            visibility = View.GONE
            setOnClickListener {
                if (selected.isNotEmpty()) finishWith(selected.map { File(it) })
            }
        }
        val bl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bl.setMargins(dp(16), dp(8), dp(16), dp(12))
        root.addView(bottomBtn, bl)

        // ---- bilah aksi (saat berkas dipilih): salin, pindah, hapus, bagikan, lainnya
        actionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(barBg)
            setPadding(dp(4), dp(2), dp(4), dp(2))
            visibility = View.GONE
        }
        fun actBtn(label: String, color: Int, click: (View) -> Unit) {
            actionBar.addView(TextView(this).apply {
                text = label
                setTextColor(color)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(dp(2), dp(14), dp(2), dp(14))
                setOnClickListener(click)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        actBtn("Salin", barFg) { setClip(false) }
        actBtn("Pindah", barFg) { setClip(true) }
        actBtn("Hapus", 0xFFFF5252.toInt()) { confirmDelete() }
        actBtn("Bagikan", barFg) { shareSelected() }
        actBtn("Lainnya", brand) { showSelMore(it) }
        root.addView(actionBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- bilah tempel (setelah Salin / Pindah)
        pasteBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        pasteTv = TextView(this).apply {
            setTextColor(onBrand)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_chip)
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setOnClickListener { pasteHere() }
        }
        pasteBar.addView(pasteTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        pasteBar.addView(TextView(this).apply {
            text = "Batal"
            setTextColor(barFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(13), dp(6), dp(13))
            setOnClickListener { clipFiles = emptyList(); updateBars() }
        })
        val pl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        pl.setMargins(dp(16), dp(8), dp(16), dp(12))
        root.addView(pasteBar, pl)

        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!goUp()) finish()
            }
        })
        updateSortLabel()
    }

    override fun onResume() {
        super.onResume()
        refreshAccess()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // Izin ditolak saat memilih berkas untuk situs: boleh pakai pemilih berkas aplikasi lain
        if (pick && grantResults.isNotEmpty() && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            useOther()
            return
        }
        refreshAccess()
    }

    // =========================================================== izin

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (x: Exception) {
                    Toast.makeText(this, "Tidak dapat membuka pengaturan izin", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
        }
    }

    private fun refreshAccess() {
        if (hasAccess()) {
            permView.visibility = View.GONE
            if (!started) {
                started = true
                load()
            }
        } else {
            permView.visibility = View.VISIBLE
        }
    }

    // =========================================================== lokasi

    private fun computeRoots() {
        val prim = Environment.getExternalStorageDirectory()
        val list = ArrayList<File>()
        list.add(prim)
        try {
            for (d in getExternalFilesDirs(null)) {
                if (d == null) continue
                val i = d.path.indexOf("/Android/data")
                if (i > 0) {
                    val r = File(d.path.substring(0, i))
                    if (r.exists() && list.none { it.path == r.path }) list.add(r)
                }
            }
        } catch (e: Exception) {
            // abaikan: hanya penyimpanan internal
        }
        roots = list
    }

    private fun isRoot(f: File) =
        roots.any { it.path == f.path } || roots.none { f.path.startsWith(it.path + "/") }

    private fun startDir(): File {
        // selalu mulai di penyimpanan internal / Unduhan
        val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        return if (dl.isDirectory) dl else roots[0]
    }

    private fun shortcuts(): List<Pair<String, File>> {
        val prim = roots[0]
        val out = ArrayList<Pair<String, File>>()
        out.add("Unduhan" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))
        for ((label, name) in listOf(
            "Kamera" to "DCIM", "Gambar" to "Pictures", "Dokumen" to "Documents", "Video" to "Movies", "Musik" to "Music"
        )) {
            val d = File(prim, name)
            if (d.isDirectory) out.add(label to d)
        }
        out.add("Penyimpanan" to prim)
        for (i in 1 until roots.size) out.add((if (roots.size > 2) "Kartu SD ${i}" else "Kartu SD") to roots[i])
        return out
    }

    private fun goUp(): Boolean {
        if (!pick && selected.isNotEmpty()) {
            selected.clear()
            adapter.notifyDataSetChanged()
            updateBars()
            return true
        }
        if (isRoot(cur)) return false
        val p = cur.parentFile ?: return false
        cur = p
        load()
        return true
    }

    // =========================================================== muat & urut

    private fun comparator(): Comparator<Entry> {
        val second: Comparator<Entry> = when (sort) {
            0 -> Comparator { a, b -> b.mtime.compareTo(a.mtime) }
            1 -> Comparator { a, b -> a.mtime.compareTo(b.mtime) }
            2 -> Comparator { a, b -> a.name.compareTo(b.name, true) }
            3 -> Comparator { a, b -> b.name.compareTo(a.name, true) }
            else -> Comparator { a, b -> b.size.compareTo(a.size) }
        }
        return Comparator { a, b ->
            if (a.isDir != b.isDir) (if (a.isDir == dirsTop) -1 else 1) else second.compare(a, b)
        }
    }

    private fun load() {
        val dir = cur
        val id = ++loadId
        baseTitle = if (isRoot(dir) && roots.any { it.path == dir.path }) {
            if (dir.path == roots[0].path) "Penyimpanan internal" else "Kartu SD"
        } else dir.name
        pathTv.text = dir.path
        if (!pick) selected.clear()
        updateBars()
        updateChips()
        val cmp = comparator()
        val hidden = showHidden
        Thread {
            val files = dir.listFiles()
            val out = ArrayList<Entry>()
            if (files != null) {
                for (f in files) {
                    if (!hidden && f.name.startsWith(".")) continue
                    val d = f.isDirectory
                    out.add(Entry(f, d, f.lastModified(), if (d) 0L else f.length()))
                }
                out.sortWith(cmp)
            }
            runOnUiThread {
                if (id != loadId || isFinishing) return@runOnUiThread
                items.clear()
                items.addAll(out)
                adapter.notifyDataSetChanged()
                listView.setSelection(0)
                if (out.isEmpty()) {
                    emptyTv.text = if (files == null) "Folder ini tidak bisa dibuka" else "Folder kosong"
                    emptyTv.visibility = View.VISIBLE
                } else {
                    emptyTv.visibility = View.GONE
                }
            }
        }.start()
    }

    /** Tandai pintasan yang sedang aktif (folder terdekat yang memuat lokasi sekarang). */
    private fun updateChips() {
        val c = cur.path
        var best: Pair<TextView, File>? = null
        for (p in chips) {
            val d = p.second.path
            if ((c == d || c.startsWith("$d/")) && (best == null || d.length > best.second.path.length)) best = p
        }
        for (p in chips) {
            val on = p === best
            val t = p.first
            t.setBackgroundResource(if (on) R.drawable.bg_chip else R.drawable.bg_field)
            t.setTextColor(if (on) onBrand else fgColor)
            t.setTypeface(null, if (on) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            t.setPadding(dp(14), dp(7), dp(14), dp(7))
        }
        best?.let { b -> chipScroll.post { chipScroll.smoothScrollTo(maxOf(0, b.first.left - dp(24)), 0) } }
    }

    private fun updateSortLabel() {
        sortTv.text = SORTS[sort] + " ▾"
    }

    private fun showSortDialog() {
        AlertDialog.Builder(this)
            .setTitle("Urutkan")
            .setSingleChoiceItems(SORTS, sort) { d, which ->
                sort = which
                perf.edit().putInt("fm_sort", sort).apply()
                updateSortLabel()
                d.dismiss()
                load()
            }
            .show()
    }

    private fun showMore(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "Tampilkan file tersembunyi").apply { isCheckable = true; isChecked = showHidden }
        pm.menu.add(0, 3, 0, "Folder di atas berkas").apply { isCheckable = true; isChecked = dirsTop }
        if (!pick) pm.menu.add(0, 4, 0, "Folder baru")
        if (pick) pm.menu.add(0, 2, 0, "Pakai pemilih berkas lain…")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> {
                    showHidden = !showHidden
                    perf.edit().putBoolean("fm_hidden", showHidden).apply()
                    load()
                }
                2 -> useOther()
                4 -> newFolderDialog()
                3 -> {
                    dirsTop = !dirsTop
                    perf.edit().putBoolean("fm_dirs_top", dirsTop).apply()
                    load()
                }
            }
            true
        }
        pm.show()
    }

    private fun useOther() {
        setResult(RESULT_OTHER)
        finish()
    }

    // =========================================================== aksi berkas

    private fun onItemClick(e: Entry) {
        when {
            !pick && selected.isNotEmpty() -> toggleSel(e)
            e.isDir -> {
                cur = e.file
                load()
            }
            pick && multi -> {
                val p = e.file.path
                if (!selected.add(p)) selected.remove(p)
                adapter.notifyDataSetChanged()
                updateBottom()
            }
            pick -> finishWith(listOf(e.file))
            else -> when (e.file.extension.lowercase(Locale.ROOT)) {
                "apk" -> installApk(e.file)
                "zip", "xapk", "apks", "apkm", "jar" -> showArchiveDialog(e.file)
                else -> openFile(e.file)
            }
        }
    }

    private fun updateBottom() {
        if (selected.isEmpty()) {
            bottomBtn.visibility = View.GONE
        } else {
            bottomBtn.text = "Pilih (${selected.size})"
            bottomBtn.visibility = View.VISIBLE
        }
    }

    private fun uriFor(f: File): Uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)

    private fun finishWith(files: List<File>) {
        try {
            val uris = files.map { uriFor(it) }
            val res = Intent().setData(uris[0])
            if (uris.size > 1) {
                val clip = ClipData.newRawUri("berkas", uris[0])
                for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
                res.clipData = clip
            }
            res.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            setResult(RESULT_OK, res)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Berkas ini tidak bisa dipilih", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openFile(f: File) {
        try {
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase(Locale.ROOT)) ?: "*/*"
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uriFor(f), mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka berkas ini", Toast.LENGTH_SHORT).show()
        }
    }

    // =========================================================== kelola berkas

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase(Locale.ROOT)) ?: "*/*"

    private fun toggleSel(e: Entry) {
        val p = e.file.path
        if (!selected.add(p)) selected.remove(p)
        adapter.notifyDataSetChanged()
        updateBars()
    }

    private fun updateBars() {
        val selecting = !pick && selected.isNotEmpty()
        actionBar.visibility = if (selecting) View.VISIBLE else View.GONE
        val showPaste = !pick && !selecting && clipFiles.isNotEmpty()
        pasteBar.visibility = if (showPaste) View.VISIBLE else View.GONE
        if (showPaste) pasteTv.text = (if (clipMove) "Pindahkan " else "Tempel ") + "${clipFiles.size} item di sini"
        titleTv.text = if (selecting) "${selected.size} dipilih" else baseTitle
    }

    private fun setClip(move: Boolean) {
        clipFiles = selected.map { File(it) }
        clipMove = move
        selected.clear()
        adapter.notifyDataSetChanged()
        updateBars()
        toast(if (move) "Buka folder tujuan, lalu ketuk Pindahkan" else "Buka folder tujuan, lalu ketuk Tempel")
    }

    /** Jalankan pekerjaan berkas di thread latar dengan dialog tunggu, lalu muat ulang folder. */
    private fun runOp(msg: String, work: () -> Unit) {
        val dlg = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()
        Thread {
            var err: String? = null
            try { work() } catch (t: Throwable) { err = t.message ?: t.javaClass.simpleName }
            runOnUiThread {
                try { dlg.dismiss() } catch (_: Exception) {}
                if (isFinishing) return@runOnUiThread
                if (err != null) toast("Gagal: $err")
                load()
            }
        }.start()
    }

    private fun uniqueDest(dir: File, name: String, isDir: Boolean): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val dot = name.lastIndexOf('.')
        val hasExt = !isDir && dot > 0
        val base = if (hasExt) name.substring(0, dot) else name
        val ext = if (hasExt) name.substring(dot) else ""
        var n = 2
        while (true) {
            f = File(dir, "$base ($n)$ext")
            if (!f.exists()) return f
            n++
        }
    }

    private fun copyRecursive(src: File, dst: File) {
        if (src.isDirectory) {
            dst.mkdirs()
            src.listFiles()?.forEach { copyRecursive(it, File(dst, it.name)) }
        } else {
            src.copyTo(dst, overwrite = false)
        }
    }

    private fun pasteHere() {
        val dest = cur
        val list = clipFiles.toList()
        val move = clipMove
        clipFiles = emptyList()
        updateBars()
        runOp(if (move) "Memindahkan…" else "Menyalin…") {
            for (src in list) {
                if (!src.exists()) continue
                if (src.isDirectory && (dest.path == src.path || dest.path.startsWith(src.path + "/")))
                    throw java.io.IOException("folder tidak bisa dimasukkan ke dalam dirinya sendiri")
                if (move && src.parentFile?.path == dest.path) continue
                val target = uniqueDest(dest, src.name, src.isDirectory)
                if (move) {
                    if (!src.renameTo(target)) {
                        copyRecursive(src, target)
                        if (!src.deleteRecursively()) throw java.io.IOException("gagal menghapus sumber ${src.name}")
                    }
                } else {
                    copyRecursive(src, target)
                }
            }
        }
    }

    private fun confirmDelete() {
        val files = selected.map { File(it) }
        if (files.isEmpty()) return
        val what = if (files.size == 1) "\"${files[0].name}\"" else "${files.size} item"
        AlertDialog.Builder(this)
            .setTitle("Hapus")
            .setMessage("Hapus $what? Tindakan ini tidak bisa dibatalkan.")
            .setPositiveButton("Hapus") { _, _ ->
                selected.clear()
                updateBars()
                runOp("Menghapus…") {
                    for (f in files) if (!f.deleteRecursively()) throw java.io.IOException("tidak bisa menghapus ${f.name}")
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun shareSelected() {
        val files = selected.map { File(it) }.filter { it.isFile }
        if (files.isEmpty()) { toast("Folder tidak bisa dibagikan, pilih berkas"); return }
        try {
            val i = if (files.size == 1) {
                Intent(Intent.ACTION_SEND)
                    .putExtra(Intent.EXTRA_STREAM, uriFor(files[0]))
                    .setType(mimeOf(files[0]))
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE)
                    .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(files.map { uriFor(it) }))
                    .setType("*/*")
            }
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Kirim lewat"))
        } catch (e: Exception) {
            toast("Berkas tidak bisa dibagikan")
        }
    }

    private fun showSelMore(anchor: View) {
        val one = if (selected.size == 1) File(selected.first()) else null
        val pm = PopupMenu(this, anchor)
        if (one != null) pm.menu.add(0, 1, 0, "Ganti nama")
        if (one != null && one.isFile && isArchive(one)) {
            pm.menu.add(0, 2, 0, "Ekstrak di sini")
            pm.menu.add(0, 3, 0, "Ekstrak ke folder baru")
        }
        pm.menu.add(0, 4, 0, "Pilih semua")
        pm.menu.add(0, 5, 0, "Batal pilih")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> one?.let { f -> renameDialog(f) }
                2 -> one?.let { f -> extractTo(f, cur, false) }
                3 -> one?.let { f -> extractTo(f, cur, true) }
                4 -> { items.forEach { e -> selected.add(e.file.path) }; adapter.notifyDataSetChanged(); updateBars() }
                5 -> { selected.clear(); adapter.notifyDataSetChanged(); updateBars() }
            }
            true
        }
        pm.show()
    }

    private fun renameDialog(f: File) {
        val et = android.widget.EditText(this).apply {
            setText(f.name)
            setSingleLine()
            setSelection(0, (if (f.isDirectory) f.name else f.nameWithoutExtension).length.coerceAtMost(f.name.length))
        }
        AlertDialog.Builder(this).setTitle("Ganti nama").setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val n = et.text.toString().trim()
                val t = File(f.parentFile, n)
                when {
                    n.isEmpty() || n.contains('/') -> toast("Nama tidak valid")
                    t.exists() -> toast("Nama sudah dipakai")
                    f.renameTo(t) -> load()
                    else -> toast("Gagal mengganti nama")
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun newFolderDialog() {
        val et = android.widget.EditText(this).apply { hint = "Nama folder"; setSingleLine() }
        AlertDialog.Builder(this).setTitle("Folder baru").setView(et)
            .setPositiveButton("Buat") { _, _ ->
                val n = et.text.toString().trim()
                val t = File(cur, n)
                when {
                    n.isEmpty() || n.contains('/') -> toast("Nama tidak valid")
                    t.exists() -> toast("Nama sudah dipakai")
                    t.mkdirs() -> load()
                    else -> toast("Gagal membuat folder")
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    // ---- arsip ZIP

    private fun isArchive(f: File) = f.extension.lowercase(Locale.ROOT) in setOf("zip", "xapk", "apks", "apkm", "jar")

    private fun showArchiveDialog(f: File) {
        AlertDialog.Builder(this).setTitle(f.name)
            .setItems(arrayOf("Ekstrak di sini", "Ekstrak ke folder “${f.nameWithoutExtension}”", "Buka dengan aplikasi lain")) { _, w ->
                when (w) {
                    0 -> extractTo(f, f.parentFile ?: cur, false)
                    1 -> extractTo(f, f.parentFile ?: cur, true)
                    else -> openFile(f)
                }
            }
            .setNegativeButton("Batal", null).show()
    }

    private fun extractTo(zip: File, parent: File, intoFolder: Boolean) {
        selected.clear()
        updateBars()
        runOp("Mengekstrak…") {
            val dest = if (intoFolder) uniqueDest(parent, zip.nameWithoutExtension, true) else parent
            dest.mkdirs()
            val canon = dest.canonicalPath
            java.util.zip.ZipInputStream(zip.inputStream().buffered()).use { zin ->
                var en = zin.nextEntry
                while (en != null) {
                    val out = File(dest, en.name)
                    val oc = out.canonicalPath
                    if (oc != canon && !oc.startsWith(canon + File.separator))
                        throw java.io.IOException("isi zip tidak aman")
                    if (en.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        val target = if (out.exists()) uniqueDest(out.parentFile ?: dest, out.name, false) else out
                        target.outputStream().buffered().use { zin.copyTo(it) }
                    }
                    zin.closeEntry()
                    en = zin.nextEntry
                }
            }
        }
    }

    // ---- pasang APK

    private fun installApk(f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(this)
                .setTitle("Izin pasang aplikasi")
                .setMessage("Izinkan CromeAja memasang aplikasi dulu di pengaturan, lalu kembali dan ketuk berkas APK ini lagi.")
                .setPositiveButton("Buka pengaturan") { _, _ ->
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                    } catch (e: Exception) {
                        toast("Tidak bisa membuka pengaturan")
                    }
                }
                .setNegativeButton("Batal", null).show()
            return
        }
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uriFor(f), "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            toast("Tidak bisa memasang berkas ini")
        }
    }

    // =========================================================== tampilan baris

    /** Ikon asli aplikasi di dalam berkas .apk (di-cache; dimuat di thread latar). */
    private val apkIcons = android.util.LruCache<String, android.graphics.Bitmap>(120)
    private val apkNoIcon = HashSet<String>()
    private val apkPending = HashSet<String>()
    private val apkPool by lazy { java.util.concurrent.Executors.newFixedThreadPool(2) }

    private fun apkKey(f: File) = f.path + "|" + f.lastModified() + "|" + f.length()

    private fun loadApkIcon(f: File): android.graphics.Bitmap? {
        return try {
            val pm = packageManager
            @Suppress("DEPRECATION")
            val pi = pm.getPackageArchiveInfo(f.path, 0) ?: return null
            val ai = pi.applicationInfo ?: return null
            ai.sourceDir = f.path
            ai.publicSourceDir = f.path
            if (ai.icon == 0) return null
            val d = ai.loadIcon(pm) ?: return null
            val size = 96
            val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
            val c = android.graphics.Canvas(bmp)
            d.setBounds(0, 0, size, size)
            d.draw(c)
            bmp
        } catch (t: Throwable) {
            null
        }
    }

    /** Ikon tiap jenis berkas: bentuk berbeda + warna cerah berbeda (tanpa abu-abu). */
    private fun badgeFor(e: Entry): Badge {
        val ext = e.file.extension.lowercase(Locale.ROOT)
        val label = if (ext.isEmpty()) "FILE" else ext.take(4).uppercase(Locale.ROOT)
        return when (ext) {
            // APK: kepala robot Android, hijau
            "apk", "xapk", "apks", "apkm" ->
                Badge(R.drawable.ic_shape_squircle, R.drawable.ic_glyph_android, 0xFF00C853.toInt(), label)
            // ZIP: kotak arsip beresleting, oranye
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz" ->
                Badge(R.drawable.ic_shape_box, R.drawable.ic_glyph_zip, 0xFFFF9100.toInt(), label)
            // Gambar: segi enam bergambar gunung, pink
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg" ->
                Badge(R.drawable.ic_shape_hex, R.drawable.ic_glyph_image, 0xFFF50057.toInt(), label)
            // Video: persegi panjang dengan tombol putar, ungu
            "mp4", "mkv", "webm", "3gp", "avi", "mov" ->
                Badge(R.drawable.ic_shape_wide, R.drawable.ic_glyph_play, 0xFFAA00FF.toInt(), label)
            // Audio: lingkaran dengan not musik, cyan
            "mp3", "m4a", "wav", "ogg", "flac", "aac", "opus" ->
                Badge(R.drawable.ic_shape_circle, R.drawable.ic_glyph_note, 0xFF00B8D4.toInt(), label)
            // Dokumen berlipat sudut dengan label ekstensi
            "pdf" -> Badge(R.drawable.ic_shape_page, 0, 0xFFFF1744.toInt(), label)
            "doc", "docx", "txt", "rtf", "odt", "epub", "md" -> Badge(R.drawable.ic_shape_page, 0, 0xFF2979FF.toInt(), label)
            "xls", "xlsx", "csv", "ods" -> Badge(R.drawable.ic_shape_page, 0, 0xFF00BFA5.toInt(), label)
            "ppt", "pptx", "odp" -> Badge(R.drawable.ic_shape_page, 0, 0xFFFF5722.toInt(), label)
            "json", "js", "html", "htm", "xml", "css", "kt", "java", "py", "sh" ->
                Badge(R.drawable.ic_shape_page, 0, 0xFF3D5AFE.toInt(), label)
            // jenis lain: dokumen dengan warna cerah sesuai ekstensi
            else -> Badge(
                R.drawable.ic_shape_page, 0,
                EXTRA_COLORS[(ext.hashCode() and 0x7fffffff) % EXTRA_COLORS.size], label
            )
        }
    }

    private inner class RowAdapter(val fg: Int, val dim: Int, val brand: Int) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int) = position.toLong()

        private fun build(): LinearLayout {
            val row = LinearLayout(this@FileManagerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(60)
                setPadding(dp(16), dp(8), dp(12), dp(8))
                setBackgroundResource(R.drawable.bg_row)
            }
            val icon = TextView(this@FileManagerActivity).apply {
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(0xFFFFFFFF.toInt())
                gravity = Gravity.CENTER
                maxLines = 1
            }
            val folder = android.widget.ImageView(this@FileManagerActivity).apply {
                setImageResource(R.drawable.ic_folder)
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                contentDescription = "Folder"
            }
            val shape = android.widget.ImageView(this@FileManagerActivity).apply {
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            }
            val glyph = android.widget.ImageView(this@FileManagerActivity).apply {
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            }
            icon.setPadding(0, dp(9), 0, 0)   // label ekstensi di bagian bawah-tengah dokumen
            val iconBox = FrameLayout(this@FileManagerActivity)
            val full = { FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) }
            iconBox.addView(shape, full())
            iconBox.addView(glyph, full())
            iconBox.addView(icon, full())
            iconBox.addView(folder, full())
            val apkView = android.widget.ImageView(this@FileManagerActivity).apply {
                scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                visibility = View.GONE
            }
            iconBox.addView(apkView, full())
            row.addView(iconBox, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(12) })
            val col = LinearLayout(this@FileManagerActivity).apply { orientation = LinearLayout.VERTICAL }
            val title = TextView(this@FileManagerActivity).apply {
                setTextColor(fg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                isSingleLine = true
                ellipsize = TextUtils.TruncateAt.MIDDLE
            }
            val sub = TextView(this@FileManagerActivity).apply {
                setTextColor(dim)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                isSingleLine = true
            }
            col.addView(title)
            col.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(2) })
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val check = TextView(this@FileManagerActivity).apply {
                text = "✓"
                setTextColor(brand)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                visibility = View.GONE
            }
            row.addView(check, LinearLayout.LayoutParams(dp(32), dp(32)))
            row.tag = Holder(icon, folder, shape, glyph, title, sub, check, apkView)
            return row
        }

        private fun showApkBitmap(h: Holder, bmp: android.graphics.Bitmap) {
            h.shape.visibility = View.GONE
            h.glyph.visibility = View.GONE
            h.icon.visibility = View.GONE
            h.apk.setImageBitmap(bmp)
            h.apk.visibility = View.VISIBLE
        }

        /** Tampilkan ikon asli aplikasi dari .apk; sambil dimuat, ikon robot hijau jadi cadangan. */
        private fun bindApkIcon(h: Holder, e: Entry) {
            val key = apkKey(e.file)
            val cached = apkIcons.get(key)
            if (cached != null) { showApkBitmap(h, cached); return }
            if (apkNoIcon.contains(key) || !apkPending.add(key)) return
            val path = e.file.path
            apkPool.execute {
                val bmp = loadApkIcon(e.file)
                runOnUiThread {
                    apkPending.remove(key)
                    if (isFinishing) return@runOnUiThread
                    if (bmp == null) { apkNoIcon.add(key); return@runOnUiThread }
                    apkIcons.put(key, bmp)
                    adapter.notifyDataSetChanged()
                }
            }
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? LinearLayout) ?: build()
            val h = row.tag as Holder
            val e = items[position]
            h.path = e.file.path
            h.apk.visibility = View.GONE
            if (e.isDir) {
                h.folder.visibility = View.VISIBLE
                h.shape.visibility = View.GONE
                h.glyph.visibility = View.GONE
                h.icon.visibility = View.GONE
            } else {
                val bd = badgeFor(e)
                h.folder.visibility = View.GONE
                h.shape.visibility = View.VISIBLE
                h.shape.setImageResource(bd.shape)
                h.shape.setColorFilter(bd.color, android.graphics.PorterDuff.Mode.SRC_IN)
                if (bd.glyph != 0) {
                    h.glyph.visibility = View.VISIBLE
                    h.glyph.setImageResource(bd.glyph)
                    h.icon.visibility = View.GONE
                } else {
                    h.glyph.visibility = View.GONE
                    h.icon.visibility = View.VISIBLE
                    h.icon.text = bd.label
                    // latar terang -> teks gelap, latar gelap -> teks putih
                    h.icon.setTextColor(
                        if (ColorUtils.calculateLuminance(bd.color) > 0.4) 0xFF1B1B1B.toInt() else 0xFFFFFFFF.toInt()
                    )
                    h.icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (bd.label.length > 3) 8f else 9f)
                }
            }
            if (!e.isDir && e.file.extension.equals("apk", ignoreCase = true)) bindApkIcon(h, e)
            h.title.text = e.name
            val date = dateFmt.format(Date(e.mtime))
            h.sub.text = if (e.isDir) date else date + " · " + Formatter.formatShortFileSize(this@FileManagerActivity, e.size)
            val sel = selected.contains(e.file.path)
            row.isActivated = sel
            h.check.visibility = if (sel) View.VISIBLE else View.GONE
            return row
        }
    }
}
