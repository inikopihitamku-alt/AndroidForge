package id.sejukjiwa.kilat

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.text.InputType
import android.text.format.Formatter
import android.util.TypedValue
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceResponse
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.URLUtil
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private class Tab {
    var web: WebView? = null
    var url = ""
    var title = ""
    var desktop = false
    var pending: String? = null     // URL yang akan dimuat saat WebView dibuat
    var state: Bundle? = null       // status WebView saat tab "ditidurkan"
    var errorFor: String? = null    // URL yang gagal dimuat (halaman error sedang tampil)
    var progress = 100
    var lastUsed = 0L
    var thumb: Bitmap? = null       // cuplikan halaman untuk daftar tab
    var ntVer = -1                  // versi pintasan saat halaman tab baru dimuat
}

/** WebView yang tidak ikut "disembunyikan" saat aplikasi ke latar belakang, supaya audio/video (mis. YouTube) tetap diputar. */
private class BgWebView(ctx: Context) : WebView(ctx) {
    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility != View.GONE) super.onWindowVisibilityChanged(View.VISIBLE)
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, if (visibility == View.GONE) visibility else View.VISIBLE)
    }
}

private class Row(val title: String, val url: String, val active: Boolean, val site: String = "")

private fun sameUrl(a: String, b: String) = a.trimEnd('/') == b.trimEnd('/')

open class MainActivity : AppCompatActivity() {

    protected open val isPrivate = false

    private lateinit var store: Store
    private val tabs = ArrayList<Tab>()
    private var cur = -1

    private lateinit var webHost: FrameLayout
    private lateinit var swipe: androidx.swiperefreshlayout.widget.SwipeRefreshLayout
    private lateinit var urlInput: EditText
    private lateinit var icSecurity: ImageView
    private lateinit var btnReload: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var btnBack: ImageView
    private lateinit var btnFwd: ImageView
    private lateinit var btnBookmark: ImageView
    private lateinit var btnSave: ImageView
    private lateinit var btnDownload: ImageView
    private lateinit var dlRing: RingView
    private lateinit var dlList: ListView
    private lateinit var tabCount: TextView
    private lateinit var findBar: View
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView
    private lateinit var panel: View
    private lateinit var panelTitle: TextView
    private lateinit var panelAction: TextView
    private lateinit var panelList: ListView
    private lateinit var tabGrid: GridView
    private lateinit var panelEmpty: TextView
    private lateinit var fullscreen: FrameLayout

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var panelMode = P_NONE
    private var shortVer = 0
    private var homeEdit = false
    private var ptrOn = true                  // tarik-ke-bawah untuk muat ulang (bisa dimatikan lewat menu)
    @Volatile private var ptrBlock = false   // true selama jari menyentuh elemen halaman yang bisa digulir sendiri

    /** Jembatan kecil dari skrip halaman: hanya menerima true/false untuk menahan tarik-untuk-muat-ulang. */
    private inner class PtrBridge {
        @android.webkit.JavascriptInterface
        fun block(b: Boolean) { ptrBlock = b }
    }
    private var panelRows: List<Row> = emptyList()
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingDl: Array<String?>? = null
    private lateinit var baseUa: String
    private lateinit var desktopUa: String
    private val ui = Handler(Looper.getMainLooper())
    private var adBlock = true
    private val perf by lazy { getSharedPreferences("crom_perf", Context.MODE_PRIVATE) }

    // status unduhan
    private lateinit var dls: DlManager
    private var dlUnseen = 0                       // 0 tidak ada, 1 ada yang selesai, 2 ada yang gagal
    private var dlBounce: ObjectAnimator? = null

    private var fileBase: Intent? = null

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            // "Pakai pemilih berkas lain" di file manager bawaan: tampilkan daftar aplikasi lain
            val base = fileBase
            if (r.resultCode == FileManagerActivity.RESULT_OTHER && base != null && fileCb != null) {
                try {
                    chooseFileManager(base)
                    return@registerForActivityResult
                } catch (e: Exception) {
                    // lanjut: batalkan permintaan berkas
                }
            }
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
            fileCb = null
        }

    /**
     * Saat situs meminta berkas: tampilkan daftar aplikasi file manager (semua yang bisa memilih
     * berkas), bukan langsung pemilih bawaan Android yang urutannya berdasarkan nama.
     * Pilihan terakhir ditaruh paling atas.
     */
    private fun chooseFileManager(base: Intent) {
        // Minta pemilih berkas langsung membuka folder Unduhan (diabaikan bila aplikasinya tidak mendukung).
        if (Build.VERSION.SDK_INT >= 26) {
            base.putExtra(
                android.provider.DocumentsContract.EXTRA_INITIAL_URI,
                Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload")
            )
        }
        val pm = packageManager
        val found = LinkedHashMap<String, android.content.pm.ResolveInfo>()   // satu entri per aplikasi
        for (act in listOf(Intent.ACTION_GET_CONTENT, Intent.ACTION_OPEN_DOCUMENT)) {
            val probe = Intent(act).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            for (ri in pm.queryIntentActivities(probe, 0)) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == packageName) continue
                if (!found.containsKey(pkg)) found[pkg] = ri
            }
        }
        val last = perf.getString("fm_last", null)
        val list = found.values.sortedByDescending { it.activityInfo.packageName == last }
        if (list.isEmpty()) {
            fileLauncher.launch(Intent.createChooser(base, "Pilih file manager"))
            return
        }
        val labels = list.map { it.loadLabel(pm).toString() }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih file manager")
            .setItems(labels) { _, which ->
                val ri = list[which]
                perf.edit().putString("fm_last", ri.activityInfo.packageName).apply()
                val i = Intent(base).setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                try {
                    fileLauncher.launch(i)
                } catch (e: Exception) {
                    // aplikasi menolak intent ini: pakai pemilih bawaan sistem
                    try {
                        fileLauncher.launch(Intent.createChooser(base, "Pilih file manager"))
                    } catch (x: Exception) {
                        fileCb?.onReceiveValue(null)
                        fileCb = null
                    }
                }
            }
            .setOnCancelListener {
                fileCb?.onReceiveValue(null)
                fileCb = null
            }
            .show()
    }

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val stopKeep = Runnable { keepAlive(false) }

    private fun keepAlive(on: Boolean) {
        if (isPrivate) return
        try {
            val i = Intent(this, KeepAliveService::class.java)
            if (on) ContextCompat.startForegroundService(this, i) else stopService(i)
        } catch (e: Exception) {
            // abaikan: sistem menolak layanan latar depan
        }
    }

    private val storagePerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val d = pendingDl
            pendingDl = null
            if (ok && d != null) enqueueDownload(d[0]!!, d[1], d[2], d[3]!!)
            else toast("Izin penyimpanan diperlukan untuk mengunduh")
        }

    // =========================================================== siklus hidup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this, !isPrivate)
        dls = DlManager.get(this, !isPrivate)
        setContentView(R.layout.activity_main)

        webHost = findViewById(R.id.webHost)
        swipe = findViewById(R.id.swipe)
        swipe.setColorSchemeColors(attrColor(R.attr.brand))
        swipe.setProgressBackgroundColorSchemeColor(attrColor(R.attr.barBg))
        // Tarik dari atas ke bawah (saat halaman ada di posisi paling atas) = muat ulang; tidak berlaku bila sentuhan dimulai di dalam area yang bisa digulir sendiri (kalender, daftar, peta)
        swipe.setOnChildScrollUpCallback { _, _ -> ptrBlock || (curWeb()?.scrollY ?: 0) > 0 }
        swipe.isEnabled = ptrOn
        swipe.setOnRefreshListener {
            curTab()?.let { reloadTab(it) }
            swipe.postDelayed({ swipe.isRefreshing = false }, 1500)
        }
        urlInput = findViewById(R.id.urlInput)
        icSecurity = findViewById(R.id.icSecurity)
        btnReload = findViewById(R.id.btnReload)
        progress = findViewById(R.id.progress)
        btnBack = findViewById(R.id.btnBack)
        btnFwd = findViewById(R.id.btnFwd)
        btnBookmark = findViewById(R.id.btnBookmark)
        btnSave = findViewById(R.id.btnSave)
        btnDownload = findViewById(R.id.btnDownload)
        dlRing = findViewById(R.id.dlRing)
        dlList = findViewById(R.id.dlList)
        tabCount = findViewById(R.id.tabCount)
        findBar = findViewById(R.id.findBar)
        findInput = findViewById(R.id.findInput)
        findCount = findViewById(R.id.findCount)
        panel = findViewById(R.id.panel)
        panelTitle = findViewById(R.id.panelTitle)
        panelAction = findViewById(R.id.panelAction)
        panelList = findViewById(R.id.panelList)
        tabGrid = findViewById(R.id.tabGrid)
        panelEmpty = findViewById(R.id.panelEmpty)
        fullscreen = findViewById(R.id.fullscreen)

        if (isPrivate) {
            findViewById<View>(R.id.privChip).visibility = View.VISIBLE
            btnBookmark.visibility = View.GONE
            btnSave.visibility = View.GONE
        }

        if (!isPrivate && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)

        setupBars()
        adBlock = perf.getBoolean("adblock", true)
        ptrOn = perf.getBoolean("ptr", true)
        setupUserAgents()
        wireUi()
        dls.onChange = { onDlChange() }
        dls.onFinished = { d ->
            if (d.state == DlManager.DONE) {
                if (dlUnseen == 0) dlUnseen = 1
                toast("Unduhan selesai: ${d.name}")
            } else {
                dlUnseen = 2
                toast("Unduhan gagal: ${d.name}" + (d.error?.let { " ($it)" } ?: ""))
            }
            onDlChange()
        }
        onDlChange()
        restoreTabs(intent)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = onBack()
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_VIEW) {
            intent.dataString?.let { newTab(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        curWeb()?.onResume()
        onDlChange()
        ui.removeCallbacks(stopKeep)
        ui.postDelayed(stopKeep, 1500)
    }

    override fun onPause() {
        // WebView sengaja tidak di-pause: halaman tetap berjalan di latar belakang
        ui.removeCallbacks(stopKeep)
        if (!isFinishing) keepAlive(true)
        CookieManager.getInstance().flush()
        if (!isPrivate) {
            store.save()
            store.saveSession(tabs.map { if (it.errorFor != null) it.errorFor!! else it.url.ifEmpty { NEWTAB } }, cur)
        }
        super.onPause()
    }

    /** Memori HP menipis: tab latar belakang dilepas (status tersimpan, dimuat ulang saat dibuka). */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            tabs.filter { it.web != null && it !== curTab() }.forEach { discard(it) }
        }
    }

    override fun onDestroy() {
        dls.onChange = null
        dls.onFinished = null
        dlBounce?.cancel()
        if (isFinishing) { ui.removeCallbacks(stopKeep); keepAlive(false) }
        if (isPrivate && isFinishing) {
            try {
                curWeb()?.clearCache(true)
                tabs.forEach { destroyWeb(it) }
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
            } catch (e: Exception) {
                // abaikan
            }
            super.onDestroy()
            android.os.Process.killProcess(android.os.Process.myPid())
            return
        }
        tabs.forEach { destroyWeb(it) }
        super.onDestroy()
    }

    // =========================================================== setup

    private fun attrColor(attr: Int): Int {
        val tv = TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }

    private fun setupBars() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val dark = isPrivate || night
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
        window.statusBarColor = attrColor(R.attr.barBg)
        window.navigationBarColor = attrColor(R.attr.barBg)
    }

    private fun setupUserAgents() {
        val def = WebSettings.getDefaultUserAgent(this)
        baseUa = def.replace("; wv", "").replace(" Version/4.0", "")
        desktopUa = baseUa
            .replace(Regex("\\(Linux; Android[^)]*\\)"), "(X11; Linux x86_64)")
            .replace(" Mobile", "")
    }

    private fun wireUi() {
        urlInput.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO ||
                (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)
            ) {
                go(urlInput.text.toString())
                true
            } else false
        }
        urlInput.setOnFocusChangeListener { _, focused ->
            val t = curTab()
            if (focused) {
                urlInput.setText(if (t == null || isNewTab(t.url) || t.url.startsWith("file:")) "" else t.url)
                urlInput.post { urlInput.selectAll() }
            } else {
                urlInput.setText(display(t?.url ?: ""))
            }
        }
        btnReload.setOnClickListener {
            val t = curTab() ?: return@setOnClickListener
            if (t.progress in 1..99) {
                t.web?.stopLoading()
                t.progress = 100
                updateLoading(t)
            } else reloadTab(t)
        }
        btnBack.setOnClickListener { curWeb()?.let { if (it.canGoBack()) it.goBack() } }
        btnFwd.setOnClickListener { curWeb()?.let { if (it.canGoForward()) it.goForward() } }
        btnBookmark.setOnClickListener { toggleBookmark() }
        btnSave.setOnClickListener { savePage() }
        btnDownload.setOnClickListener { showDownloads() }
        findViewById<View>(R.id.btnNewTab).setOnClickListener { openNewTabAndFocus() }
        findViewById<View>(R.id.btnTabs).setOnClickListener { showPanel(P_TABS) }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        panelList.adapter = rowAdapter
        dlList.adapter = dlAdapter
        panelList.setOnItemClickListener { _, _, i, _ -> onRowClick(i) }
        tabGrid.adapter = tabAdapter
        tabGrid.setOnItemClickListener { _, _, i, _ -> selectTab(i); closePanel() }
        findViewById<View>(R.id.panelClose).setOnClickListener { closePanel() }
        panelAction.setOnClickListener { onPanelAction() }

        findInput.doAfterTextChanged { s ->
            val q = s?.toString().orEmpty()
            if (q.isEmpty()) {
                curWeb()?.clearMatches()
                findCount.text = ""
            } else curWeb()?.findAllAsync(q)
        }
        findInput.setOnEditorActionListener { _, _, _ -> curWeb()?.findNext(true); true }
        findViewById<View>(R.id.findNext).setOnClickListener { curWeb()?.findNext(true) }
        findViewById<View>(R.id.findPrev).setOnClickListener { curWeb()?.findNext(false) }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }
    }

    private fun restoreTabs(i: Intent?) {
        val start = if (i != null && i.action == Intent.ACTION_VIEW) i.dataString else null
        if (!isPrivate) {
            val (urls, idx) = store.loadSession()
            for (u in urls) {
                val t = Tab()
                t.pending = u
                t.url = u
                tabs.add(t)
            }
            if (tabs.isNotEmpty()) selectTab(idx.coerceIn(0, tabs.size - 1))
        }
        if (start != null) newTab(start) else if (tabs.isEmpty()) newTab(null)
    }

    private fun onBack() {
        when {
            customView != null -> hideCustom()
            panel.visibility == View.VISIBLE -> closePanel()
            findBar.visibility == View.VISIBLE -> closeFind()
            urlInput.hasFocus() -> { urlInput.clearFocus(); hideKeyboard() }
            curWeb()?.canGoBack() == true -> curWeb()?.goBack()
            tabs.size > 1 -> closeTab(cur)
            else -> finish()
        }
    }

    // =========================================================== tab

    private fun curTab(): Tab? = tabs.getOrNull(cur)
    private fun curWeb(): WebView? = curTab()?.web

    private fun newTab(url: String?, select: Boolean = true, load: Boolean = true): Tab {
        val t = Tab()
        if (load) {
            t.pending = url ?: NEWTAB
            t.url = url ?: NEWTAB
        }
        tabs.add(t)
        if (select) selectTab(tabs.size - 1)
        return t
    }

    private fun openNewTabAndFocus() {
        closePanel()
        newTab(null)
        urlInput.setText("")   // tab baru: kolom alamat selalu kosong, tidak membawa URL tab sebelumnya
        urlInput.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(urlInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun selectTab(i: Int) {
        if (i !in tabs.indices) return
        curTab()?.let { if (it.thumb == null && panel.visibility != View.VISIBLE) captureSoft(it) }
        curTab()?.web?.let {
            it.onPause()
            webHost.removeView(it)
        }
        cur = i
        val t = tabs[i]
        val w = ensureWeb(t)
        t.lastUsed = SystemClock.uptimeMillis()
        if (w.parent == null) {
            webHost.addView(
                w,
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }
        w.onResume()
        if (isNewTab(t.url) && t.errorFor == null && t.ntVer >= 0 && t.ntVer != shortVer) loadNewTab(t, w)
        discardOld()
        closeFind()
        refreshUi()
        // Kolom alamat sedang fokus (updateAddress tidak menimpanya): kosongkan bila tab yang dipilih adalah tab baru.
        if (isNewTab(t.url) && urlInput.hasFocus()) urlInput.setText("")
    }

    private fun closeTab(i: Int) {
        if (i !in tabs.indices) return
        val t = tabs.removeAt(i)
        destroyWeb(t)
        if (tabs.isEmpty()) {
            cur = -1
            if (isPrivate) finish() else newTab(null)
            return
        }
        if (i == cur) {
            cur = -1
            selectTab(minOf(i, tabs.size - 1))
        } else {
            if (i < cur) cur--
            refreshUi()
        }
    }

    /** Menjaga memori: hanya beberapa WebView hidup; sisanya disimpan statusnya. */
    private fun discardOld() {
        val live = tabs.filter { it.web != null && it !== curTab() }
        if (live.size <= MAX_LIVE - 1) return
        live.sortedBy { it.lastUsed }.take(live.size - (MAX_LIVE - 1)).forEach { discard(it) }
    }

    private fun discard(t: Tab) {
        val w = t.web ?: return
        if (t.errorFor != null) {
            t.pending = t.errorFor
        } else if (isNewTab(t.url)) {
            t.pending = NEWTAB
        } else {
            val b = Bundle()
            w.saveState(b)
            t.state = b
        }
        destroyWeb(t)
    }

    private fun destroyWeb(t: Tab) {
        val w = t.web ?: return
        t.web = null
        (w.parent as? ViewGroup)?.removeView(w)
        w.stopLoading()
        w.webChromeClient = null
        w.destroy()
    }

    private fun ensureWeb(t: Tab): WebView {
        t.web?.let { return it }
        val w = makeWeb(t)
        t.web = w
        val st = t.state
        val p = t.pending
        t.state = null
        t.pending = null
        when {
            st != null -> {
                if (w.restoreState(st) == null && t.url.isNotEmpty()) w.loadUrl(t.url)
            }
            p == null -> {}
            isNewTab(p) -> { t.url = NEWTAB; loadNewTab(t, w) }
            else -> { t.url = p; w.loadUrl(p) }
        }
        return w
    }

    // =========================================================== WebView

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(t: Tab): WebView {
        val w = BgWebView(this)
        w.setBackgroundColor(attrColor(R.attr.pageBg))
        // Isi otomatis sistem (mis. Google Password Manager) agar akun/kata sandi tersimpan muncul di kolom login.
        // Dimatikan di mode pribadi supaya tidak ada data login yang tersimpan.
        if (Build.VERSION.SDK_INT >= 26) {
            w.importantForAutofill =
                if (isPrivate) View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS else View.IMPORTANT_FOR_AUTOFILL_YES
        }
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = true
        s.allowFileAccess = true   // hanya untuk halaman offline; file lain diblokir di handleUrl
        s.allowFileAccessFromFileURLs = false
        s.allowUniversalAccessFromFileURLs = false
        s.allowContentAccess = false
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.setSupportMultipleWindows(true)
        // WebView biasanya menambahkan header "X-Requested-With: <nama paket>" yang dipakai situs
        // (Google, GitHub, dll.) untuk mengenali WebView dan menyembunyikan tombol "Lanjutkan dengan Google/Apple".
        // Header itu dimatikan agar halaman tampil seperti di Chrome.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
            WebSettingsCompat.setRequestedWithHeaderOriginAllowList(s, emptySet())
        }
        // Safe Browsing memeriksa tiap alamat ke server Google sebelum halaman dibuka (menambah jeda).
        // Ubah SAFE_BROWSING ke true bila ingin perlindungan situs berbahaya aktif lagi.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) {
            WebSettingsCompat.setSafeBrowsingEnabled(s, SAFE_BROWSING)
        }
        enableWebAuthn(s)
        chromeBrandHints(s)
        // Proses render tetap berprioritas tinggi walau aplikasi di latar belakang (audio/video tidak ikut dimatikan sistem)
        if (Build.VERSION.SDK_INT >= 26) {
            try { w.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false) } catch (e: Throwable) { /* abaikan */ }
        }
        // Halaman dianggap selalu terlihat, jadi situs (mis. YouTube) tidak menjeda media saat aplikasi di latar belakang
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(w, BG_JS, setOf("*"))
                WebViewCompat.addDocumentStartJavaScript(w, PTR_JS, setOf("*"))
            }
        } catch (e: Throwable) {
            // abaikan
        }
        // Khusus github.com: bila WebView tidak punya WebAuthn sama sekali, sediakan stub agar GitHub
        // tetap menampilkan pilihan login lain (Google/Apple). Stub tidak dipasang bila API aslinya ada.
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(w, SHIM_JS, setOf("https://github.com"))
            }
        } catch (e: Throwable) {
            // abaikan
        }
        applyDesktop(w, t)
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(w, !isPrivate)
        }
        w.addJavascriptInterface(PtrBridge(), "CromPtr")
        w.setDownloadListener { url, ua, cd, mime, len -> startDownload(url, ua, cd, mime, len) }
        w.webViewClient = makeClient(t)
        w.webChromeClient = makeChrome(t)
        w.setOnLongClickListener { onLongPress(w) }
        w.setFindListener { active, total, _ ->
            if (t === curTab() && findInput.text.isNotEmpty()) {
                findCount.text = if (total > 0) "${active + 1}/$total" else "0/0"
            }
        }
        return w
    }

    /**
     * Mengaktifkan WebAuthn/passkey di WebView (butuh WebView 128+). Tanpa ini situs seperti GitHub menganggap
     * browser tidak mendukung passkey dan ikut menyembunyikan "Continue with Google/Apple".
     * Dipanggil lewat refleksi agar build tetap aman bila versi library berbeda.
     */
    private fun enableWebAuthn(s: WebSettings) {
        try {
            if (!WebViewFeature.isFeatureSupported("WEB_AUTHENTICATION")) return
            Class.forName("androidx.webkit.WebSettingsCompat")
                .getMethod("setWebAuthenticationSupport", WebSettings::class.java, Int::class.javaPrimitiveType)
                .invoke(null, s, 2)   // 2 = WEB_AUTHENTICATION_SUPPORT_FOR_BROWSER (aplikasi ini adalah browser, bukan app terikat satu situs)
        } catch (e: Throwable) {
            // tidak didukung di perangkat ini
        }
    }

    /**
     * Header Sec-CH-UA bawaan WebView memuat merek "Android WebView" (Chrome memakai "Google Chrome").
     * Merek itu diganti agar situs seperti Google memperlakukan browser ini seperti Chrome.
     * Lewat refleksi (dan dibungkus try) supaya build tetap aman bila library/WebView tidak mendukung.
     */
    private fun chromeBrandHints(s: WebSettings) {
        try {
            if (!WebViewFeature.isFeatureSupported("USER_AGENT_METADATA")) return
            val compat = Class.forName("androidx.webkit.WebSettingsCompat")
            val uam = Class.forName("androidx.webkit.UserAgentMetadata")
            val bv = Class.forName("androidx.webkit.UserAgentMetadata\$BrandVersion")
            val bvb = Class.forName("androidx.webkit.UserAgentMetadata\$BrandVersion\$Builder")
            val uamb = Class.forName("androidx.webkit.UserAgentMetadata\$Builder")
            val def = compat.getMethod("getUserAgentMetadata", WebSettings::class.java).invoke(null, s) ?: return
            val old = uam.getMethod("getBrandVersionList").invoke(def) as? List<*> ?: return
            val list = old.map { b ->
                val brand = bv.getMethod("getBrand").invoke(b) as String
                val major = bv.getMethod("getMajorVersion").invoke(b) as String
                val full = bv.getMethod("getFullVersion").invoke(b) as String
                val nb = bvb.getConstructor().newInstance()
                bvb.getMethod("setBrand", String::class.java).invoke(nb, if (brand.contains("WebView", true)) "Google Chrome" else brand)
                bvb.getMethod("setMajorVersion", String::class.java).invoke(nb, major)
                bvb.getMethod("setFullVersion", String::class.java).invoke(nb, full)
                bvb.getMethod("build").invoke(nb)
            }
            val builder = uamb.getConstructor(uam).newInstance(def)
            uamb.getMethod("setBrandVersionList", List::class.java).invoke(builder, list)
            val meta = uamb.getMethod("build").invoke(builder)
            compat.getMethod("setUserAgentMetadata", WebSettings::class.java, uam).invoke(null, s, meta)
        } catch (e: Throwable) {
            // tidak didukung di perangkat ini
        }
    }

    private fun applyDesktop(w: WebView, t: Tab) {
        val s = w.settings
        s.userAgentString = if (t.desktop) desktopUa else baseUa
        s.useWideViewPort = true
        s.loadWithOverviewMode = t.desktop
    }

    private fun makeClient(t: Tab) = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
            handleUrl(view, request.url.toString())

        // Blokir iklan & pelacak (hanya sub-sumber daya, halaman utama tidak pernah diblokir): halaman lebih ringan dan cepat.
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            if (adBlock && !request.isForMainFrame && (isAdHost(request.url.host) || isAdPath(request.url.path))) {
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            return null
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            if (url != t.errorFor) t.errorFor = null
            t.url = url
            t.progress = 5
            if (t === curTab()) {
                updateAddress(t)
                updateLoading(t)
                updateNav()
            }
        }

        override fun onPageFinished(view: WebView, url: String) {
            t.progress = 100
            if (t === curTab()) swipe.isRefreshing = false
            view.evaluateJavascript(ZOOM_JS, null)
            view.evaluateJavascript(PTR_JS, null)
            if (adBlock && url.startsWith("http")) view.evaluateJavascript(HIDE_ADS_JS, null)
            t.title = view.title ?: ""
            if (t.errorFor == null) addHistory(t, url)
            if (t === curTab()) {
                updateAddress(t)
                updateLoading(t)
                updateNav()
            }
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            t.url = url
            if (t === curTab()) {
                updateAddress(t)
                updateNav()
            }
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (!request.isForMainFrame) return
            val u = request.url.toString()
            t.errorFor = u
            view.loadDataWithBaseURL(
                u, errorHtml(u, error.description.toString(), if (isPrivate) null else store.findSaved(u)),
                "text/html", "utf-8", u
            )
        }
    }

    private fun makeChrome(t: Tab) = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            t.progress = newProgress
            if (t === curTab()) updateLoading(t)
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            t.title = title ?: ""
            if (!isPrivate) store.setTitle(view.url, title)
        }

        override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden()
                return
            }
            customView = view
            customCb = callback
            fullscreen.addView(view)
            fullscreen.visibility = View.VISIBLE
            setBars(false)
        }

        override fun onHideCustomView() = hideCustom()

        override fun onShowFileChooser(
            webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams
        ): Boolean {
            fileCb?.onReceiveValue(null)
            fileCb = filePathCallback
            try {
                fileBase = params.createIntent()
                // File manager bawaan CromeAja (urut terbaru), bukan pemilih berkas sistem
                fileLauncher.launch(
                    Intent(this@MainActivity, FileManagerActivity::class.java)
                        .putExtra(FileManagerActivity.EXTRA_PICK, true)
                        .putExtra(
                            FileManagerActivity.EXTRA_MULTI,
                            params.mode == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE
                        )
                        .putExtra(FileManagerActivity.EXTRA_PRIVATE, isPrivate)
                )
            } catch (e: Exception) {
                fileCb?.onReceiveValue(null)
                fileCb = null
            }
            return true
        }

        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
            if (!isUserGesture) return false      // blokir popup otomatis
            val nt = newTab(null, select = true, load = false)
            val transport = resultMsg.obj as WebView.WebViewTransport
            transport.webView = nt.web
            resultMsg.sendToTarget()
            return true
        }

        override fun onCloseWindow(window: WebView) {
            val i = tabs.indexOfFirst { it.web === window }
            if (i >= 0) closeTab(i)
        }

        override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setTitle(Uri.parse(url).host ?: "")
                .setMessage(message)
                .setPositiveButton("OK") { _, _ -> result.confirm() }
                .setOnCancelListener { result.cancel() }
                .show()
            return true
        }

        override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setTitle(Uri.parse(url).host ?: "")
                .setMessage(message)
                .setPositiveButton("OK") { _, _ -> result.confirm() }
                .setNegativeButton("Batal") { _, _ -> result.cancel() }
                .setOnCancelListener { result.cancel() }
                .show()
            return true
        }

        override fun onJsPrompt(
            view: WebView, url: String, message: String, defaultValue: String?, result: JsPromptResult
        ): Boolean {
            val et = EditText(this@MainActivity)
            et.setText(defaultValue ?: "")
            AlertDialog.Builder(this@MainActivity)
                .setTitle(Uri.parse(url).host ?: "")
                .setMessage(message)
                .setView(et)
                .setPositiveButton("OK") { _, _ -> result.confirm(et.text.toString()) }
                .setNegativeButton("Batal") { _, _ -> result.cancel() }
                .setOnCancelListener { result.cancel() }
                .show()
            return true
        }
    }

    private fun handleUrl(v: WebView, url: String): Boolean {
        val scheme = Uri.parse(url).scheme?.lowercase(Locale.US)
        if (scheme == null || scheme == "http" || scheme == "https" || scheme == "about" ||
            scheme == "blob" || scheme == "data" || scheme == "javascript"
        ) return false
        if (scheme == "kilat") { handleInternal(url); return true }
        if (scheme == "file") return !isOwnFile(url)
        var fallback: String? = null
        try {
            val i = if (scheme == "intent") Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            else Intent(Intent.ACTION_VIEW, Uri.parse(url))
            fallback = i.getStringExtra("browser_fallback_url")
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            startActivity(i)
        } catch (e: Exception) {
            if (fallback != null && fallback.startsWith("http")) v.loadUrl(fallback)
            else toast("Tidak ada aplikasi untuk membuka tautan ini")
        }
        return true
    }

    /** Cocok bila host atau induk domainnya ada di daftar (mis. x.doubleclick.net cocok dengan doubleclick.net). */
    private fun isAdHost(host: String?): Boolean {
        var h = host?.lowercase(Locale.US) ?: return false
        while (true) {
            if (AD_HOSTS.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }

    /** Skrip/permintaan iklan yang dikenali dari pola alamatnya, walau domainnya milik situs itu sendiri. */
    private fun isAdPath(path: String?): Boolean {
        val p = path?.lowercase(Locale.US) ?: return false
        for (k in AD_PATHS) if (p.contains(k)) return true
        return false
    }

    private fun isOwnFile(url: String) = url.startsWith("file://" + store.offlineDir().absolutePath + "/")

    private fun handleInternal(url: String) {
        val u = Uri.parse(url)
        when (u.host) {
            "add" -> if (!isPrivate) shortcutDialog(-1)
            "edit" -> if (!isPrivate) u.getQueryParameter("i")?.toIntOrNull()?.let { shortcutDialog(it) }
            "del" -> if (!isPrivate) u.getQueryParameter("i")?.toIntOrNull()?.let {
                homeEdit = true
                store.removeShortcut(it)
                shortcutsChanged()
            }
            "offline" -> {
                val f = u.getQueryParameter("f") ?: return
                store.saved.firstOrNull { it.file == f }?.let { openSaved(it) }
            }
        }
    }

    private fun reloadTab(t: Tab) {
        val w = t.web ?: return
        val err = t.errorFor
        if (err != null) {
            t.errorFor = null
            w.loadUrl(err)
        } else if (isNewTab(t.url)) loadNewTab(t, w)
        else w.reload()
    }

    private fun loadIn(t: Tab, url: String) {
        t.errorFor = null
        ensureWeb(t).loadUrl(url)
    }

    private fun go(input: String) {
        val u = resolve(input)
        if (u.isEmpty()) return
        curTab()?.let { loadIn(it, u) }
        hideKeyboard()
        urlInput.clearFocus()
    }

    private fun resolve(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return ""
        val lower = t.lowercase(Locale.US)
        if (lower.startsWith("http://") || lower.startsWith("https://") || lower.startsWith("about:")) return t
        val looksUrl = !t.contains(' ') && !t.startsWith("?") &&
            (t.contains('.') || lower.startsWith("localhost"))
        if (looksUrl) {
            val host = t.substringBefore('/').substringBefore(':')
            val local = host == "localhost" || Regex("\\d{1,3}(\\.\\d{1,3}){3}").matches(host)
            return (if (local) "http://" else "https://") + t
        }
        return Store.ENGINES[store.engine].search + Uri.encode(t)
    }

    // =========================================================== UI state

    private fun isNewTab(u: String) = u.isEmpty() || u.startsWith("about:")

    private fun display(u: String): String =
        if (isNewTab(u)) "" else if (u.startsWith("file:")) "Dibaca offline" else u.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

    private fun refreshUi() {
        val t = curTab() ?: return
        updateAddress(t)
        updateLoading(t)
        updateNav()
        tabCount.text = tabs.size.toString()
    }

    private fun updateAddress(t: Tab) {
        if (!urlInput.hasFocus()) urlInput.setText(display(t.url))
        icSecurity.setImageResource(
            when {
                isNewTab(t.url) -> R.drawable.ic_search
                t.url.startsWith("file:") -> R.drawable.ic_offline
                t.url.startsWith("https://") -> R.drawable.ic_lock
                else -> R.drawable.ic_info
            }
        )
        updateBookmark()
    }

    private fun updateBookmark() {
        val t = curTab()
        val on = t != null && t.url.startsWith("http") && store.hasBookmark(t.url)
        btnBookmark.setImageResource(if (on) R.drawable.ic_star_on else R.drawable.ic_star)
    }

    private fun toggleBookmark() {
        val t = curTab() ?: return
        if (!t.url.startsWith("http")) {
            toast("Buka sebuah halaman dulu")
            return
        }
        val added = store.toggleBookmark(t.title.ifEmpty { t.url }, t.url)
        toast(if (added) "Bookmark ditambahkan" else "Bookmark dihapus")
        updateBookmark()
    }

    /** Menyimpan halaman sebagai arsip MHTML agar bisa dibaca tanpa internet. */
    private fun savePage() {
        val t = curTab() ?: return
        val w = t.web ?: return
        when {
            isNewTab(t.url) || t.errorFor != null || !t.url.startsWith("http") -> {
                toast("Buka sebuah halaman dulu")
                return
            }
            t.progress in 1..99 -> {
                toast("Tunggu halaman selesai dimuat")
                return
            }
        }
        val dir = store.offlineDir()
        dir.mkdirs()
        val f = File(dir, "p" + System.currentTimeMillis() + ".mht")
        val title = t.title.ifEmpty { display(t.url) }
        val url = t.url
        toast("Menyimpan halaman…")
        w.saveWebArchive(f.absolutePath, false) { path ->
            runOnUiThread {
                if (path != null && f.exists() && f.length() > 0) {
                    store.addSaved(Saved(title, url, f.name, System.currentTimeMillis()))
                    if (panelMode == P_SAVED) refreshPanel()
                    toast("Halaman tersimpan, bisa dibaca offline")
                } else {
                    f.delete()
                    toast("Gagal menyimpan halaman")
                }
            }
        }
    }

    private fun openSaved(sv: Saved) {
        val f = store.fileOf(sv)
        if (!f.exists()) {
            toast("File tersimpan tidak ditemukan")
            return
        }
        curTab()?.let { loadIn(it, Uri.fromFile(f).toString()) }
    }

    private fun updateLoading(t: Tab) {
        val loading = t.progress in 1..99
        btnReload.setImageResource(if (loading) R.drawable.ic_close else R.drawable.ic_refresh)
        btnReload.contentDescription = if (loading) "Berhenti" else "Muat ulang"
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        progress.progress = t.progress
    }

    private fun updateNav() {
        val w = curWeb()
        btnBack.alpha = if (w?.canGoBack() == true) 1f else 0.35f
        btnFwd.alpha = if (w?.canGoForward() == true) 1f else 0.35f
    }

    private fun addHistory(t: Tab, url: String) {
        if (isPrivate || isNewTab(url) || url.startsWith("file:")) return
        store.addHistory(t.title, url)
        ui.removeCallbacks(saveRunnable)
        ui.postDelayed(saveRunnable, 3000)
    }

    private val saveRunnable = Runnable { store.save() }

    private fun setBars(show: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (show) c.show(WindowInsetsCompat.Type.systemBars()) else c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun hideCustom() {
        val v = customView ?: return
        fullscreen.removeView(v)
        fullscreen.visibility = View.GONE
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        setBars(true)
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlInput.windowToken, 0)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copy(s: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("url", s))
        toast("Disalin")
    }

    // =========================================================== menu

    private fun showMenu(anchor: View) {
        val t = curTab() ?: return
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        m.add(0, 1, 0, if (isPrivate) "Tab pribadi baru" else "Tab baru")
        if (!isPrivate) m.add(0, 2, 0, "Tab pribadi baru (jendela terpisah)")
        if (!isPrivate && t.url.startsWith("http")) {
            m.add(0, 3, 0, if (store.hasBookmark(t.url)) "Hapus bookmark" else "Tambah bookmark")
            m.add(0, 14, 0, "Simpan halaman (baca offline)")
        }
        if (!isPrivate) {
            m.add(0, 4, 0, "Bookmark")
            m.add(0, 15, 0, "Halaman tersimpan")
            m.add(0, 5, 0, "Riwayat")
        }
        m.add(0, 6, 0, "Unduhan")
        m.add(0, 21, 0, "File manager")
        m.add(0, 7, 0, "Situs desktop").apply { isCheckable = true; isChecked = t.desktop }
        m.add(0, 8, 0, "Cari di halaman")
        m.add(0, 9, 0, "Bagikan")
        m.add(0, 10, 0, "Salin tautan")
        m.add(0, 18, 0, "Izinkan jalan di latar belakang")
        m.add(0, 20, 0, "Tarik untuk muat ulang").apply { isCheckable = true; isChecked = ptrOn }
        m.add(0, 17, 0, "Blokir iklan").apply { isCheckable = true; isChecked = adBlock }
        if (t.url.startsWith("http")) m.add(0, 16, 0, "Diagnosa halaman")
        if (!isPrivate) m.add(0, 11, 0, "Hapus data penjelajahan")
        m.add(0, 12, 0, "Mesin pencari")
        m.add(0, 19, 0, "Tentang CromeAja")
        if (isPrivate) m.add(0, 13, 0, "Tutup mode pribadi")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> openNewTabAndFocus()
                2 -> openPrivate()
                3 -> toggleBookmark()
                14 -> savePage()
                15 -> showPanel(P_SAVED)
                4 -> showPanel(P_BOOK)
                5 -> showPanel(P_HIST)
                6 -> showDownloads()
                21 -> startActivity(
                    Intent(this, FileManagerActivity::class.java).putExtra(FileManagerActivity.EXTRA_PRIVATE, isPrivate)
                )
                7 -> {
                    t.desktop = !t.desktop
                    t.web?.let { applyDesktop(it, t) }
                    reloadTab(t)
                    toast(if (t.desktop) "Situs desktop aktif" else "Situs seluler aktif")
                }
                8 -> showFind()
                9 -> if (t.url.startsWith("http")) startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.url), null
                    )
                )
                10 -> if (t.url.startsWith("http")) copy(t.url)
                16 -> diagnose()
                18 -> try {
                    startActivity(
                        Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (x: Exception) {
                        toast("Tidak dapat membuka pengaturan baterai")
                    }
                }
                17 -> {
                    adBlock = !adBlock
                    perf.edit().putBoolean("adblock", adBlock).apply()
                    toast(if (adBlock) "Blokir iklan aktif" else "Blokir iklan mati")
                    if (t.url.startsWith("http")) reloadTab(t)
                }
                20 -> {
                    ptrOn = !ptrOn
                    perf.edit().putBoolean("ptr", ptrOn).apply()
                    swipe.isEnabled = ptrOn
                    toast(if (ptrOn) "Tarik untuk muat ulang aktif" else "Tarik untuk muat ulang mati")
                }
                11 -> clearDataDialog()
                12 -> engineDialog()
                19 -> aboutDialog()
                13 -> finish()
            }
            true
        }
        pm.show()
    }

    /** Versi aplikasi dan riwayat perubahan, supaya jelas versi mana yang sedang terpasang. */
    private fun aboutDialog() {
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { null } ?: "?"
        val log = Changelog.ENTRIES.joinToString("\n\n") { (v, note) -> "v$v\n$note" }
        AlertDialog.Builder(this)
            .setTitle("Tentang CromeAja")
            .setMessage("Versi $ver\n\nRiwayat perubahan:\n\n$log")
            .setPositiveButton("Tutup", null)
            .show()
    }

    /** Menampilkan info teknis halaman (dukungan WebAuthn, UA, tombol login) untuk mencari penyebab masalah situs. */
    private fun diagnose() {
        val w = curWeb() ?: return
        // Info perangkat/WebView untuk menelusuri kenapa dialog kunci layar (passkey) tidak muncul
        val wvVer = try { WebViewCompat.getCurrentWebViewPackage(this)?.versionName } catch (e: Throwable) { null }
        val head = "android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "webview: ${wvVer ?: "?"}\n" +
            "fiturWebAuthn: ${WebViewFeature.isFeatureSupported("WEB_AUTHENTICATION")}\n" +
            "fiturBrandUA: ${WebViewFeature.isFeatureSupported("USER_AGENT_METADATA")}\n"
        w.evaluateJavascript(UV_JS, null)
        ui.postDelayed({
            w.evaluateJavascript(DIAG_JS) { raw ->
                val text = head + try {
                    val str = org.json.JSONTokener(raw).nextValue() as? String ?: raw
                    val o = org.json.JSONObject(str)
                    o.keys().asSequence().joinToString("\n") { k -> "$k: ${o.opt(k)}" }
                } catch (e: Exception) {
                    raw ?: "tidak ada hasil"
                }
                AlertDialog.Builder(this)
                    .setTitle("Diagnosa halaman")
                    .setMessage(text)
                    .setPositiveButton("Salin") { _, _ -> copy(text) }
                    .setNegativeButton("Tutup", null)
                    .show()
            }
        }, 700)
    }

    private fun openDownloads() {
        try {
            startActivity(Intent(this, FileManagerActivity::class.java).putExtra(FileManagerActivity.EXTRA_PRIVATE, isPrivate))
        } catch (e: Exception) {
            toast("Tidak dapat membuka daftar unduhan")
        }
    }

    private fun openPrivate() {
        if (Build.VERSION.SDK_INT < 28) {
            toast("Mode pribadi membutuhkan Android 9 atau lebih baru")
            return
        }
        startActivity(Intent(this, PrivateActivity::class.java))
    }

    private fun clearDataDialog() {
        val items = arrayOf("Riwayat penjelajahan", "Cookie dan data situs", "Gambar dan file dalam cache")
        val on = booleanArrayOf(true, true, true)
        AlertDialog.Builder(this)
            .setTitle("Hapus data penjelajahan")
            .setMultiChoiceItems(items, on) { _, i, c -> on[i] = c }
            .setPositiveButton("Hapus") { _, _ ->
                if (on[0]) {
                    store.clearHistory()
                    if (panelMode == P_HIST) refreshPanel()
                }
                if (on[1]) {
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                    WebStorage.getInstance().deleteAllData()
                }
                if (on[2]) curWeb()?.clearCache(true)
                toast("Data dihapus")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun engineDialog() {
        val names = Store.ENGINES.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Mesin pencari")
            .setSingleChoiceItems(names, store.engine) { d, which ->
                store.engine = which
                d.dismiss()
            }
            .show()
    }

    // =========================================================== cari di halaman

    private fun showFind() {
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun closeFind() {
        if (findBar.visibility != View.VISIBLE) return
        curWeb()?.clearMatches()
        findInput.setText("")
        findCount.text = ""
        findBar.visibility = View.GONE
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(findInput.windowToken, 0)
    }

    // =========================================================== panel (tab / riwayat / bookmark)

    /**
     * Mengambil cuplikan bagian atas halaman (rasio 4:5) sebagai thumbnail tab.
     * WebView yang dipercepat perangkat keras sering menghasilkan gambar kosong bila digambar ke Canvas biasa,
     * jadi di Android 8+ dipakai PixelCopy (salinan langsung dari layar). [done] dipanggil di thread utama setelah selesai.
     */
    private fun capture(t: Tab, done: (() -> Unit)? = null) {
        val w = t.web
        if (w == null || w.width <= 0 || w.height <= 0 || w.parent == null || w.windowToken == null) {
            done?.invoke()
            return
        }
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                val loc = IntArray(2)
                w.getLocationInWindow(loc)
                val sw = w.width
                val sh = minOf(w.height, (sw * 1.25f).toInt())
                val src = android.graphics.Rect(loc[0], loc[1], loc[0] + sw, loc[1] + sh)
                val tw = 240
                val th = (tw * sh / sw.toFloat()).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
                android.view.PixelCopy.request(window, src, bmp, { res ->
                    if (res == android.view.PixelCopy.SUCCESS) t.thumb = bmp else captureSoft(t)
                    done?.invoke()
                }, Handler(Looper.getMainLooper()))
                return
            } catch (e: Throwable) {
                // lanjut ke cara lama
            }
        }
        captureSoft(t)
        done?.invoke()
    }

    /** Cara lama (cadangan): menggambar WebView ke bitmap. */
    private fun captureSoft(t: Tab) {
        val w = t.web ?: return
        if (w.width <= 0 || w.height <= 0 || w.parent == null) return
        try {
            val tw = 240
            val th = 300
            val sc = tw / w.width.toFloat()
            val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.RGB_565)
            bmp.eraseColor(attrColor(R.attr.pageBg))
            val c = Canvas(bmp)
            c.scale(sc, sc)
            w.draw(c)
            t.thumb = bmp
        } catch (e: Throwable) {
            // abaikan: thumbnail opsional
        }
    }

    private val tabAdapter = object : BaseAdapter() {
        override fun getCount() = tabs.size
        override fun getItem(p: Int) = tabs[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val v = cv ?: layoutInflater.inflate(R.layout.item_tab, parent, false)
            val t = tabs[p]
            val title = t.title.ifEmpty { if (isNewTab(t.url)) "Tab baru" else display(t.url) }
            v.findViewById<TextView>(R.id.tabTitle).text = title
            val img = v.findViewById<ImageView>(R.id.tabThumb)
            img.setImageBitmap(t.thumb)
            v.findViewById<TextView>(R.id.tabLetter).text =
                if (t.thumb == null) title.trim().take(1).uppercase(Locale.getDefault()) else ""
            v.isActivated = p == cur
            v.findViewById<View>(R.id.tabClose).setOnClickListener { onRowRemove(p) }
            return v
        }
    }

    /** Logo situs: huruf awal berwarna dulu, diganti favicon begitu berhasil dimuat. */
    private fun bindSiteIcon(v: View, r: Row) {
        val letter = v.findViewById<TextView>(R.id.rowLetter)
        val icon = v.findViewById<ImageView>(R.id.rowIcon)
        val host = try { Uri.parse(r.site).host.orEmpty() } catch (e: Exception) { "" }
        val seed = host.ifEmpty { r.title }
        val hue = ((seed.hashCode() and 0x7fffffff) % 360).toFloat()
        val bg = GradientDrawable()
        bg.cornerRadius = 10 * resources.displayMetrics.density
        bg.setColor(Color.HSVToColor(floatArrayOf(hue, 0.5f, 0.62f)))
        letter.background = bg
        letter.text = r.title.trim().take(1).uppercase(Locale.getDefault())
        icon.setImageDrawable(null)
        icon.visibility = View.GONE
        icon.tag = host
        if (host.isNotEmpty() && !isPrivate) {
            FavIcons.load(this, host) { bmp ->
                if (bmp != null && icon.tag == host) {
                    icon.setImageBitmap(bmp)
                    icon.visibility = View.VISIBLE
                }
            }
        }
    }

    private val rowAdapter = object : BaseAdapter() {
        override fun getCount() = panelRows.size
        override fun getItem(p: Int) = panelRows[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val v = cv ?: layoutInflater.inflate(R.layout.item_row, parent, false)
            val r = panelRows[p]
            v.findViewById<TextView>(R.id.rowTitle).text = r.title
            v.findViewById<TextView>(R.id.rowUrl).text = r.url
            bindSiteIcon(v, r)
            v.isActivated = r.active
            v.findViewById<View>(R.id.rowClose).setOnClickListener { onRowRemove(p) }
            return v
        }
    }

    private fun showPanel(mode: Int) {
        closeFind()
        hideKeyboard()
        val ct = curTab()
        if (mode == P_TABS && ct != null && panel.visibility != View.VISIBLE) {
            capture(ct) { showPanelNow(mode) }   // ambil gambar halaman sebelum panel menutupinya
            return
        }
        showPanelNow(mode)
    }

    private fun showPanelNow(mode: Int) {
        panelMode = mode
        when (mode) {
            P_TABS -> { panelAction.text = "+ Tab baru"; panelAction.visibility = View.VISIBLE }
            P_HIST -> { panelTitle.text = "Riwayat"; panelAction.text = "Hapus semua"; panelAction.visibility = View.VISIBLE }
            P_DL -> { panelTitle.text = "Unduhan"; panelAction.text = "Hapus riwayat"; panelAction.visibility = View.VISIBLE }
            P_SAVED -> { panelTitle.text = "Tersimpan (offline)"; panelAction.visibility = View.GONE }
            else -> { panelTitle.text = "Bookmark"; panelAction.visibility = View.GONE }
        }
        refreshPanel()
        panel.visibility = View.VISIBLE
    }

    private fun closePanel() {
        panel.visibility = View.GONE
        panelMode = P_NONE
    }

    private fun refreshPanel() {
        panelRows = when (panelMode) {
            P_TABS -> {
                panelTitle.text = if (isPrivate) "${tabs.size} tab pribadi" else "${tabs.size} tab"
                tabs.mapIndexed { i, t ->
                    Row(
                        t.title.ifEmpty { if (isNewTab(t.url)) "Tab baru" else display(t.url) },
                        display(t.url), i == cur
                    )
                }
            }
            P_HIST -> store.history.map { Row(it.title.ifEmpty { it.url }, it.url, false, it.url) }
            P_DL -> emptyList()
            P_SAVED -> {
                val fmt = SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault())
                store.saved.map { Row(it.title.ifEmpty { display(it.url) }, display(it.url) + "  •  " + fmt.format(Date(it.time)), false, it.url) }
            }
            else -> store.bookmarks.map { Row(it.title.ifEmpty { it.url }, it.url, false, it.url) }
        }
        rowAdapter.notifyDataSetChanged()
        tabAdapter.notifyDataSetChanged()
        dlAdapter.notifyDataSetChanged()
        tabGrid.visibility = if (panelMode == P_TABS) View.VISIBLE else View.GONE
        panelList.visibility = if (panelMode == P_TABS || panelMode == P_DL) View.GONE else View.VISIBLE
        dlList.visibility = if (panelMode == P_DL) View.VISIBLE else View.GONE
        panelEmpty.text = when (panelMode) {
            P_DL -> "Belum ada unduhan"
            P_HIST -> "Belum ada riwayat"
            P_SAVED -> "Belum ada halaman tersimpan.\nBuka halaman, lalu ketuk ikon simpan di atas."
            else -> "Belum ada bookmark"
        }
        panelEmpty.gravity = android.view.Gravity.CENTER
        panelEmpty.setPadding(48, 0, 48, 0)
        panelEmpty.visibility = if (panelMode == P_DL) (if (dls.items.isEmpty()) View.VISIBLE else View.GONE)
            else if (panelRows.isEmpty() && panelMode != P_TABS) View.VISIBLE else View.GONE
    }

    private fun onRowClick(i: Int) {
        when (panelMode) {
            P_TABS -> { selectTab(i); closePanel() }
            P_SAVED -> store.saved.getOrNull(i)?.let { closePanel(); openSaved(it) }
            P_HIST, P_BOOK -> {
                val url = (if (panelMode == P_HIST) store.history else store.bookmarks).getOrNull(i)?.url ?: return
                closePanel()
                curTab()?.let { loadIn(it, url) }
            }
        }
    }

    private fun onRowRemove(i: Int) {
        when (panelMode) {
            P_TABS -> closeTab(i)
            P_HIST -> store.removeHistory(i)
            P_BOOK -> { store.removeBookmark(i); updateBookmark() }
            P_SAVED -> store.removeSaved(i)
        }
        if (panelMode != P_NONE) refreshPanel()
    }

    private fun onPanelAction() {
        when (panelMode) {
            P_TABS -> openNewTabAndFocus()
            P_DL -> clearDownloadHistory()
            P_HIST -> AlertDialog.Builder(this)
                .setMessage("Hapus seluruh riwayat penjelajahan?")
                .setPositiveButton("Hapus") { _, _ -> store.clearHistory(); refreshPanel() }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    // =========================================================== tekan lama

    private fun onLongPress(w: WebView): Boolean {
        val r = w.hitTestResult
        // Halaman utama (tab baru): tekan lama pada thumbnail = dialog ubah nama/alamat (+ tombol Hapus)
        val ct = curTab()
        if (!isPrivate && ct != null && (isNewTab(ct.url) || ct.url.startsWith("data:"))) {
            return true   // tekan lama pada thumbnail ditangani skrip halaman (membuka dialog ubah)
        }
        val extra = r.extra ?: return false
        if (extra.startsWith("kilat:")) return true
        when (r.type) {
            WebView.HitTestResult.SRC_ANCHOR_TYPE -> linkMenu(extra, null)
            WebView.HitTestResult.IMAGE_TYPE -> linkMenu(null, extra)
            WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                val h = Handler(Looper.getMainLooper()) { m ->
                    linkMenu(m.data?.getString("url"), m.data?.getString("src") ?: extra)
                    true
                }
                w.requestFocusNodeHref(h.obtainMessage())
            }
            else -> return false
        }
        return true
    }

    private fun shortcutsChanged() {
        shortVer++
        val t = curTab() ?: return
        val w = t.web ?: return
        if (isNewTab(t.url) && t.errorFor == null) loadNewTab(t, w)
    }

    /** Dialog tambah (index < 0) atau ubah pintasan situs di halaman tab baru. */
    private fun shortcutDialog(index: Int) {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 3, pad, 0)
        val name = EditText(this)
        name.hint = "Nama situs"
        name.setSingleLine()
        name.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        val addr = EditText(this)
        addr.hint = "Alamat, mis. detik.com"
        addr.setSingleLine()
        addr.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val old = store.shortcuts.getOrNull(index)
        if (old != null) {
            name.setText(old.title)
            addr.setText(old.url)
        }
        box.addView(name)
        box.addView(addr)
        val d = AlertDialog.Builder(this)
            .setTitle(if (old == null) "Tambah situs" else "Ubah situs")
            .setView(box)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
            .apply {
                if (old != null) setNeutralButton("Hapus") { _, _ ->
                    store.removeShortcut(index)
                    shortcutsChanged()
                }
            }
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                var u = addr.text.toString().trim()
                if (u.isEmpty()) {
                    toast("Isi alamat situs")
                    return@setOnClickListener
                }
                if (!u.contains("://")) u = "https://$u"
                val low = u.lowercase(Locale.US)
                val host = Uri.parse(u).host
                if (!(low.startsWith("http://") || low.startsWith("https://")) || host.isNullOrEmpty()) {
                    toast("Alamat tidak valid")
                    return@setOnClickListener
                }
                if (store.shortcuts.withIndex().any { (k, e) -> k != index && sameUrl(e.url, u) }) {
                    toast("Situs sudah ada")
                    return@setOnClickListener
                }
                val title = name.text.toString().trim().ifEmpty { host.removePrefix("www.") }
                if (old == null) store.addShortcut(title, u) else store.updateShortcut(index, title, u)
                d.dismiss()
                shortcutsChanged()
            }
        }
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
        name.requestFocus()
    }

    private fun linkMenu(link: String?, img: String?) {
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (link != null) {
            items.add("Buka di tab baru"); acts.add { newTab(link) }
            items.add("Salin tautan"); acts.add { copy(link) }
        }
        if (img != null && img.startsWith("http")) {
            items.add("Unduh gambar"); acts.add { startDownload(img, baseUa, null, null) }
        }
        if (items.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(link ?: img)
            .setItems(items.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    // =========================================================== unduhan

    /** Membersihkan nama dari karakter terlarang; null jika kosong. */
    private fun cleanName(raw: String, guessed: String): String? {
        var n = raw.trim().replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim('.', ' ')
        if (n.isEmpty()) return null
        val ext = guessed.substringAfterLast('.', "")
        if (ext.isNotEmpty() && !n.contains('.')) n += ".$ext"
        return n.take(150)
    }

    /** Menampilkan jendela simpan (bisa ganti nama); file otomatis masuk folder Unduhan. */
    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?, size: Long = -1L) {
        if (!url.startsWith("http")) {
            toast("Jenis unduhan ini belum didukung")
            return
        }
        val guessed = URLUtil.guessFileName(url, cd, mime)
        val d8 = resources.displayMetrics.density
        val pad = (20 * d8).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 3, pad, 0)
        val name = EditText(this)
        name.hint = "Nama file"
        name.setText(guessed)
        name.setSingleLine()
        name.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val info = TextView(this)
        info.text = (if (size > 0) "Ukuran: ${Formatter.formatShortFileSize(this, size)}\n" else "") +
            "Disimpan otomatis di folder Unduhan"
        info.setTextColor(attrColor(R.attr.barDim))
        info.textSize = 13f
        info.setPadding(0, (10 * d8).toInt(), 0, 0)
        box.addView(name)
        box.addView(info)
        val dlg = AlertDialog.Builder(this)
            .setTitle("Simpan file")
            .setView(box)
            .setPositiveButton("Unduh", null)
            .setNegativeButton("Batal", null)
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = cleanName(name.text.toString(), guessed)
                if (n == null) {
                    toast("Nama file tidak boleh kosong")
                    return@setOnClickListener
                }
                dlg.dismiss()
                enqueueDownload(url, ua, mime, n)
            }
        }
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dlg.show()
        name.requestFocus()
        val dot = guessed.lastIndexOf('.')
        name.setSelection(0, if (dot > 0) dot else guessed.length)
    }

    private fun enqueueDownload(url: String, ua: String?, mime: String?, name: String) {
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDl = arrayOf(url, ua, mime, name)
            storagePerm.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        try {
            dls.add(url, ua, mime, name, curWeb()?.url?.takeIf { it.startsWith("http") })
            toast("Mengunduh $name")
        } catch (e: Exception) {
            toast("Unduhan gagal: ${e.message}")
        }
    }

    private fun speedText(bps: Long) =
        if (bps <= 0) "…" else Formatter.formatShortFileSize(this, bps) + "/dtk"

    private fun onDlChange() {
        updateDownloadButton()
        if (panelMode == P_DL) refreshPanel()
    }

    /** Ikon unduh: berwarna + cincin progres + bergoyang saat ada unduhan berjalan; hijau/merah setelah selesai/gagal. */
    private fun updateDownloadButton() {
        if (panelMode == P_DL) dlUnseen = 0
        val run = dls.items.filter { it.running }
        val paused = dls.items.any { it.state == DlManager.PAUSED }
        if (run.isNotEmpty()) {
            var done = 0L
            var total = 0L
            var known = true
            for (d in run) {
                if (d.total > 0) { done += d.done; total += d.total } else known = false
            }
            val c = attrColor(R.attr.brand)
            btnDownload.setColorFilter(c)
            dlRing.setRingColor(c)
            dlRing.progress = if (known && total > 0) done.toFloat() / total else -1f
            dlRing.visibility = View.VISIBLE
            btnDownload.contentDescription = "Unduhan berjalan: ${run.size}"
            if (dlBounce == null) {
                val dd = resources.displayMetrics.density
                dlBounce = ObjectAnimator.ofFloat(btnDownload, View.TRANSLATION_Y, -1.5f * dd, 1.5f * dd).apply {
                    duration = 550
                    repeatCount = ValueAnimator.INFINITE
                    repeatMode = ValueAnimator.REVERSE
                    start()
                }
            }
        } else {
            dlBounce?.cancel()
            dlBounce = null
            btnDownload.translationY = 0f
            dlRing.visibility = View.GONE
            btnDownload.contentDescription = "Unduhan"
            when {
                dlUnseen == 2 -> btnDownload.setColorFilter(0xFFE5384B.toInt())
                dlUnseen == 1 -> btnDownload.setColorFilter(0xFF2E9E5B.toInt())
                paused -> btnDownload.setColorFilter(0xFFF59E0B.toInt())
                else -> btnDownload.clearColorFilter()
            }
        }
    }

    // ---- halaman unduhan (satu halaman penuh, lengkap dengan riwayat)

    private val dlAdapter = object : BaseAdapter() {
        override fun getCount() = dls.items.size
        override fun getItem(p: Int) = dls.items[p]
        override fun getItemId(p: Int) = dls.items[p].id
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val v = cv ?: layoutInflater.inflate(R.layout.item_download, parent, false)
            bindDownloadRow(v, dls.items[p], p)
            return v
        }
    }

    private fun showDownloads() {
        dlUnseen = 0
        showPanel(P_DL)
        updateDownloadButton()
    }

    private fun clearDownloadHistory() {
        val n = dls.items.count { !it.active }
        if (n == 0) {
            toast("Tidak ada riwayat untuk dihapus")
            return
        }
        AlertDialog.Builder(this)
            .setMessage("Hapus $n riwayat unduhan dari daftar ini? File di perangkat tidak ikut terhapus.")
            .setPositiveButton("Hapus") { _, _ -> dls.clearFinished() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun dayKey(ms: Long): Int {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    private fun dayLabel(ms: Long): String {
        val full = SimpleDateFormat("d MMMM yyyy", Locale("id", "ID")).format(Date(ms))
        val k = dayKey(ms)
        val now = System.currentTimeMillis()
        return when (k) {
            dayKey(now) -> "Hari ini, $full"
            dayKey(now - 24L * 3600 * 1000) -> "Kemarin, $full"
            else -> full
        }
    }

    private fun bindDownloadRow(v: View, d: DlItem, pos: Int) {
        val header = v.findViewById<TextView>(R.id.dlHeader)
        val label = dayLabel(d.time)
        val before = if (pos > 0) dls.items.getOrNull(pos - 1) else null
        if (before == null || dayLabel(before.time) != label) {
            header.text = label
            header.visibility = View.VISIBLE
        } else header.visibility = View.GONE
        val row = v.findViewById<View>(R.id.dlRow)
        val name = v.findViewById<TextView>(R.id.dlName)
        val bar = v.findViewById<ProgressBar>(R.id.dlBar)
        val info = v.findViewById<TextView>(R.id.dlInfo)
        val toggle = v.findViewById<ImageView>(R.id.dlToggle)
        name.text = d.name
        var color = attrColor(R.attr.brand)
        var indeterminate = false
        var pct = 0
        if (d.total > 0) pct = (d.done * 100 / d.total).toInt().coerceIn(0, 100)
        val date = SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date(d.time))
        val sizes = if (d.total > 0) Formatter.formatShortFileSize(this, d.done) + " dari " +
            Formatter.formatShortFileSize(this, d.total) else Formatter.formatShortFileSize(this, d.done)
        val text: String
        when (d.state) {
            DlManager.DONE -> {
                pct = 100
                color = 0xFF2E9E5B.toInt()
                text = "Selesai" + (if (d.total > 0) " · ${Formatter.formatShortFileSize(this, d.total)}" else "") + " · $date"
            }
            DlManager.FAILED -> {
                color = 0xFFE5384B.toInt()
                text = "Gagal" + (d.error?.let { ": $it" } ?: "") + " · ketuk ▶ untuk coba lagi"
            }
            DlManager.PAUSED -> {
                color = 0xFFF59E0B.toInt()
                text = if (d.total > 0) "Dijeda · $pct% · $sizes" else "Dijeda · $sizes"
            }
            else -> {
                if (d.total > 0) {
                    text = "$pct% · ${speedText(d.speed)} · $sizes"
                } else {
                    indeterminate = true
                    text = if (d.done <= 0) "Menghubungkan…" else "${speedText(d.speed)} · $sizes"
                }
            }
        }
        info.text = text
        info.setTextColor(if (d.state == DlManager.FAILED) color else attrColor(R.attr.barDim))
        if (bar.isIndeterminate != indeterminate) bar.isIndeterminate = indeterminate
        bar.progressTintList = ColorStateList.valueOf(color)
        bar.indeterminateTintList = ColorStateList.valueOf(color)
        if (!indeterminate) bar.progress = pct

        when (d.state) {
            DlManager.RUNNING -> {
                toggle.visibility = View.VISIBLE
                toggle.setImageResource(R.drawable.ic_pause)
                toggle.contentDescription = "Jeda"
            }
            DlManager.PAUSED, DlManager.FAILED -> {
                toggle.visibility = View.VISIBLE
                toggle.setImageResource(R.drawable.ic_play)
                toggle.contentDescription = "Lanjutkan"
            }
            else -> toggle.visibility = View.GONE
        }
        toggle.setOnClickListener {
            if (d.running) dls.pause(d) else dls.resume(d)
        }
        // Ketuk unduhan yang selesai -> buka file manager (folder Unduhan). Tekan lama -> buka file-nya langsung.
        row.setOnClickListener { if (d.state == DlManager.DONE) openFileManager(d) }
        if (d.state == DlManager.DONE) row.setOnLongClickListener { openDownloadedFile(d); true }
        else row.setOnLongClickListener(null)
        // Unduhan sukses: garis progres dihilangkan, tinggal nama file dan keterangan
        bar.visibility = if (d.state == DlManager.DONE) View.GONE else View.VISIBLE
        v.findViewById<View>(R.id.dlClose).setOnClickListener {
            toast(if (d.active) "Unduhan dibatalkan" else "Dihapus dari daftar")
            dls.remove(d)
        }
    }

    /** Membuka file manager bawaan CromeAja di folder Unduhan (bukan file manager aplikasi lain). */
    private fun openFileManager(d: DlItem) {
        try {
            startActivity(
                Intent(this, FileManagerActivity::class.java).putExtra(FileManagerActivity.EXTRA_PRIVATE, isPrivate)
            )
        } catch (e: Exception) {
            openDownloadedFile(d)
        }
    }

    private fun openDownloadedFile(d: DlItem) {
        try {
            val uri = Uri.parse(d.uri ?: throw IllegalStateException())
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, d.mime ?: "*/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            toast("Tidak dapat membuka file ini")
        }
    }

    // =========================================================== halaman bawaan

    private fun hex(c: Int) = String.format(Locale.US, "#%06X", 0xFFFFFF and c)

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&#39;")

    private fun css(): String {
        val bg = hex(attrColor(R.attr.pageBg))
        val fg = hex(attrColor(R.attr.barFg))
        val dim = hex(attrColor(R.attr.barDim))
        val fld = hex(attrColor(R.attr.fieldBg))
        val acc = hex(attrColor(R.attr.brand))
        return """
            body{margin:0;padding:0 20px 40px;background:$bg;color:$fg;font-family:sans-serif;text-align:center}
            body{padding-top:22px}
            .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:22px 10px;max-width:520px;margin:0 auto}
            .tile{display:block;text-decoration:none;color:$fg;font-size:12px;overflow:visible;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}
            .w{position:relative;width:58px;height:58px;margin:0 auto 7px}
            .ic{position:relative;width:58px;height:58px;border-radius:18px;color:#fff;font-size:24px;font-weight:700;line-height:58px;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.18)}
            .ic img{position:absolute;left:0;top:0;width:100%;height:100%;box-sizing:border-box;padding:13px;background:#fff}
            .ic.add{background:$fld;color:$acc;font-size:30px;font-weight:400;box-shadow:none}
            .x{display:none;position:absolute;top:-3px;right:-3px;width:18px;height:18px;border-radius:50%;background:#E5384B;color:#fff;font-size:10px;line-height:18px;font-weight:700;box-shadow:0 1px 3px rgba(0,0,0,.4)}
            .edit .x{display:block}
            .edit .addt{display:none}
            .edit .ic{animation:sh .3s infinite alternate}
            @keyframes sh{from{transform:rotate(-2deg)}to{transform:rotate(2deg)}}
            .btn{display:inline-block;padding:12px 22px;border-radius:24px;background:$acc;color:$bg;text-decoration:none;font-weight:700;font-size:15px}
            .tile span{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
            .note{color:$dim;font-size:14px;max-width:420px;margin:20px auto;line-height:1.5}
            h2{margin-top:18vh;font-size:22px}
            .url{color:$dim;font-size:13px;word-break:break-all}
        """.trimIndent()
    }

    private fun loadNewTab(t: Tab, w: WebView) {
        t.ntVer = shortVer
        w.loadDataWithBaseURL(null, newTabHtml(), "text/html", "utf-8", NEWTAB)
    }

    private fun newTabHtml(): String {
        val edit = homeEdit
        homeEdit = false
        val body = if (isPrivate) {
            "<h2>Mode pribadi</h2><p class=\"note\">Riwayat, cookie, dan data situs dihapus saat jendela pribadi ditutup. " +
                "File yang Anda unduh tetap tersimpan di perangkat.</p>"
        } else {
            val tiles = store.shortcuts.withIndex().joinToString("") { (k, b) ->
                val label = b.title.ifBlank { b.url }
                val host = Uri.parse(b.url).host.orEmpty()
                val hue = (label.hashCode() and 0x7fffffff) % 360
                val icon = if (host.isEmpty()) "" else
                    "<img src=\"https://www.google.com/s2/favicons?domain=${esc(host)}&amp;sz=128\" alt=\"\" onerror=\"this.remove()\">"
                "<a class=\"tile\" href=\"${esc(b.url)}\" data-e=\"kilat://edit?i=$k\" data-d=\"kilat://del?i=$k\">" +
                    "<div class=\"w\"><div class=\"ic\" style=\"background:hsl($hue,55%,46%)\">" +
                    esc(label.trim().take(1).uppercase(Locale.getDefault())) + icon +
                    "</div><b class=\"x\">&#10005;</b></div><span>${esc(label)}</span></a>"
            }
            val plus = "<a class=\"tile addt\" href=\"kilat://add\"><div class=\"w\"><div class=\"ic add\">+</div></div><span>Tambah</span></a>"
            "<div class=\"grid\">$tiles$plus</div>" + SCRIPT
        }
        return "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<style>${css()}</style></head><body" + (if (edit) " class=\"edit\"" else "") + ">" +
            body + "</body></html>"
    }

    private fun errorHtml(url: String, desc: String, sv: Saved?): String =
        "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<style>${css()}</style></head><body>" +
            "<h2>Halaman tidak dapat dibuka</h2>" +
            "<p class=\"note\">${esc(desc)}</p>" +
            "<p class=\"url\">${esc(url)}</p>" +
            (if (sv != null) "<p><a class=\"btn\" href=\"kilat://offline?f=${esc(sv.file)}\">Buka salinan offline</a></p>" else "") +
            "<p class=\"note\">Periksa koneksi internet, lalu ketuk tombol muat ulang.</p>" +
            "</body></html>"

    companion object {
        private const val NEWTAB = "about:newtab"
        private const val SHIM_JS = "(function(){if(window.PublicKeyCredential)return;window.__cromShim=1;" +
            "function P(){}P.isUserVerifyingPlatformAuthenticatorAvailable=function(){return Promise.resolve(false)};" +
            "P.isConditionalMediationAvailable=function(){return Promise.resolve(false)};window.PublicKeyCredential=P})();"
        private const val BG_JS = "(function(){try{var d=document;" +
            "function df(o,k,v){try{Object.defineProperty(o,k,{configurable:true,get:function(){return v}})}catch(e){}}" +
            "df(d,'hidden',false);df(d,'webkitHidden',false);df(d,'visibilityState','visible');df(d,'webkitVisibilityState','visible');" +
            "var st=function(e){e.stopImmediatePropagation()};" +
            "d.addEventListener('visibilitychange',st,true);d.addEventListener('webkitvisibilitychange',st,true);" +
            "d.hasFocus=function(){return true}}catch(e){}})();"
        private const val UV_JS = "(function(){try{var P=window.PublicKeyCredential;" +
            "if(!P||!P.isUserVerifyingPlatformAuthenticatorAvailable){window.__uv='API tidak ada';return}" +
            "P.isUserVerifyingPlatformAuthenticatorAvailable().then(function(r){window.__uv=String(r)}," +
            "function(e){window.__uv='error '+e})}catch(e){window.__uv='error '+e}})()"
        private const val DIAG_JS = "(function(){try{var t=document.body?document.body.innerText:'';" +
            "var b=(navigator.userAgentData&&navigator.userAgentData.brands||[]).map(function(x){return x.brand+' '+x.version}).join(', ');" +
            "return JSON.stringify({ua:navigator.userAgent,publicKeyCredential:typeof window.PublicKeyCredential," +
            "uvPlatformAuth:window.__uv||'belum ada hasil',stubDipasang:!!window.__cromShim,uaBrands:b,teksGoogle:/Continue with Google/i.test(t)," +
            "teksApple:/Continue with Apple/i.test(t),teksPasskey:/passkey/i.test(t)," +
            "iframeGoogle:!!document.querySelector('iframe[src*=\"accounts.google.com\"]')," +
            "webauthnStatus:!!document.querySelector('webauthn-status')})}catch(e){return 'error '+e}})()"
        /** Memaksa halaman bisa dicubit/zoom walau situs memasang user-scalable=no. */
        private const val ZOOM_JS = "(function(){var m=document.querySelector('meta[name=viewport]');if(!m)return;" +
            "var c=(m.getAttribute('content')||'').replace(/,?\\s*(maximum-scale|minimum-scale|user-scalable)\\s*=\\s*[^,;]*/gi,'');" +
            "m.setAttribute('content',c+', minimum-scale=0.5, maximum-scale=10, user-scalable=yes')})()"
        /** Tekan lama (450 ms) pada thumbnail = buka dialog ubah; ketukan biasa tetap membuka situs. */
        private const val SCRIPT = "<script>(function(){var t=null,lp=false,sx=0,sy=0;" +
            "function clr(){if(t){clearTimeout(t);t=null}}" +
            "document.addEventListener('touchstart',function(e){lp=false;clr();" +
            "var a=e.target.closest('a.tile');if(!a||a.dataset.e===undefined)return;" +
            "var p=e.touches[0];sx=p.clientX;sy=p.clientY;" +
            "t=setTimeout(function(){t=null;lp=true;location.href=a.dataset.e},450)},{passive:true});" +
            "document.addEventListener('touchmove',function(e){var p=e.touches[0];" +
            "if(Math.abs(p.clientX-sx)>10||Math.abs(p.clientY-sy)>10)clr()},{passive:true});" +
            "document.addEventListener('touchend',clr,{passive:true});" +
            "document.addEventListener('touchcancel',clr,{passive:true});" +
            "document.addEventListener('click',function(e){if(lp){lp=false;e.preventDefault();e.stopPropagation()}},true);" +
            "document.addEventListener('contextmenu',function(e){e.preventDefault()})})()</script>"
        /**
         * Memberi tahu aplikasi saat jari mulai pada elemen yang mengurus gesernya sendiri (daftar/roda tanggal, slider,
         * kalender, dsb.), agar tarik-ke-bawah tidak memuat ulang halaman. Juga menghormati overscroll-behavior dan touch-action situs.
         */
        private const val PTR_JS = "(function(){if(window.__cromPtr)return;window.__cromPtr=1;" +
            "var RX=/(picker|wheel|drum|scroller|scrollable|dropdown|drop-down|calendar|datepicker|swiper|carousel|slider|spinner|listbox)/i;" +
            "var RL=/^(listbox|slider|spinbutton|combobox|option|menu|menuitem|dialog|grid|scrollbar)$/;" +
            "var TG=/^(SELECT|INPUT|TEXTAREA|CANVAS|VIDEO|OPTION)$/;" +
            "function blk(e){try{var h=document.documentElement,b=document.body,k,o;" +
            "for(k=0;k<2;k++){var n=k?b:h;if(n){o=getComputedStyle(n).overscrollBehaviorY;if(o==='contain'||o==='none')return true}}" +
            "while(e&&e.nodeType===1&&e!==b&&e!==h){" +
            "if(TG.test(e.tagName))return true;" +
            "var cs=getComputedStyle(e),oy=cs.overflowY;" +
            "if((oy==='auto'||oy==='scroll'||oy==='overlay')&&e.scrollHeight>e.clientHeight+1)return true;" +
            "var ta=cs.touchAction;if(ta==='none'||ta==='pan-x'||ta==='pan-left'||ta==='pan-right')return true;" +
            "o=cs.overscrollBehaviorY;if(o==='contain'||o==='none')return true;" +
            "var r=e.getAttribute('role');if(r&&RL.test(r))return true;" +
            "var c=e.className;if(typeof c==='string'&&c&&RX.test(c))return true;" +
            "e=e.parentElement||(e.getRootNode&&e.getRootNode().host)}}catch(x){}return false}" +
            "function set(v){try{if(window.CromPtr)window.CromPtr.block(v)}catch(x){}}" +
            "var o={passive:true,capture:true};" +
            "document.addEventListener('touchstart',function(e){set(blk(e.target))},o);" +
            "document.addEventListener('touchend',function(){set(false)},o);" +
            "document.addEventListener('touchcancel',function(){set(false)},o)})()"
        /** Menyembunyikan kotak iklan umum (iklan Google, jaringan iklan native, kelas "ads/banner") lewat CSS. */
        private const val HIDE_ADS_JS = "(function(){try{if(document.getElementById('__crom_ab'))return;" +
            "var s=document.createElement('style');s.id='__crom_ab';" +
            "s.textContent='ins.adsbygoogle,.adsbygoogle,[id^=\"google_ads\"],[id^=\"div-gpt-ad\"],[id^=\"taboola-\"],[id^=\"outbrain\"]," +
            "iframe[src*=\"doubleclick.net\"],iframe[src*=\"googlesyndication\"],iframe[id^=\"google_ads\"]," +
            "[data-ad-slot],[data-google-query-id],.ad-banner,.adbox,.ad-box,.adsbox,.ad_box,.ads-box,.ad-container,.ad-slot,.ad-wrapper," +
            ".advert,.advertisement,.textads,.text-ads,.afs_ads,.banner_ads,.banner-ads,.sponsored-ad,.taboola,.OUTBRAIN,#ad-banner,#adbox,#ads-banner" +
            "{display:none!important}';" +
            "(document.head||document.documentElement).appendChild(s)}catch(e){}})()"
        /** Potongan alamat yang hampir pasti iklan (dicocokkan pada path, bukan domain). */
        private val AD_PATHS = listOf(
            "/pagead/", "/pagead.js", "/adsbygoogle", "/show_ads", "/adserver/", "/adframe.", "/ads.js", "/ad.js", "/widget/ads."
        )
        private const val MAX_LIVE = 3
        private const val SAFE_BROWSING = false
        private val AD_HOSTS: HashSet<String> = hashSetOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "googletagservices.com",
            "adservice.google.com", "adservice.google.co.id", "google-analytics.com", "2mdn.net",
            "adnxs.com", "adsrvr.org", "criteo.com", "criteo.net", "taboola.com", "outbrain.com",
            "scorecardresearch.com", "quantserve.com", "hotjar.com", "amazon-adsystem.com", "moatads.com",
            "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com", "advertising.com",
            "adform.net", "popads.net", "propellerads.com", "exoclick.com", "juicyads.com", "trafficjunky.net",
            "mgid.com", "revcontent.com", "zedo.com", "smartadserver.com", "serving-sys.com", "yieldmo.com",
            "media.net", "adcolony.com", "applovin.com", "mopub.com", "inmobi.com", "adsafeprotected.com",
            "doubleverify.com", "chartbeat.net", "ads.yahoo.com", "adskeeper.com", "bidswitch.net",
            "smaato.net", "teads.tv", "sharethrough.com", "33across.com", "lijit.com", "contextweb.com",
            "adsco.re", "onetag-sys.com", "id5-sync.com", "adition.com", "gumgum.com", "indexww.com",
            "sitescout.com", "bluekai.com", "demdex.net", "krxd.net", "rlcdn.com", "tapad.com",
            "mathtag.com", "everesttech.net", "adtechus.com", "yieldlab.net", "adnxs-simple.com",
            "pagead2.googlesyndication.com", "tpc.googlesyndication.com", "securepubads.g.doubleclick.net",
            "ads.twitter.com", "analytics.twitter.com", "ads.linkedin.com", "px.ads.linkedin.com",
            "analytics.tiktok.com", "ads.tiktok.com", "log.byteoversea.com", "mon.byteoversea.com",
            "adjust.com", "app-measurement.com", "branch.io", "appsflyer.com", "mixpanel.com",
            "segment.io", "segment.com", "fullstory.com", "mouseflow.com", "clarity.ms", "crazyegg.com",
            "luckyorange.com", "inspectlet.com", "newrelic.com", "nr-data.net", "bugsnag.com",
            "ad.gt", "adsymptotic.com", "agkn.com", "bidr.io", "bttrack.com", "turn.com", "yieldoptimizer.com",
            "ad-delivery.net", "adroll.com", "perfectaudience.com", "richaudience.com", "rfihub.com",
            "pippio.com", "owneriq.net", "w55c.net", "spotxchange.com", "spotx.tv", "adtelligent.com",
            "undertone.com", "triplelift.com", "conversantmedia.com", "connextra.com", "ligatus.com",
            "plista.com", "nativo.com", "zemanta.com", "adblade.com", "content.ad", "clickadu.com",
            "hilltopads.net", "adcash.com", "a-ads.com", "monetag.com", "pushwoosh.com", "onesignal-ads.com",
            "mc.yandex.ru", "an.yandex.ru", "yandexadexchange.net", "mc.webvisor.com", "counter.yadro.ru", "top-fwz1.mail.ru",
            "sentry.io", "sentry-cdn.com", "getsentry.com", "rollbar.com", "airbrake.io", "logrocket.com", "smartlook.com",
            "heapanalytics.com", "heap.io", "amplitude.com", "omtrdc.net", "2o7.net", "optimizely.com", "stats.wp.com", "pixel.wp.com",
            "pixel.facebook.com", "an.facebook.com", "analytics.facebook.com", "snap.licdn.com", "dc.ads.linkedin.com", "bat.bing.com",
            "ads.reddit.com", "events.reddit.com", "alb.reddit.com", "static.ads-twitter.com", "ads-api.twitter.com",
            "ads.pinterest.com", "ct.pinterest.com", "trk.pinterest.com", "sc-static.net", "tr.snapchat.com", "adsapi.snapchat.com",
            "business-api.tiktok.com", "analytics.yahoo.com", "udc.yahoo.com", "imasdk.googleapis.com", "stickyadstv.com", "tidaltv.com",
            "fwmrm.net", "innovid.com", "smartclip.net", "unityads.unity3d.com", "ads.unity3d.com", "vungle.com", "chartboost.com",
            "supersonicads.com", "ironsrc.com", "adsterra.com", "popcash.net", "propellerclick.com", "yllix.com", "admaven.com", "ad-maven.com",
            "exdynsrv.com", "realsrv.com", "tsyndicate.com", "adspyglass.com", "ero-advertising.com", "dtscout.com", "dtscdn.com",
            "onclickads.net", "onclkds.com", "profitablegatecpm.com", "highperformanceformat.com", "effectivegatecpm.com",
            "topcreativeformat.com", "browser-intake-datadoghq.com", "hs-analytics.net", "hscollectedforms.net", "usemessages.com",
            "adthrive.com", "mediavine.com", "ezoic.net", "ezodn.com", "cdn.carbonads.com", "carbonads.net", "buysellads.com",
            "adtng.com", "adnium.com", "trafficfactory.biz", "clickadilla.com", "pushnami.com", "pushengage.com", "izooto.com"
        )
        private const val P_NONE = 0
        private const val P_TABS = 1
        private const val P_HIST = 2
        private const val P_BOOK = 3
        private const val P_SAVED = 4
        private const val P_DL = 5
    }
}
