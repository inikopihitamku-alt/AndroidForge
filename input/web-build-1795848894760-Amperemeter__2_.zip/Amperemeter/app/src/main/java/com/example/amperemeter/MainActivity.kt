package com.example.amperemeter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import kotlin.math.abs

/**
 * Amperemeter charger: membaca VBUS (tegangan konektor) dan arus jalur charger
 * dari folder sysfs power_supply (node usb, ac, dll). Ketersediaan tergantung merk/kernel hp.
 * Data baterai (BatteryManager) ditampilkan sebagai pembanding.
 */
class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var bm: BatteryManager
    private val samples = ArrayDeque<Double>()
    private var showDump = false

    private lateinit var tvStatus: TextView
    private lateinit var tvVbus: TextView
    private lateinit var tvAmp: TextView
    private lateinit var tvWatt: TextView
    private lateinit var tvBatt: TextView
    private lateinit var tvDump: TextView

    private val ticker = object : Runnable {
        override fun run() { update(); handler.postDelayed(this, 1000) }
    }

    // ---------- baca sysfs ----------
    private val root = File("/sys/class/power_supply")

    private fun readStr(f: File): String? = try { f.readText().trim() } catch (e: Exception) { null }
    private fun readLong(f: File): Long? = readStr(f)?.toLongOrNull()

    private val chargerTypes = setOf(
        "usb", "mains", "usb_dcp", "usb_cdp", "usb_aca", "usb_c", "usb_pd", "usb_pd_drp",
        "wireless", "usb_hvdcp", "usb_hvdcp_3", "usb_float", "usb_brick_id", "dc"
    )

    private data class Charger(val name: String, val volt: Double?, val ma: Double?, val vSrc: String, val aSrc: String)

    private fun toVolt(raw: Long): Double = when {
        raw >= 1_000_000 -> raw / 1_000_000.0   // µV
        raw >= 1000 -> raw / 1000.0              // mV
        else -> raw.toDouble()                   // V
    }
    private fun toMa(raw: Long): Double =
        if (abs(raw) >= 20000) abs(raw) / 1000.0 else abs(raw).toDouble()

    private fun findCharger(): Charger? {
        val nodes = root.listFiles() ?: return null
        var best: Charger? = null
        for (n in nodes.sortedBy { it.name }) {
            val name = n.name.lowercase()
            val type = readStr(File(n, "type"))?.lowercase() ?: ""
            if (type == "battery" || name == "battery" || name == "bms") continue
            if (type !in chargerTypes && name !in chargerTypes) continue
            val online = readLong(File(n, "online"))
            if (online != null && online == 0L) continue

            val vFile = listOf("voltage_now", "input_voltage_now", "vbus_voltage")
                .firstNotNullOfOrNull { k -> readLong(File(n, k))?.let { k to it } }
            val aFile = listOf("input_current_now", "current_now", "input_current", "current_avg")
                .firstNotNullOfOrNull { k -> readLong(File(n, k))?.let { k to it } }
            if (vFile == null && aFile == null) continue

            val c = Charger(
                n.name,
                vFile?.let { toVolt(it.second) },
                aFile?.let { toMa(it.second) },
                vFile?.first ?: "-", aFile?.first ?: "-"
            )
            // pilih node yang punya data paling lengkap
            if (best == null || (c.volt != null && c.ma != null && (best.volt == null || best.ma == null))) best = c
        }
        return best
    }

    private fun dumpAll(): String {
        val nodes = root.listFiles() ?: return "Folder $root tidak bisa dibaca (diblokir sistem)."
        val sb = StringBuilder()
        for (n in nodes.sortedBy { it.name }) {
            sb.append("[${n.name}] type=${readStr(File(n, "type")) ?: "?"}\n")
            val keys = listOf("online", "present", "status", "voltage_now", "input_voltage_now",
                "current_now", "input_current_now", "input_current_settled", "current_max", "voltage_max")
            for (k in keys) readStr(File(n, k))?.let { sb.append("  $k = $it\n") }
        }
        return sb.toString()
    }

    // ---------- update ----------
    private fun update() {
        val i: Intent? = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
        var mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        if (mv in 1..99) mv *= 1000
        val rawBat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        val batMa = toMa(rawBat.toLong())

        val ch = if (plugged != 0) findCharger() else null

        tvStatus.text = when {
            plugged == 0 -> "Charger tidak terhubung"
            status == BatteryManager.BATTERY_STATUS_FULL -> "Terhubung - baterai penuh"
            else -> "Mengisi daya"
        }

        if (ch != null) {
            tvVbus.text = ch.volt?.let { "%.2f V".format(it) } ?: "-"
            val a = ch.ma
            if (a != null) {
                samples.addLast(a); if (samples.size > 5) samples.removeFirst()
            }
            val avg = if (samples.isEmpty()) null else samples.average()
            tvAmp.text = avg?.let { "%.0f mA".format(it) } ?: "-"
            tvWatt.text = if (ch.volt != null && avg != null) "%.2f W".format(ch.volt * avg / 1000.0) else "-"
            tvStatus.text = tvStatus.text.toString() + "\nSumber data: ${ch.name} (${ch.vSrc}, ${ch.aSrc})"
        } else {
            samples.clear()
            tvVbus.text = "-"; tvAmp.text = "-"; tvWatt.text = "-"
            if (plugged != 0) tvStatus.text = tvStatus.text.toString() +
                    "\nHP ini tidak membuka data VBUS/arus charger. Tekan Scan untuk melihat node yang tersedia."
        }

        tvBatt.text = "Pembanding (sisi baterai):\n%.3f V  |  %.0f mA  |  %d%%  |  %.1f°C".format(
            mv / 1000.0, batMa, level * 100 / scale, temp)
        if (showDump) tvDump.text = dumpAll()
    }

    // ---------- UI ----------
    private fun tv(size: Float, bold: Boolean = false, color: Int = Color.BLACK) = TextView(this).apply {
        textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun label(t: String) = tv(12f, color = Color.GRAY).apply { text = t; setPadding(0, 20, 0, 0) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 64, 48, 48); setBackgroundColor(Color.WHITE)
        }
        tvStatus = tv(14f, true, Color.parseColor("#2E7D32"))
        tvVbus = tv(48f, true, Color.parseColor("#1565C0"))
        tvAmp = tv(56f, true, Color.parseColor("#C62828"))
        tvWatt = tv(32f, true, Color.parseColor("#EF6C00"))
        tvBatt = tv(13f, color = Color.DKGRAY).apply { setPadding(0, 32, 0, 0) }
        tvDump = TextView(this).apply { textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(Color.DKGRAY) }
        val btn = Button(this).apply {
            text = "Scan node charger (diagnosa)"
            setOnClickListener { showDump = !showDump; tvDump.text = if (showDump) dumpAll() else "" }
        }
        listOf(tvStatus, label("TEGANGAN CHARGER (VBUS)"), tvVbus, label("ARUS CHARGER"), tvAmp,
            label("DAYA CHARGER"), tvWatt, tvBatt, btn, tvDump).forEach { col.addView(it) }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }
}
