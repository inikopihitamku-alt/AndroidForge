plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// NAIKKAN angka ini setiap kali membuat versi baru (2, 3, 4, ...).
// Hasil APK akan bernama Amperemeter-v<angka>.apk dan menimpa (update) versi lama saat di-install.
val appVersionCode = 2

android {
    namespace = "com.example.amperemeter"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.amperemeter"
        minSdk = 21
        targetSdk = 34
        versionCode = appVersionCode
        versionName = "1.$appVersionCode"
    }

    // Keystore tetap: semua build (debug & release) ditandatangani kunci yang sama,
    // sehingga APK baru bisa menimpa APK lama tanpa harus uninstall.
    signingConfigs {
        create("fixed") {
            storeFile = file("amperemeter.keystore")
            storePassword = "amperemeter123"
            keyAlias = "amperemeter"
            keyPassword = "amperemeter123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Nama file berurutan: Amperemeter-v2-debug.apk, Amperemeter-v3-release.apk, dst.
base {
    archivesName.set("Amperemeter-v$appVersionCode")
}
