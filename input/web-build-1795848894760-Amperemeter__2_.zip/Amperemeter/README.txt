CARA BUILD APK
1. Build lewat AndroidForge atau Android Studio (Build > Build APK(s)).
2. Hasil: Amperemeter-v<nomor>-debug.apk / -release.apk

MENIMPA (UPDATE) VERSI LAMA
- Package name tetap (com.example.amperemeter) dan ditandatangani keystore tetap
  (app/amperemeter.keystore), jadi APK baru langsung menimpa versi lama tanpa uninstall.
- Setiap versi baru, naikkan "appVersionCode" di app/build.gradle.kts (2 -> 3 -> 4 ...).
  Android menolak menimpa jika versionCode sama atau lebih kecil.
- Jika sebelumnya sudah terpasang APK hasil build lama (kunci berbeda), uninstall sekali saja.
